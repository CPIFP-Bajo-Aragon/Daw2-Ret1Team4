-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 19-02-2024 a las 14:14:45
-- Versión del servidor: 10.6.16-MariaDB-0ubuntu0.22.04.1
-- Versión de PHP: 8.1.2-1ubuntu2.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `mydb`
--
CREATE SCHEMA IF NOT EXISTS mydb;
USE mydb;
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `aviso`
--

CREATE TABLE `aviso` (
  `id_aviso` int(11) NOT NULL,
  `titulo_aviso` varchar(255) NOT NULL,
  `contenido_aviso` varchar(255) NOT NULL,
  `fecha_creacion_aviso` date NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chatear`
--

CREATE TABLE `chatear` (
  `id_usuario` int(11) NOT NULL,
  `id_usuario1` int(11) NOT NULL,
  `fecha_chat` datetime NOT NULL DEFAULT current_timestamp(),
  `mensaje_chat` varchar(255) DEFAULT NULL,
  `estado_chat` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `chatear`
--

INSERT INTO `chatear` (`id_usuario`, `id_usuario1`, `fecha_chat`, `mensaje_chat`, `estado_chat`) VALUES
(4, 2, '2024-02-15 08:27:36', 'hola', NULL),
(2, 4, '2024-02-15 08:34:43', 'asd', NULL),
(5, 1, '2024-02-15 08:34:54', 'aaaaaaaaaaaaaaaaaaaaaa', NULL),
(4, 2, '2024-02-15 10:46:04', 'aaaaaaaaaaaaa', NULL),
(4, 2, '2024-02-15 10:46:07', 'ooo', NULL),
(4, 2, '2024-02-15 10:46:10', 'asdsa', NULL),
(2, 2, '2024-02-15 10:46:49', 'saaa', NULL),
(2, 2, '2024-02-15 10:47:12', 'saaa', NULL),
(2, 2, '2024-02-15 10:47:16', 'OOOOOOOOOOOOO', NULL),
(2, 2, '2024-02-15 10:47:23', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 10:48:22', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:00:20', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:00:35', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:01:18', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:01:21', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:01:26', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:01:47', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:02:06', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:02:10', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:02:18', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:02:28', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:02:36', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:02:42', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:02:44', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:02:47', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:02:56', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:03:03', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:03:22', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:03:44', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:03:51', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:03:57', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:03:58', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:03:59', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:04:04', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:04:11', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:04:18', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:04:23', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:04:33', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:04:45', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:04:49', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:04:55', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:04:59', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:01', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:03', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:16', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:24', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:27', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:29', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:34', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:41', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:46', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:05:49', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:06:20', '<h1>hola</h1>', NULL),
(2, 2, '2024-02-15 11:14:17', 'U', NULL),
(2, 2, '2024-02-15 11:14:20', 'U', NULL),
(2, 2, '2024-02-15 11:14:23', 'U', NULL),
(2, 2, '2024-02-15 11:14:31', 'U', NULL),
(2, 2, '2024-02-15 11:14:32', 'U', NULL),
(2, 2, '2024-02-15 11:14:33', 'U', NULL),
(2, 2, '2024-02-15 11:14:34', 'U', NULL),
(2, 2, '2024-02-15 11:14:35', 'U', NULL),
(2, 2, '2024-02-15 11:14:36', 'U', NULL),
(2, 2, '2024-02-15 11:14:37', 'U', NULL),
(2, 2, '2024-02-15 11:14:38', 'U', NULL),
(2, 2, '2024-02-15 11:28:04', 'U', NULL),
(1, 2, '2024-02-15 12:09:56', 'hola\r\n', NULL),
(4, 2, '2024-02-16 08:10:02', 'a', NULL),
(4, 2, '2024-02-16 08:37:29', 'asd', NULL),
(4, 2, '2024-02-16 08:37:56', 'asd', NULL),
(4, 2, '2024-02-16 08:38:06', 'asd', NULL),
(4, 2, '2024-02-16 08:42:28', 'asd', NULL),
(4, 2, '2024-02-16 08:42:39', 'asd', NULL),
(4, 2, '2024-02-16 08:43:15', 'asd', NULL),
(4, 2, '2024-02-16 08:43:27', 'asd', NULL),
(4, 2, '2024-02-16 08:44:06', 'asd', NULL),
(4, 2, '2024-02-16 08:44:31', 'asd', NULL),
(4, 2, '2024-02-16 08:45:12', 'asd', NULL),
(4, 2, '2024-02-16 08:45:28', 'asd', NULL),
(4, 19, '2024-02-16 09:07:52', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', NULL),
(13, 4, '2024-02-16 09:09:01', 'OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO', NULL),
(4, 19, '2024-02-16 09:15:21', 'asdda', NULL),
(4, 13, '2024-02-16 09:15:25', 'AAA', NULL),
(4, 13, '2024-02-16 09:15:37', 'AAA', NULL),
(4, 13, '2024-02-16 09:15:57', 'AAA', NULL),
(4, 13, '2024-02-16 09:16:01', 'AAA', NULL),
(2, 1, '2024-02-16 10:49:17', 'me interesa tu ofertón', NULL),
(4, 13, '2024-02-19 08:37:32', 'asd', NULL),
(4, 13, '2024-02-19 08:40:42', 'asd', NULL),
(4, 13, '2024-02-19 08:40:46', 'asd', NULL),
(4, 2, '2024-02-19 08:40:53', 'asdaaa', NULL),
(4, 2, '2024-02-19 08:42:17', 'AAAAAAAAAAAAAAAA', NULL),
(2, 4, '2024-02-19 08:42:52', 'AAAA', NULL),
(4, 2, '2024-02-19 08:47:33', 'sadasdasdasd', NULL),
(4, 2, '2024-02-19 08:47:35', 'dfgdfg', NULL),
(2, 4, '2024-02-19 08:48:22', 'hola', NULL),
(2, 4, '2024-02-19 08:50:41', 'hola', NULL),
(2, 4, '2024-02-19 08:50:51', 'olaaa', NULL),
(4, 2, '2024-02-19 09:08:10', 'asd', NULL),
(2, 4, '2024-02-19 09:08:36', 'a', NULL),
(2, 4, '2024-02-19 09:08:54', 'aaa', NULL),
(2, 4, '2024-02-19 09:09:15', 'aaa', NULL),
(2, 4, '2024-02-19 09:09:23', 'asdasdasdas', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documento`
--

CREATE TABLE `documento` (
  `id_documento` int(11) NOT NULL,
  `nombre_documento` varchar(45) NOT NULL,
  `descripcion_documento` varchar(45) DEFAULT NULL,
  `tipo_documento` varchar(45) DEFAULT NULL,
  `fecha_subida` date DEFAULT NULL,
  `ruta_archivo` varchar(45) DEFAULT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entidad`
--

CREATE TABLE `entidad` (
  `id_entidad` int(11) NOT NULL,
  `nombre_entidad` varchar(100) NOT NULL,
  `cif_entidad` varchar(20) NOT NULL,
  `sector_entidad` varchar(50) DEFAULT NULL,
  `direccion_entidad` varchar(200) NOT NULL,
  `numero_telefono_entidad` varchar(15) NOT NULL,
  `correo_entidad` varchar(100) NOT NULL,
  `pagina_web_entidad` varchar(100) DEFAULT NULL,
  `activa` tinyint(4) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `entidad`
--

INSERT INTO `entidad` (`id_entidad`, `nombre_entidad`, `cif_entidad`, `sector_entidad`, `direccion_entidad`, `numero_telefono_entidad`, `correo_entidad`, `pagina_web_entidad`, `activa`) VALUES
(1, 'Entidad 1', '54564743J', 'Informatica', 'Plaza España', '64577477', 'entidad1@gmail.com', 'Entidad1.com', 1),
(3, 'Alcanalitycs', '654654ff', 'Informática', '11', '651201478', 'alca@gmail.com', 'alcanalitycs.com', 1),
(4, 'Nytt', '34464564K', 'Informatica', 'Plaza España', '645756788', 'nytt@gmail.com', 'nytt.com', 1),
(5, 'DHCJM', '5439645L', 'Informatica', 'Calle Jose Pardo Sastron', '54645646', 'dhcjm@gmail.com', 'dhcjm.com', 1),
(6, 'Gitano Corporation', '555712Q', 'Informatica', 'Calle Zaragoza 39', '642387475', 'adriperezcaspe@gmail.com', 'nyttba.es', 1),
(7, 'La Tertulia', 'H16522864', 'A', 'A', '633391777', 'laTertulia@gmail.com', 'https://www.barlatertulia.com/', 1),
(8, 'Prueba', '73229684F', 'Sectro', 'calle falsa', '63333333', 'carlosbaq24@gmail.com', '', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE `estado` (
  `id_estado` int(11) NOT NULL,
  `estado` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`id_estado`, `estado`) VALUES
(1, 'Nuevo'),
(2, 'usado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `imagen`
--

CREATE TABLE `imagen` (
  `id_imagen` int(11) NOT NULL,
  `nombre_imagen` varchar(45) NOT NULL,
  `formato_imagen` varchar(45) NOT NULL,
  `ruta_imagen` varchar(45) NOT NULL,
  `descripcion_imagen` varchar(45) DEFAULT NULL,
  `id_inmueble` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `inmueble`
--

CREATE TABLE `inmueble` (
  `id_inmueble` int(11) NOT NULL,
  `metros_cuadrados_inmueble` int(11) DEFAULT NULL,
  `descripcion_inmueble` varchar(700) DEFAULT NULL,
  `direccion_inmueble` varchar(120) DEFAULT NULL,
  `latitud_inmueble` varchar(255) DEFAULT NULL,
  `longitud_inmueble` varchar(255) DEFAULT NULL,
  `tipo_inmueble` char(1) DEFAULT NULL,
  `id_municipio` int(11) DEFAULT NULL,
  `id_estado` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `inmueble`
--

INSERT INTO `inmueble` (`id_inmueble`, `metros_cuadrados_inmueble`, `descripcion_inmueble`, `direccion_inmueble`, `latitud_inmueble`, `longitud_inmueble`, `tipo_inmueble`, `id_municipio`, `id_estado`) VALUES
(1, 333, 'Piso amplio, cerca de universidad, zonas comunes, gastos incluidos...', 'Calle Zaragoza 50 1º B', NULL, NULL, 'V', 10, 1),
(2, 15, 'Local muy pequeño pero en buenas condiciones.', 'Calle Baja 17', NULL, NULL, 'L', 10, 2),
(3, 590, 'Amplio y grande', 'calle 1', NULL, NULL, 'L', 10, NULL),
(4, 300, 'Muy grande y con todo incluido', 'calle 3 teruel', NULL, NULL, 'L', 10, NULL),
(5, 80, 'Tiene todo incluido. Piso amueblado cerca de la universidad.', 'calle san jorge', NULL, NULL, 'V', 11, NULL),
(6, 120, 'hjkhk', 'adasda', NULL, NULL, 'V', 10, NULL),
(7, 170, 'Casa grande', 'calle 1', NULL, NULL, 'V', 10, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `local`
--

CREATE TABLE `local` (
  `id_inmueble` int(11) NOT NULL,
  `aforo` int(11) DEFAULT NULL,
  `recursos` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `local`
--

INSERT INTO `local` (`id_inmueble`, `aforo`, `recursos`) VALUES
(2, 2, 'Agua, luz.'),
(3, 20, 'agua, luz y todo'),
(4, 30, 'todo incluido');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipio`
--

CREATE TABLE `municipio` (
  `id_municipio` int(11) NOT NULL,
  `nombre_municipio` varchar(50) NOT NULL,
  `provincia_municipio` varchar(50) NOT NULL,
  `codigo_postal_municipio` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `municipio`
--

INSERT INTO `municipio` (`id_municipio`, `nombre_municipio`, `provincia_municipio`, `codigo_postal_municipio`) VALUES
(10, 'Teruel', 'Teruel', '44001'),
(11, 'Fuentealbilla', 'Albacete', '02260'),
(12, '1', '1', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `negocio`
--

CREATE TABLE `negocio` (
  `id_negocio` int(11) NOT NULL,
  `titulo_negocio` varchar(30) DEFAULT NULL,
  `motivo_traspaso_negocio` varchar(250) DEFAULT NULL,
  `coste_traspaso_negocio` int(11) DEFAULT NULL,
  `coste_mensual_negocio` int(11) DEFAULT NULL,
  `descripcion_negocio` varchar(400) DEFAULT NULL,
  `id_municipio_negocio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `negocio`
--

INSERT INTO `negocio` (`id_negocio`, `titulo_negocio`, `motivo_traspaso_negocio`, `coste_traspaso_negocio`, `coste_mensual_negocio`, `descripcion_negocio`, `id_municipio_negocio`) VALUES
(1, 'Panadería Buen Pan', 'Jubilación', 18000, 800, NULL, 10),
(2, 'herreria de pedrito', NULL, 120000, 1300, 'Es una herrería', 10),
(3, 'Alguacil', NULL, 20000, 300, 'Hacer cosas del pueblo', 10),
(4, 'Panes gedo', NULL, 30000, 600, 'Vendemos mucho', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `negocio_local`
--

CREATE TABLE `negocio_local` (
  `id_negocio` int(11) NOT NULL,
  `id_inmueble` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `negocio_local`
--

INSERT INTO `negocio_local` (`id_negocio`, `id_inmueble`) VALUES
(2, 3),
(4, 4);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `noticia`
--

CREATE TABLE `noticia` (
  `id_noticia` int(11) NOT NULL,
  `titulo_noticia` varchar(45) NOT NULL,
  `fecha_publicacion_noticia` date DEFAULT NULL,
  `contenido_noticia` varchar(255) NOT NULL,
  `id_municipio` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notificacion`
--

CREATE TABLE `notificacion` (
  `id_notificacion` int(11) NOT NULL,
  `leida_notificacion` tinyint(1) NOT NULL,
  `contenido_notificacion` varchar(250) NOT NULL,
  `fecha_notificacion` datetime NOT NULL DEFAULT current_timestamp(),
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `notificacion`
--

INSERT INTO `notificacion` (`id_notificacion`, `leida_notificacion`, `contenido_notificacion`, `fecha_notificacion`, `id_usuario`) VALUES
(227, 1, 'Paúl Se ha inscrito a tu oferta Carniceria en Alcañiz', '2024-02-16 11:33:16', 1),
(229, 0, 'Paúl Se ha inscrito a tu oferta Carniceria en Alcañiz', '2024-02-16 11:33:16', 10),
(230, 1, 'Paúl Se ha inscrito a tu oferta Carniceria en Alcañiz', '2024-02-16 11:33:16', 13),
(231, 1, 'Se te ha eliminado a la entidad Entidad 1', '2024-02-16 11:33:16', 13),
(232, 0, 'Se te ha añadido a la entidad Entidad 1', '2024-02-16 11:33:16', 5),
(233, 1, 'Se te ha eliminado a la entidad Entidad 1', '2024-02-16 11:33:16', 1),
(235, 0, 'Paúl Se ha inscrito a tu oferta Carniceria en Alcañiz', '2024-02-16 11:33:16', 5),
(236, 0, 'Paúl Se ha inscrito a tu oferta Carniceria en Alcañiz', '2024-02-16 11:33:16', 10),
(238, 0, 'Paúl Se ha inscrito a tu oferta Carniceria en Alcañiz', '2024-02-16 11:33:16', 5),
(239, 0, 'Paúl Se ha inscrito a tu oferta Carniceria en Alcañiz', '2024-02-16 11:33:16', 10),
(240, 0, 'Se te ha eliminado a la entidad Entidad 1', '2024-02-16 11:33:16', 10),
(241, 0, 'Se te ha añadido a la entidad Entidad 1', '2024-02-16 11:33:16', 10),
(243, 0, 'Paúl Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-16 11:33:16', 13),
(246, 1, 'Se ha cambiado correctamente la información de tu perfil', '2024-02-19 08:21:43', 4),
(247, 1, 'Se ha cambiado correctamente la información de tu perfil', '2024-02-19 08:21:50', 4),
(248, 1, 'Se ha cambiado correctamente la información de tu perfil', '2024-02-19 08:21:53', 4),
(249, 1, 'Se ha cambiado correctamente la contraseña', '2024-02-19 08:22:52', 4),
(250, 1, 'Se ha cambiado correctamente la contraseña', '2024-02-19 08:23:10', 4),
(251, 0, 'Te han enviado un nuevo mensaje.', '2024-02-19 08:37:32', 13),
(252, 0, 'Te han enviado un nuevo mensaje. <a href=RUTA_URL/Chat>Ir al chat</a>', '2024-02-19 08:40:42', 13),
(253, 0, 'Te han enviado un nuevo mensaje. <a href=RUTA_URL/Chat>Ir al chat</a>', '2024-02-19 08:40:46', 13),
(256, 1, 'Te han enviado un nuevo mensaje. <a href=echo RUTA_URL/Chat>Ir al chat</a>', '2024-02-19 08:42:52', 4),
(259, 1, 'Te han enviado un nuevo mensaje. <a href=\'/Chat/index/\'>Ir al chat</a>', '2024-02-19 08:48:22', 4),
(260, 1, 'Te han enviado un nuevo mensaje. <a href=\'/Chat/index/2\'>Ir al chat</a>', '2024-02-19 08:50:41', 4),
(261, 1, 'Te han enviado un nuevo mensaje. <a href=\'/Chat/index/2\'>Ir al chat</a>', '2024-02-19 08:50:51', 4),
(263, 1, 'Te han enviado un nuevo mensaje. <a href=\'/Chat/index/2\'>Ir al chat</a>', '2024-02-19 09:08:36', 4),
(264, 1, 'Te han enviado un nuevo mensaje. <a href=\'/Chat/index/2\'>Ir al chat</a>', '2024-02-19 09:08:54', 4),
(265, 1, 'Te han enviado un nuevo mensaje. <a href=\'/Chat/index/2\'>Ir al chat</a>', '2024-02-19 09:09:15', 4),
(266, 1, 'Te han enviado un nuevo mensaje. <a href=\'/Chat/index/2\'>Ir al chat</a>', '2024-02-19 09:09:23', 4),
(267, 1, 'Se ha creado la entidad satisfactoriamente', '2024-02-19 09:15:36', 4),
(269, 0, 'Jesu Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 10:30:41', 13),
(271, 0, 'Jesu Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 10:30:54', 13),
(273, 0, 'Jesu Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 10:30:56', 13),
(275, 0, 'Jesu Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 10:45:47', 13),
(277, 0, 'Jesu Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 10:45:54', 13),
(279, 0, 'Jesu Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:08:51', 13),
(281, 0, 'Jesu Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:09:11', 13),
(283, 0, 'Jesu Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:11:55', 13),
(285, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:13:07', 13),
(287, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:13:23', 13),
(289, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:13:34', 13),
(291, 0, 'Paúl Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:15:38', 13),
(293, 0, 'Paúl Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:15:42', 13),
(295, 0, 'Jesu Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:15:58', 13),
(297, 0, 'Paúl Se ha inscrito a tu oferta Vivienda recién reformada', '2024-02-19 11:17:29', 5),
(298, 0, 'Paúl Se ha inscrito a tu oferta Vivienda recién reformada', '2024-02-19 11:17:29', 10),
(300, 0, 'Paúl Se ha inscrito a tu oferta Vivienda recién reformada', '2024-02-19 11:17:35', 5),
(301, 0, 'Paúl Se ha inscrito a tu oferta Vivienda recién reformada', '2024-02-19 11:17:35', 10),
(303, 0, 'Paúl Se ha inscrito a tu oferta Vivienda recién reformada', '2024-02-19 11:17:41', 5),
(304, 0, 'Paúl Se ha inscrito a tu oferta Vivienda recién reformada', '2024-02-19 11:17:41', 10),
(306, 0, 'Paúl Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:17:42', 13),
(308, 0, 'Paúl Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:17:44', 13),
(310, 0, 'Paúl Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:19:21', 13),
(312, 0, 'Paúl Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:19:23', 13),
(314, 0, 'Paúl Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:20:53', 13),
(316, 0, 'Paúl Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:20:57', 13),
(318, 0, 'Paúl Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 11:20:59', 13),
(320, 0, 'Paúl Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 11:24:36', 5),
(321, 0, 'Paúl Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 11:24:36', 10),
(323, 0, 'Paúl Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:24:41', 13),
(325, 0, 'Paúl Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:24:43', 13),
(327, 0, 'Paúl Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:25:07', 13),
(329, 0, 'Paúl Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 11:25:11', 5),
(330, 0, 'Paúl Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 11:25:11', 10),
(332, 0, 'Paúl Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:25:12', 13),
(334, 0, 'Paúl Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:25:28', 13),
(336, 0, 'Paúl Se ha inscrito a tu oferta Local sin negocio disponible para negocio y garaje.', '2024-02-19 11:25:37', 13),
(337, 1, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:08:12', 2),
(338, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:08:12', 13),
(339, 1, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:08:20', 2),
(340, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:08:20', 13),
(341, 1, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:52:29', 2),
(342, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:52:29', 13),
(343, 1, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:52:45', 2),
(344, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:52:45', 13),
(345, 1, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:53:51', 2),
(346, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:53:51', 13),
(347, 1, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 12:53:54', 2),
(348, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 12:53:54', 5),
(349, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 12:53:54', 10),
(350, 1, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 12:53:57', 2),
(351, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 12:53:57', 5),
(352, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 12:53:57', 10),
(353, 1, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:54:00', 2),
(354, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 12:54:00', 13),
(355, 1, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 12:54:01', 2),
(356, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 12:54:01', 5),
(357, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 12:54:01', 10),
(358, 1, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:00:06', 2),
(359, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:00:06', 13),
(360, 1, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:00:09', 2),
(361, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:00:09', 5),
(362, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:00:09', 10),
(363, 1, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:00:30', 2),
(364, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:00:30', 5),
(365, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:00:30', 10),
(366, 1, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:00:53', 2),
(367, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:00:53', 5),
(368, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:00:53', 10),
(369, 1, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:01:15', 2),
(370, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:01:15', 13),
(371, 1, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:02:08', 2),
(372, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:02:08', 13),
(373, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:03:55', 2),
(374, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:03:55', 13),
(375, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:10:55', 2),
(376, 0, 'Jesu Se ha inscrito a tu oferta Piso para estudiantes', '2024-02-19 13:10:55', 13),
(377, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:10:56', 2),
(378, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:10:56', 5),
(379, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:10:56', 10),
(380, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:12:01', 2),
(381, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:12:01', 5),
(382, 0, 'Jesu Se ha inscrito a tu oferta Alquilo piso', '2024-02-19 13:12:01', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oferta`
--

CREATE TABLE `oferta` (
  `id_oferta` int(11) NOT NULL,
  `titulo_oferta` varchar(80) DEFAULT NULL,
  `fecha_inicio_oferta` date DEFAULT current_timestamp(),
  `condiciones_oferta` varchar(100) DEFAULT NULL,
  `descripcion_oferta` varchar(250) DEFAULT NULL,
  `activo_oferta` tinyint(4) DEFAULT 1,
  `id_entidad` int(11) DEFAULT NULL,
  `tipo_oferta` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `oferta`
--

INSERT INTO `oferta` (`id_oferta`, `titulo_oferta`, `fecha_inicio_oferta`, `condiciones_oferta`, `descripcion_oferta`, `activo_oferta`, `id_entidad`, `tipo_oferta`) VALUES
(1, 'Piso para estudiantes', '2024-02-15', 'No fumar. No perros. No fiestas.', 'Piso grande, amueblado, cerca de universidad.', 1, 3, 'I'),
(2, 'Local sin negocio disponible para negocio y garaje.', '2024-02-15', 'hola', 'Precio no negociable', 1, 3, 'I'),
(3, 'Panadería Buen Pan en Venta / Traspaso', '2024-02-15', NULL, 'No hace falta reformar.', 1, 4, 'N'),
(4, 'Herreria en teruel', NULL, 'No entrar perros', 'la traspaso con todo el material necesario', 1, 1, 'N'),
(5, 'Alguacil el teruel', NULL, '', 'Lo paso porque me jubilo', 1, 1, 'N'),
(6, 'Panadería en Teruel', NULL, 'No entrar animales', 'Lo traspaso porque me jubilo', 1, 3, 'N'),
(7, 'Alquilo piso', '2024-02-19', '', '', 1, 1, 'N'),
(8, 'asdjt', '2024-02-19', '', '', 1, 7, 'N'),
(9, 'casa', '2024-02-19', '', '', 1, 1, 'N');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oferta_inmueble`
--

CREATE TABLE `oferta_inmueble` (
  `id_oferta` int(11) NOT NULL,
  `id_inmueble` int(11) NOT NULL,
  `precio` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `oferta_inmueble`
--

INSERT INTO `oferta_inmueble` (`id_oferta`, `id_inmueble`, `precio`) VALUES
(1, 1, 350),
(2, 2, 75),
(7, 5, 480),
(8, 6, 500),
(9, 7, 630);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `oferta_negocio`
--

CREATE TABLE `oferta_negocio` (
  `id_oferta` int(11) NOT NULL,
  `id_negocio` int(11) DEFAULT NULL,
  `precio_traspaso` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `oferta_negocio`
--

INSERT INTO `oferta_negocio` (`id_oferta`, `id_negocio`, `precio_traspaso`) VALUES
(3, 1, 18000),
(4, 2, 120000),
(5, 3, 20000),
(6, 4, 30000);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recuperar_pass`
--

CREATE TABLE `recuperar_pass` (
  `id_recuperar_password` int(11) NOT NULL,
  `email_recuperar` varchar(45) DEFAULT NULL,
  `fecha_hora_recuperar` datetime DEFAULT NULL,
  `hash` varchar(255) DEFAULT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE `rol` (
  `id_rol` int(11) NOT NULL,
  `nombre_rol` varchar(45) NOT NULL,
  `descripcion_rol` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id_rol`, `nombre_rol`, `descripcion_rol`) VALUES
(10, 'Usuario', 'Usuario genérico'),
(20, 'Administrador', 'Administrador de la página web');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `servicio`
--

CREATE TABLE `servicio` (
  `id_servicio` int(11) NOT NULL,
  `nombre_servicio` varchar(50) NOT NULL,
  `descripcion_servicio` varchar(255) DEFAULT NULL,
  `id_tipo_servicio` int(11) NOT NULL,
  `id_municipio` int(11) NOT NULL,
  `latitud_servicio` varchar(30) DEFAULT NULL,
  `longitud_servicio` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `servicio`
--

INSERT INTO `servicio` (`id_servicio`, `nombre_servicio`, `descripcion_servicio`, `id_tipo_servicio`, `id_municipio`, `latitud_servicio`, `longitud_servicio`) VALUES
(27, 'Centro', 'Aquí se encuentra el centro del pueblo', 1, 10, '40.345729180039235', '-1.106972998259481'),
(28, 'Panadería la nevera', 'Panadería local', 2, 10, '40.34644509806836', '-1.105170560423284'),
(29, 'Centro', 'Aquí se encuentra el centro del pueblo', 1, 11, '39.26717755962235', '-1.550692783611885'),
(30, 'Local', 'Local para comercio pequeño', 1, 11, '-1.550317989758635', '20'),
(31, 'Centro', 'Aquí se encuentra el centro del pueblo', 1, 12, '1', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_servicio`
--

CREATE TABLE `tipo_servicio` (
  `id_tipo_servicio` int(11) NOT NULL,
  `nombre_tipo_servicio` varchar(45) NOT NULL,
  `descripcion_tipo_servicio` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `tipo_servicio`
--

INSERT INTO `tipo_servicio` (`id_tipo_servicio`, `nombre_tipo_servicio`, `descripcion_tipo_servicio`) VALUES
(1, 'Localización', 'El centro del pueblo o ciudad'),
(2, 'Panadería', 'Panadería local donde se vende pan, bollería, etc..'),
(3, 'Turismo', 'Se utiliza para marcar donde se encuentra una localización para realizar turismo o una oficina');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `nif` varchar(15) NOT NULL,
  `nombre_usuario` varchar(50) NOT NULL,
  `apellidos_usuario` varchar(50) NOT NULL,
  `correo_usuario` varchar(100) NOT NULL,
  `contrasena_usuario` varchar(100) NOT NULL,
  `fecha_nacimiento_usuario` date NOT NULL,
  `telefono_usuario` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `nif`, `nombre_usuario`, `apellidos_usuario`, `correo_usuario`, `contrasena_usuario`, `fecha_nacimiento_usuario`, `telefono_usuario`) VALUES
(1, '54564478N', 'David', 'Martin Hernandez', 'davidmartinhernandez2003@gmail.com', '70ce1fdc9cb6f8f963fd9278edff60dad02006db9ca7c9dcdf86c6314352acfc', '2024-02-01', '4545647'),
(2, '21745016b', 'Paúl', 'uve', 'pol@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2003-12-07', '666555111'),
(4, '73229684F', 'Carlos', 'Baquero Soriano', 'carlosbaq24@gmail.com', '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67', '2000-10-17', '63339167'),
(5, '73104191W', 'Adrián', 'Pérez Correro', 'adriperezcaspe@gmail.com', '6b5227878fe232b191d290ae2da4008b80b91322272f0412bfaf37ecad116076', '1999-09-10', '642387475'),
(7, '73229684A', 'asd', 'asd', 'grillo@email.com', '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67', '2024-02-03', '2344324'),
(8, '73229684C', 'pruebaaa', 'pruebaaa', 'grilloA@email.com', '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67', '2024-02-01', '63339167'),
(10, '83242432F', 'Oscar', 'Blasco', 'oscar@oscar.es', '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67', '2024-03-01', '2344324'),
(11, '45345345A', 'Kike', 'Zaporta', 'asdasdasdasdasdas@gmail.com', '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67', '2024-02-01', '2344314'),
(12, '63134201Y', 'JOSE MANUEL', 'RODENAS', 'jrodenas@cpifpbajoaragon.com', 'ef797c8118f02dfb649607dd5d3f8c7623048c9c063d532cc95c5ed7a898a64f', '2222-02-22', '222222222'),
(13, '73104121W', 'Jesu', 'Jesu vahque', 'adri@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2024-01-30', '64578412'),
(15, '73221232G', 'prueba', 'prueba', 'oscar2@oscar.es', '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67', '2024-02-06', '2344324'),
(16, '73229222F', 'PRUEBA1234', 'PRUEBA1234', 'carlosbaq23@gmail.com', '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67', '2024-01-30', '63139167'),
(18, '73229222A', 'PRUEBA1231', 'PRUEBA3123', 'carlosbaq22@gmail.com', '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67', '2024-01-30', '6222291737'),
(19, '21745016c', 'pol2', '2', 'pol2@gmail.com', 'a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3', '2014-10-07', '321452102'),
(20, '73226123C', 'usuario', 'Prueba', 'usuarioPrueba@gmail.com', '60fe74406e7f353ed979f350f2fbb6a2e8690a5fa7d1b0c32983d1d8b3f95f67', '2024-02-08', '63333333');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_entidad`
--

CREATE TABLE `usuario_entidad` (
  `id_usuario` int(11) NOT NULL,
  `id_entidad` int(11) NOT NULL,
  `rol` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `usuario_entidad`
--

INSERT INTO `usuario_entidad` (`id_usuario`, `id_entidad`, `rol`) VALUES
(1, 4, 'Administrador'),
(1, 5, 'Administrador'),
(2, 1, 'Administrador'),
(2, 3, 'Administrador'),
(4, 7, 'Administrador'),
(4, 8, 'Administrador'),
(5, 1, 'Gerente'),
(5, 6, 'Administrador'),
(10, 1, 'Gerente'),
(13, 3, 'Gerente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_has_rol`
--

CREATE TABLE `usuario_has_rol` (
  `id_usuario` int(11) NOT NULL,
  `id_rol` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `usuario_has_rol`
--

INSERT INTO `usuario_has_rol` (`id_usuario`, `id_rol`) VALUES
(1, 20),
(2, 20),
(4, 20),
(5, 20),
(11, 10),
(13, 20),
(15, 10),
(16, 10),
(18, 10),
(19, 10),
(20, 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario_oferta`
--

CREATE TABLE `usuario_oferta` (
  `id_usuario` int(11) NOT NULL,
  `id_oferta` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `usuario_oferta`
--

INSERT INTO `usuario_oferta` (`id_usuario`, `id_oferta`) VALUES
(5, 1),
(5, 2),
(13, 1),
(13, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valorar_inmueble`
--

CREATE TABLE `valorar_inmueble` (
  `id_inmueble` int(11) NOT NULL,
  `fecha_valoracion_inm` date NOT NULL,
  `puntuacion_inm` int(11) NOT NULL,
  `descripcion_inm` varchar(250) DEFAULT NULL,
  `id_valorar_inmueble` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `valorar_negocio`
--

CREATE TABLE `valorar_negocio` (
  `id_usuario` int(11) NOT NULL,
  `id_negocio` int(11) NOT NULL,
  `puntuacion` int(11) NOT NULL,
  `descripcion` varchar(250) DEFAULT NULL,
  `fecha_valoracion` date NOT NULL,
  `id_valorar_negocio` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vivienda`
--

CREATE TABLE `vivienda` (
  `id_inmueble` int(11) NOT NULL,
  `habitaciones_vivienda` int(11) DEFAULT NULL,
  `tiene_garaje` tinyint(4) DEFAULT NULL,
  `banos` int(11) DEFAULT NULL,
  `tipo_vivienda` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Volcado de datos para la tabla `vivienda`
--

INSERT INTO `vivienda` (`id_inmueble`, `habitaciones_vivienda`, `tiene_garaje`, `banos`, `tipo_vivienda`) VALUES
(1, 5, 1, 2, 'Piso'),
(5, 4, 1, 1, 'Piso'),
(6, 23, 0, 23, 'sdfsf'),
(7, 4, 0, 2, 'Casa');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `aviso`
--
ALTER TABLE `aviso`
  ADD PRIMARY KEY (`id_aviso`),
  ADD KEY `fk_aviso_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `chatear`
--
ALTER TABLE `chatear`
  ADD PRIMARY KEY (`fecha_chat`,`id_usuario`,`id_usuario1`) USING BTREE,
  ADD KEY `fk_usuario_has_usuario_usuario2_idx` (`id_usuario1`),
  ADD KEY `fk_usuario_has_usuario_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `documento`
--
ALTER TABLE `documento`
  ADD PRIMARY KEY (`id_documento`),
  ADD KEY `fk_documento_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `entidad`
--
ALTER TABLE `entidad`
  ADD PRIMARY KEY (`id_entidad`),
  ADD UNIQUE KEY `cif_UNIQUE` (`cif_entidad`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
  ADD PRIMARY KEY (`id_estado`);

--
-- Indices de la tabla `imagen`
--
ALTER TABLE `imagen`
  ADD PRIMARY KEY (`id_imagen`),
  ADD KEY `fk_imagen_inmueble1_idx` (`id_inmueble`);

--
-- Indices de la tabla `inmueble`
--
ALTER TABLE `inmueble`
  ADD PRIMARY KEY (`id_inmueble`),
  ADD KEY `fk_modificada_inmueble` (`id_municipio`),
  ADD KEY `fk_modificada_inmueble_2` (`id_estado`);

--
-- Indices de la tabla `local`
--
ALTER TABLE `local`
  ADD PRIMARY KEY (`id_inmueble`);

--
-- Indices de la tabla `municipio`
--
ALTER TABLE `municipio`
  ADD PRIMARY KEY (`id_municipio`);

--
-- Indices de la tabla `negocio`
--
ALTER TABLE `negocio`
  ADD PRIMARY KEY (`id_negocio`),
  ADD KEY `fk_negocio` (`id_municipio_negocio`);

--
-- Indices de la tabla `negocio_local`
--
ALTER TABLE `negocio_local`
  ADD PRIMARY KEY (`id_negocio`,`id_inmueble`),
  ADD KEY `fk_modificada_negocio_local_2` (`id_inmueble`);

--
-- Indices de la tabla `noticia`
--
ALTER TABLE `noticia`
  ADD PRIMARY KEY (`id_noticia`),
  ADD KEY `fk_noticia_municipio1_idx` (`id_municipio`),
  ADD KEY `fk_noticia_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `notificacion`
--
ALTER TABLE `notificacion`
  ADD PRIMARY KEY (`id_notificacion`),
  ADD KEY `fk_notificacion_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `oferta`
--
ALTER TABLE `oferta`
  ADD PRIMARY KEY (`id_oferta`),
  ADD KEY `fk_modificada_oferta` (`id_entidad`);

--
-- Indices de la tabla `oferta_inmueble`
--
ALTER TABLE `oferta_inmueble`
  ADD PRIMARY KEY (`id_oferta`,`id_inmueble`),
  ADD KEY `fk_modificada_oferta_inmueble_2` (`id_inmueble`);

--
-- Indices de la tabla `oferta_negocio`
--
ALTER TABLE `oferta_negocio`
  ADD PRIMARY KEY (`id_oferta`),
  ADD KEY `fk_oferta_negocio` (`id_negocio`);

--
-- Indices de la tabla `recuperar_pass`
--
ALTER TABLE `recuperar_pass`
  ADD PRIMARY KEY (`id_recuperar_password`),
  ADD KEY `fk_recuperar_pass_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id_rol`);

--
-- Indices de la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD PRIMARY KEY (`id_servicio`),
  ADD KEY `fk_servicio_tipo_servicio1_idx` (`id_tipo_servicio`),
  ADD KEY `fk_servicio_municipio1_idx` (`id_municipio`);

--
-- Indices de la tabla `tipo_servicio`
--
ALTER TABLE `tipo_servicio`
  ADD PRIMARY KEY (`id_tipo_servicio`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `nif_UNIQUE` (`nif`),
  ADD UNIQUE KEY `correo_UNIQUE` (`correo_usuario`);

--
-- Indices de la tabla `usuario_entidad`
--
ALTER TABLE `usuario_entidad`
  ADD PRIMARY KEY (`id_usuario`,`id_entidad`),
  ADD KEY `fk_usuario_has_entidad_entidad1_idx` (`id_entidad`),
  ADD KEY `fk_usuario_has_entidad_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `usuario_has_rol`
--
ALTER TABLE `usuario_has_rol`
  ADD PRIMARY KEY (`id_usuario`,`id_rol`),
  ADD KEY `fk_usuario_has_rol_rol1_idx` (`id_rol`),
  ADD KEY `fk_usuario_has_rol_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `usuario_oferta`
--
ALTER TABLE `usuario_oferta`
  ADD PRIMARY KEY (`id_usuario`,`id_oferta`),
  ADD KEY `fk_usuario_has_oferta_oferta1_idx` (`id_oferta`),
  ADD KEY `fk_usuario_has_oferta_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `valorar_inmueble`
--
ALTER TABLE `valorar_inmueble`
  ADD PRIMARY KEY (`id_valorar_inmueble`),
  ADD KEY `fk_usuario_has_inmueble_inmueble1_idx` (`id_inmueble`),
  ADD KEY `fk_valorar_inmueble_usuario` (`id_usuario`);

--
-- Indices de la tabla `valorar_negocio`
--
ALTER TABLE `valorar_negocio`
  ADD PRIMARY KEY (`id_valorar_negocio`),
  ADD KEY `fk_usuario_has_negocio_negocio1_idx` (`id_negocio`),
  ADD KEY `fk_usuario_has_negocio_usuario1_idx` (`id_usuario`);

--
-- Indices de la tabla `vivienda`
--
ALTER TABLE `vivienda`
  ADD PRIMARY KEY (`id_inmueble`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `aviso`
--
ALTER TABLE `aviso`
  MODIFY `id_aviso` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `documento`
--
ALTER TABLE `documento`
  MODIFY `id_documento` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `entidad`
--
ALTER TABLE `entidad`
  MODIFY `id_entidad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `estado`
--
ALTER TABLE `estado`
  MODIFY `id_estado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `imagen`
--
ALTER TABLE `imagen`
  MODIFY `id_imagen` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `municipio`
--
ALTER TABLE `municipio`
  MODIFY `id_municipio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `noticia`
--
ALTER TABLE `noticia`
  MODIFY `id_noticia` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `notificacion`
--
ALTER TABLE `notificacion`
  MODIFY `id_notificacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=383;

--
-- AUTO_INCREMENT de la tabla `recuperar_pass`
--
ALTER TABLE `recuperar_pass`
  MODIFY `id_recuperar_password` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `servicio`
--
ALTER TABLE `servicio`
  MODIFY `id_servicio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT de la tabla `tipo_servicio`
--
ALTER TABLE `tipo_servicio`
  MODIFY `id_tipo_servicio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de la tabla `valorar_inmueble`
--
ALTER TABLE `valorar_inmueble`
  MODIFY `id_valorar_inmueble` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `valorar_negocio`
--
ALTER TABLE `valorar_negocio`
  MODIFY `id_valorar_negocio` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `aviso`
--
ALTER TABLE `aviso`
  ADD CONSTRAINT `fk_aviso_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `chatear`
--
ALTER TABLE `chatear`
  ADD CONSTRAINT `fk_usuario_has_usuario_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuario_has_usuario_usuario2` FOREIGN KEY (`id_usuario1`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `documento`
--
ALTER TABLE `documento`
  ADD CONSTRAINT `fk_documento_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `imagen`
--
ALTER TABLE `imagen`
  ADD CONSTRAINT `fk_imagen_inmueble1` FOREIGN KEY (`id_inmueble`) REFERENCES `inmueble` (`id_inmueble`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `inmueble`
--
ALTER TABLE `inmueble`
  ADD CONSTRAINT `fk_modificada_inmueble` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`),
  ADD CONSTRAINT `fk_modificada_inmueble_2` FOREIGN KEY (`id_estado`) REFERENCES `estado` (`id_estado`);

--
-- Filtros para la tabla `local`
--
ALTER TABLE `local`
  ADD CONSTRAINT `fk_modificada_local` FOREIGN KEY (`id_inmueble`) REFERENCES `inmueble` (`id_inmueble`);

--
-- Filtros para la tabla `negocio`
--
ALTER TABLE `negocio`
  ADD CONSTRAINT `fk_negocio` FOREIGN KEY (`id_municipio_negocio`) REFERENCES `municipio` (`id_municipio`);

--
-- Filtros para la tabla `negocio_local`
--
ALTER TABLE `negocio_local`
  ADD CONSTRAINT `fk_modificada_negocio_local` FOREIGN KEY (`id_negocio`) REFERENCES `negocio` (`id_negocio`),
  ADD CONSTRAINT `fk_modificada_negocio_local_2` FOREIGN KEY (`id_inmueble`) REFERENCES `local` (`id_inmueble`);

--
-- Filtros para la tabla `noticia`
--
ALTER TABLE `noticia`
  ADD CONSTRAINT `fk_noticia_municipio1` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_noticia_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `notificacion`
--
ALTER TABLE `notificacion`
  ADD CONSTRAINT `fk_notificacion_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `oferta`
--
ALTER TABLE `oferta`
  ADD CONSTRAINT `fk_modificada_oferta` FOREIGN KEY (`id_entidad`) REFERENCES `entidad` (`id_entidad`);

--
-- Filtros para la tabla `oferta_inmueble`
--
ALTER TABLE `oferta_inmueble`
  ADD CONSTRAINT `fk_modificada_oferta_inmueble` FOREIGN KEY (`id_oferta`) REFERENCES `oferta` (`id_oferta`),
  ADD CONSTRAINT `fk_modificada_oferta_inmueble_2` FOREIGN KEY (`id_inmueble`) REFERENCES `inmueble` (`id_inmueble`);

--
-- Filtros para la tabla `oferta_negocio`
--
ALTER TABLE `oferta_negocio`
  ADD CONSTRAINT `fk_oferta_negocio` FOREIGN KEY (`id_negocio`) REFERENCES `negocio` (`id_negocio`),
  ADD CONSTRAINT `fk_oferta_negocio_2` FOREIGN KEY (`id_oferta`) REFERENCES `oferta` (`id_oferta`);

--
-- Filtros para la tabla `recuperar_pass`
--
ALTER TABLE `recuperar_pass`
  ADD CONSTRAINT `fk_recuperar_pass_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `servicio`
--
ALTER TABLE `servicio`
  ADD CONSTRAINT `fk_servicio_municipio1` FOREIGN KEY (`id_municipio`) REFERENCES `municipio` (`id_municipio`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_servicio_tipo_servicio1` FOREIGN KEY (`id_tipo_servicio`) REFERENCES `tipo_servicio` (`id_tipo_servicio`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `usuario_entidad`
--
ALTER TABLE `usuario_entidad`
  ADD CONSTRAINT `fk_usuario_has_entidad_entidad1` FOREIGN KEY (`id_entidad`) REFERENCES `entidad` (`id_entidad`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuario_has_entidad_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `usuario_has_rol`
--
ALTER TABLE `usuario_has_rol`
  ADD CONSTRAINT `fk_usuario_has_rol_rol1` FOREIGN KEY (`id_rol`) REFERENCES `rol` (`id_rol`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuario_has_rol_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `usuario_oferta`
--
ALTER TABLE `usuario_oferta`
  ADD CONSTRAINT `fk_usuario_has_oferta_oferta1` FOREIGN KEY (`id_oferta`) REFERENCES `oferta` (`id_oferta`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuario_has_oferta_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `valorar_inmueble`
--
ALTER TABLE `valorar_inmueble`
  ADD CONSTRAINT `fk_usuario_has_inmueble_inmueble1` FOREIGN KEY (`id_inmueble`) REFERENCES `inmueble` (`id_inmueble`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_valorar_inmueble_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`);

--
-- Filtros para la tabla `valorar_negocio`
--
ALTER TABLE `valorar_negocio`
  ADD CONSTRAINT `fk_usuario_has_negocio_negocio1` FOREIGN KEY (`id_negocio`) REFERENCES `negocio` (`id_negocio`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_usuario_has_negocio_usuario1` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_valorar_negocio_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`);

--
-- Filtros para la tabla `vivienda`
--
ALTER TABLE `vivienda`
  ADD CONSTRAINT `fk_modificada_vivienda` FOREIGN KEY (`id_inmueble`) REFERENCES `inmueble` (`id_inmueble`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;