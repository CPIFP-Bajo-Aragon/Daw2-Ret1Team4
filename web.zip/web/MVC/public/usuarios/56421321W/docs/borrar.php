<?php
//Borrar carpeta
$carpeta=$_GET["opcion"];
rmdir("Directorio/".$carpeta);
header('Location: inicio.php');
?>

