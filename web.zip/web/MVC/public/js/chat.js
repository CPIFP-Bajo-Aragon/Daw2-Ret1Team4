document.addEventListener("DOMContentLoaded", function() {
   var element = document.getElementById("chat");
   element.scrollTop = element.scrollHeight; 
});



    // COMPROBAR MENSAJES CHAT 

    let valorMensajeChat = "";
    let mensaje_chat = document.getElementById("mensaje_chat");
    let botonEnviar = document.getElementById("botonEnviar");
    comprobarMensaje();

    function comprobarMensaje() {
        // EXPRESIÓN REGULAR PARA LOS ESPACIOS AL PRINCIPIO
        var regex = /^\s*$/;
    
        if (regex.test(valorMensajeChat)) {
            botonEnviar.disabled = true;
        } else {
            botonEnviar.disabled = false;
                // ENTER PARA MANDAR MENSAJE

                document.onkeydown=function(evt){
                    var keyCode = evt ? (evt.which ? evt.which : evt.keyCode) : event.keyCode;
                    if(keyCode == 13)
                    {
                        //your function call here
                        document.formChat.submit();
                    }
                }
        }
    }
    
      mensaje_chat.addEventListener("keyup", (event) => {
        valorMensajeChat = mensaje_chat.value;
        console.log(valorMensajeChat);
        comprobarMensaje();
      });
