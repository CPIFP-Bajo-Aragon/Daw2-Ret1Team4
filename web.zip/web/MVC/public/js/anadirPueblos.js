/* OPEN MODAL CAMBIAR INFORMACIÓN DEL PERFIL */

function openModalAnadirPueblo() {
    var modal = document.createElement('div');
    modal.className = 'modalCreate';
  
    var modalCard = document.createElement('div');
    modalCard.className = 'modalCard';

    // Titulo Card
    
    var titulo = document.createElement('h2');
    titulo.textContent = "Añadir pueblo";
    modalCard.appendChild(titulo);
  
    var closeButton = document.createElement('span');
    closeButton.className = 'closeButton';
    closeButton.innerHTML = '&times;';
    closeButton.onclick = closeModal;
    modalCard.appendChild(closeButton);
  
    var form = document.createElement('form');
    form.className = 'form-container';
    form.method = 'POST';
    form.action = '/Pueblos/anadirPueblos';
  
  
    // Nombre del pueblo
  
    var labelNombre = document.createElement('label');
    labelNombre.htmlFor = 'nombre';
    labelNombre.textContent = 'Nombre del pueblo:';
  
  
    var inputNombre = document.createElement('input');
    inputNombre.type = 'text';
    inputNombre.name = 'nombre_municipio';
    inputNombre.required = true;
    inputNombre.classList.add("form-control");
   
     // Provincia del municipio
  
     var labelProvincia = document.createElement('label');
     labelProvincia.htmlFor = 'provincia';
     labelProvincia.textContent = 'Provincia del municipio:';
   
   
     var inputProvincia = document.createElement('input');
     inputProvincia.type = 'text';
     inputProvincia.name = 'provincia_municipio';
     inputProvincia.required = true;
     inputProvincia.classList.add("form-control");
  
     // Código postal
  
      var labelCodPostal = document.createElement('label');
      labelCodPostal.htmlFor = 'codPostal';
      labelCodPostal.textContent = 'Código postal:';
    

      var inputCodPostal = document.createElement('input');
      inputCodPostal.type = 'text';
      inputCodPostal.name = 'codigo_postal_municipio';
      inputCodPostal.required = true;
      inputCodPostal.classList.add("form-control");

      
       // Latitud Servicio
  
      var labelLatitud = document.createElement('label');
      labelLatitud.htmlFor = 'latitud';
      labelLatitud.textContent = 'Latitud:';
  
  
      var inputLatitud = document.createElement('input');
      inputLatitud.type = 'text';
      inputLatitud.name = 'latitud_municipio';
      inputLatitud.required = true;
      inputLatitud.classList.add("form-control");

       // Longitud Servicio
  
      var labelLongitud = document.createElement('label');
      labelLongitud.htmlFor = 'longitud';
      labelLongitud.textContent = 'Longitud:';
  
  
      var inputLongitud = document.createElement('input');
      inputLongitud.type = 'text';
      inputLongitud.name = 'longitud_municipio';
      inputLongitud.required = true;
      inputLongitud.classList.add("form-control");

    // APPENDCHILDS

    form.appendChild(labelNombre);
    form.appendChild(inputNombre);
    form.appendChild(labelProvincia);
    form.appendChild(inputProvincia);
    form.appendChild(labelCodPostal);
    form.appendChild(inputCodPostal);
    form.appendChild(labelLatitud);
    form.appendChild(inputLatitud);
    form.appendChild(labelLongitud);
    form.appendChild(inputLongitud);

  
  
  
    var submitButton = document.createElement('input');
    submitButton.type = 'submit';
    submitButton.value = 'Guardar cambios';
    submitButton.classList.add("btn", "btn-primary");
    form.appendChild(submitButton);
  
    modalCard.appendChild(form);
    modal.appendChild(modalCard);
  
    var modalContainer = document.getElementById('modal-container');
    modalContainer.innerHTML = '';
    modalContainer.appendChild(modal);
  
    modal.style.display = 'block';
  }
  


  // VALIDAR, CERRAR, ETC...
  
  function closeModal() {
    var modalContainer = document.getElementById('modal-container');
    modalContainer.innerHTML = '';
  }
  