function PaginaTabla(a, nPag = 0, resultados = a.length, id) {
    let numeroResultados = a.length;
    let resultadosPorPagina = resultados;
    let numeroPaginas = numeroResultados / resultadosPorPagina;
    let paginaActual = nPag;


    let table = document.createElement("table");
    table.className = "table table-hover";
    let thead = document.createElement("thead");
    let trHead = document.createElement("tr");

    let columnasLong = a[0].toColumn.length;
    for (i = 0; i < columnasLong; i++) {
        let thHead = document.createElement("th");
        thHead.setAttribute("scope", "col");
        thHead.textContent = a[0].toColumn[i];
        trHead.appendChild(thHead);
    }

    thead.appendChild(trHead);
    table.appendChild(thead);

    let tbody = document.createElement("tbody");
    tbody.className = "table-group-divider";

    for (i = 0 + (resultadosPorPagina * paginaActual); i < (resultadosPorPagina * paginaActual) + resultadosPorPagina; i++) {
        let tr = document.createElement("tr");
        for (j = 0; j < columnasLong; j++)
            if (j == 0) {
                let th = document.createElement("th");
                th.setAttribute("scope", "row");
                th.textContent = i + 1;
                tr.appendChild(th);
            } else {
                let td = document.createElement("td");
                td.textContent = a[i].toArray[j];
                tr.appendChild(td);
            }
        tbody.appendChild(tr);
    }
    table.appendChild(tbody);

    let numeros = document.createElement("div");

    for (i = 0; i < numeroPaginas; i++) {
        let p = document.createElement("a");
        p.textContent = i + 1;
        p.id = i;
        p.className = "page-number";
        p.addEventListener("click", function () {
            document.getElementById(id).innerHTML = "";
            PaginaTabla(a, p.id, resultados, id);
        })
        numeros.appendChild(p);
    }

    let contenedor = document.getElementById(id);
    contenedor.appendChild(table);
    contenedor.appendChild(numeros);
}

function PaginaTarjeta(a, nPag = 0, resultados = a.length, id) {
    let numeroResultados = a.length;
    let resultadosPorPagina = resultados;
    let numeroPaginas = numeroResultados / resultadosPorPagina;
    let paginaActual = nPag;

    for (i = 0 + (resultadosPorPagina * paginaActual); i < (resultadosPorPagina * paginaActual) + resultadosPorPagina; i++) {
        let tarjeta = document.createElement("div");
        tarjeta.className = "card m-5";

        let tarjetaBody = document.createElement("div");
        tarjetaBody.className = "card-body";

        let tarjetaTitulo = document.createElement("h5");
        tarjetaTitulo.className = "card-title";
        tarjetaTitulo.textContent = a[i].titulo;

        let tarjetaDescripcion = document.createElement("p");
        tarjetaDescripcion.className = "card-text";
        tarjetaDescripcion.textContent = a[i].descripcion;

        let accionTarjeta = document.createElement("a");
        accionTarjeta.className = "btn btn-primary";
        accionTarjeta.setAttribute("href", "#");
        accionTarjeta.textContent = "Ir a (yo que se macho)";

        tarjetaBody.appendChild(tarjetaTitulo);
        tarjetaBody.appendChild(tarjetaDescripcion);
        tarjetaBody.appendChild(accionTarjeta);

        tarjeta.appendChild(tarjetaBody);

        document.getElementById(id).appendChild(tarjeta);
    }

    for (i = 0; i < numeroPaginas; i++) {
        let p = document.createElement("a");
        p.textContent = i + 1;
        p.id = i;
        p.className = "page-number";
        p.addEventListener("click", function () {
            document.getElementById(id).innerHTML = "";
            PaginaTarjeta(a, p.id, resultados, id);
        })

        document.getElementById(id).appendChild(p);
    }
}