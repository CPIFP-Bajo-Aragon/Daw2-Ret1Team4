function Vivienda(id, id_inmueble, precio, tipo_vivienda, direccion, banos, garaje, habitaciones, estado, descripcion, fecha, tipo_inmueble, superficie, inscrito, municipio) {
    this.tipo = "V";
    this.id_inmueble = id_inmueble;
    this.id = id;
    this.precio = precio;
    this.tipo_vivienda = tipo_vivienda;
    this.direccion = " " + direccion;
    this.banos = banos;
    if (garaje == 1) {
        this.garaje = "incluye garaje";
    } else {
        this.garaje = "sin garaje";
    }
    this.habitaciones = habitaciones;
    this.estado = estado;
    this.descripcion = descripcion;

    this.tipo_inmueble = "Vivienda";
    this.superficie = superficie;

    let hoy = new Date(Date.now());
    let pub = new Date(fecha);
    this.municipio = municipio;

    this.fecha = "Hace " + Math.trunc(((((hoy - pub) / 1000) / 60) / 60) / 24) + " días";
    this.inscrito = inscrito;
    this.dias = Math.trunc(((((hoy - pub) / 1000) / 60) / 60) / 24);

}

function Local(id_oferta, id_inmueble, precio, tipo_inmueble, direccion, aforo, estado, descripcion, fecha, superficie, inscrito, municipio, recursos) {
    this.tipo = "L";
    this.id_inmueble = id_inmueble;
    this.id_oferta = id_oferta;
    this.precio = precio;
    this.direccion = " " + direccion;
    this.aforo = aforo;

    this.estado = estado;
    this.descripcion = descripcion;
    this.recursos = recursos;
    this.superficie = superficie;
    this.municipio = municipio;

    let hoy = new Date(Date.now());
    let pub = new Date(fecha);

    fecha = "Hace " + Math.trunc(((((hoy - pub) / 1000) / 60) / 60) / 24) + " días";
    if (fecha > 31) {
        this.fecha = "Hace más de un mes...";
    } else {
        this.fecha = fecha;
    }
    this.inscrito = inscrito;
    this.dias = Math.trunc(((((hoy - pub) / 1000) / 60) / 60) / 24);
}

function Negocio(id_oferta, id_inmueble, titulo, descripcion, nombre, traspaso, gastos, fecha, aforo, recursos, inscrito, superficie, descripcion_inmueble, direccion, municipio) {
    this.tipo = "N";
    this.id_oferta = id_oferta;
    this.id_inmueble = id_inmueble;
    this.titulo = titulo;
    this.nombre = nombre;
    this.traspaso = traspaso;
    this.gastos = gastos;
    this.fecha = fecha;
    this.aforo = aforo;
    this.recursos = recursos;
    this.descripcion = descripcion;
    this.superficie = superficie;
    this.descripcion_inmueble = descripcion_inmueble;
    this.direccion = direccion;
    this.municipio = municipio;

    let hoy = new Date(Date.now());
    let pub = new Date(fecha);

    fecha = "Hace " + Math.trunc(((((hoy - pub) / 1000) / 60) / 60) / 24) + " días";
    if (fecha > 31) {
        this.fecha = "Hace más de un mes...";
    } else {
        this.fecha = fecha;
    }
    this.inscrito = inscrito;
    // this.ruta = descargaImagenes(this.id_inmueble);
    this.dias = Math.trunc(((((hoy - pub) / 1000) / 60) / 60) / 24);

}

async function descargaImagenes(id_inmueble) {
    let array = [];
    try {
        let responseRutas = await fetch('https://' + ip + '/Ofertas/apiRutas/' + id_inmueble);
        let dataRutas = await responseRutas.json();

        dataRutas.forEach(e => {
            array.push(e);
        });

        return array;

    } catch (error) {
        console.error('Error:', error);
    }
}

async function descargaDatosAsync() {
    let arrayOfertas = [];
    try {
        let responseNegocios = await fetch('https://' + ip + '/Ofertas/apiNegocios');
        let dataNegocios = await responseNegocios.json();

        let responseLocales = await fetch('https://' + ip + '/Ofertas/apiLocales');
        let dataLocales = await responseLocales.json();

        let responseViviendas = await fetch('https://' + ip + '/Ofertas/apiViviendas');
        let dataViviendas = await responseViviendas.json();

        dataViviendas.forEach(e => {
            let obj = new Vivienda(e.id_oferta, e.id_inmueble, e.precio, e.tipo_vivienda, e.direccion_inmueble, e.banos, e.tiene_garaje, e.habitaciones_vivienda, e.id_estado, e.descripcion_inmueble, e.fecha_inicio_oferta, e.tipo_inmueble, e.metros_cuadrados_inmueble, e.inscrito, e.nombre_municipio);
            arrayOfertas.push(obj);
        });

        dataLocales.forEach(e => {
            obj = new Local(e.id_oferta, e.id_inmueble, e.precio, e.tipo_inmueble, e.direccion_inmueble, e.aforo, e.id_estado, e.descripcion_inmueble, e.fecha_inicio_oferta, e.metros_cuadrados_inmueble, e.inscrito, e.nombre_municipio, e.recursos);
            arrayOfertas.push(obj);
        });

        dataNegocios.forEach(e => {
            obj = new Negocio(e.id_oferta, e.id_inmueble, e.titulo_oferta, e.descripcion_oferta, e.titulo_negocio, e.precio_traspaso, e.coste_mensual_negocio, e.fecha_inicio_oferta, e.aforo, e.recursos, e.inscrito, e.metros_cuadrados_inmueble, e.descripcion_inmueble, e.direccion_inmueble, e.nombre_municipio);
            arrayOfertas.push(obj);
        });



        return arrayOfertas;
    } catch (error) {
        console.error('Error:', error);
    }
}


// -------- COMIENZO SCRIPT --------- //
var paginaActual = 0;
var resultadosPorPagina = 20;
var datosDescargados = [];
var arrayFiltrado = [];


document.addEventListener("DOMContentLoaded", function () {
    carga();
});

function carga() {
    document.getElementById("holder").innerHTML = "";
    descargaDatosAsync(paginaActual, resultadosPorPagina)
        .then(e => {
            datosDescargados = e;
            construyePagina(datosDescargados);
            console.log(e)
        })


    }


    function construyePagina(e) {
        document.getElementById("holder").innerHTML = "";        
        document.getElementById("numbers").innerHTML = "";  

        // e = arrayFiltrado;
        let numeroPaginas = e.length / resultadosPorPagina;
        for (i = 0; i < numeroPaginas; i++) {
            let p = document.createElement("button");
            p.textContent = i + 1;
            p.id = i;
            if (i == 0) {
                p.className = "selected btn btn-success m-2";
            } else {
                p.className = "selected btn btn-outline-success m-2";
            }
            p.addEventListener("click", function () {
                let buttons = document.querySelectorAll("button.selected");
                console.log(buttons)
                buttons.forEach(e => {
                    e.className = "selected btn btn-outline-success m-2";
                })
                this.className = "selected btn btn-success m-2";
                paginaActual = p.id;
                pagina(paginaActual, resultadosPorPagina);
            })

            document.getElementById("numbers").appendChild(p);
        }

        try {
            for (i = 0 + (resultadosPorPagina * paginaActual); i < (resultadosPorPagina * paginaActual) + resultadosPorPagina; i++) {
                element = e[i];
                if (element.tipo == "L") {
                    CreaLocal(element);
                } else if (element.tipo == "V") {
                    CreaVivienda(element);
                } else if (element.tipo == "N") {
                    CreaNegocio(element);
                }
            }
        } catch {

        }

        function pagina(paginaActual, resultadosPorPagina) {
            try {
                // console.log(paginaActual);
                document.getElementById("holder").innerHTML = "";
                for (i = 0 + (resultadosPorPagina * paginaActual); i < (resultadosPorPagina * paginaActual) + resultadosPorPagina; i++) {
                    element = e[i];
                    if (element.tipo == "L") {
                        CreaLocal(element);
                    } else if (element.tipo == "V") {
                        CreaVivienda(element);
                    } else if (element.tipo == "N") {
                        CreaNegocio(element);
                    }
                }
            } catch {

            }
        }
    }

    function returnArrayFiltrado(a) {
        console.log(datosDescargados);    
    }

function CreaVivienda(v) {
    let ruta = "https://" + ip + "/Ofertas/Vivienda/" + v.id;

    let div = e("div", "card mt-3 rounded-3");

    let row1 = e("div", "row no-gutters rounded-3");
    let col1 = e("div", "col-md-4 rounded-3")
    let colImg = e("div", "carousel slide");
    colImg.id = "carouselExampleControls" + v.id_inmueble;
    colImg.setAttribute("data-bs-ride", "carousel");

    let divCa = e("div", "carousel-inner");
    descargaImagenes(v.id_inmueble)
        .then(data => {
            for (let i = 0; i < data.length; i++) {
                if (i == 0) {
                    let item = e("div", "carousel-item active");
                    let img = e("img", "rounded-3 tarjetaOferta");
                    img.setAttribute("src", data[i]);
                    a(item, img);
                    a(divCa, item);
                } else {
                    let item = e("div", "carousel-item");
                    let img = e("img", "rounded-3 tarjetaOferta");
                    img.setAttribute("src", data[i]);
                    a(item, img);
                    a(divCa, item);
                }
            }
        })

    let btn1Ca = e("button", "carousel-control-prev");
    btn1Ca.setAttribute("type", "button");
    btn1Ca.setAttribute("data-bs-target", "#carouselExampleControls" + v.id_inmueble);
    btn1Ca.setAttribute("data-bs-slide", "prev");
    let btn1CaSpan = e("span", "carousel-control-prev-icon");
    btn1CaSpan.setAttribute("aria-hidden", "true");
    let btn1CaSpan1 = e("span", "visually-hidden", "Previous");
    a(btn1Ca, btn1CaSpan);
    a(btn1Ca, btn1CaSpan1);

    let btn2Ca = e("button", "carousel-control-next");
    btn2Ca.setAttribute("type", "button");
    btn2Ca.setAttribute("data-bs-target", "#carouselExampleControls" + v.id_inmueble);
    btn2Ca.setAttribute("data-bs-slide", "next");
    let btn2CaSpan = e("span", "carousel-control-next-icon");
    btn2CaSpan.setAttribute("aria-hidden", "true");
    let btn2CaSpan1 = e("span", "visually-hidden", "Next");
    a(btn2Ca, btn2CaSpan);
    a(btn2Ca, btn2CaSpan1);

    a(colImg, divCa);
    a(colImg, btn1Ca);
    a(colImg, btn2Ca);


    a(col1, colImg);
    let colBody = e("div", "col-md-6");
    let cardBody = e("div", "card-body");
    let cardTitle = e("h3", "card-title");
    let cardTitleBold = e("b", "", v.precio + " ");
    let cardTitleSmall = e("small", "text-muted", "€/mes");
    a(cardTitle, cardTitleBold);
    a(cardTitle, cardTitleSmall);

    let cardText1 = e("p", "card-text");
    let cardText1Bold = e("b", "", v.tipo_vivienda);
    a(cardText1, cardText1Bold);
    let cardText1Normal = e("span", "", v.direccion);
    a(cardText1, cardText1Normal);
    let cardText2 = e("p", "card-text");
    let cardText2Small = e("small", "", v.habitaciones + " habs · " + v.banos + " baños · " + v.superficie + "m² · " + v.garaje)
    a(cardText2, cardText2Small);
    let cardText3 = e("p", "card-text");
    let cardText3Normal = e("span", "", v.descripcion + " - ... ")
    a(cardText3, cardText3Normal);
    let cardText3A = e("a", "leer", "Leer más...")
    cardText3A.href = ruta;
    cardText3A.style.color = "#CE7106";
    a(cardText3, cardText3A);
    let cardText4 = e("p", "card-text");
    let cardText4Small = e("small", "text-muted", v.fecha);
    a(cardText4, cardText4Small);


    a(cardBody, cardTitle);
    a(cardBody, cardText1);
    a(cardBody, cardText2);
    a(cardBody, cardText3);
    a(cardBody, cardText4);

    a(colBody, cardBody);

    a(row1, col1);
    a(row1, colBody);
    let colBoton = CreaBotones(v.id, v.inscrito);
    a(row1, colBoton);

    a(div, row1);
    document.getElementById("holder").appendChild(div);

    function CreaBotones(id, inscrito) {
        let contenedor = e("div", "col d-flex flex-column justify-content-between p-3");
        let contenedorRow = e("div", "row h-100 flex-md-column justify-content-between p-2");
        let rowIconos = e("div", "row justify-content-end");
        let btnInfo = e("a", "btn col-6 ml-3");
        btnInfo.style.border = "none";
        btnInfo.style.color = "#CE7106";
        btnInfo.style.backgroundColor = "white";
        btnInfo.id = "iBS0";
        btnInfo.href = ruta;

        let iconInfo = e("i", "bi bi-info-circle-fill", "");
        let btnDots = e("button", "btn col-6");
        btnDots.style.border = "none";
        btnDots.style.color = "#CE7106";
        btnDots.style.backgroundColor = "white";
        btnDots.id = "iBS0";
        let iconDots = e("i", "bi bi-three-dots");
        
        let btnCheck;
        if (inscrito) {
            btnCheck = e("button", "d-grid btn align-items-center");
            btnCheck.style.border = "2px solid #CE7106";
            btnCheck.style.color = "white";
            btnCheck.style.backgroundColor = "#CE7106";
        } else {
            btnCheck = e("button", "d-grid btn align-items-center");
            btnCheck.style.border = "2px solid #CE7106";
            btnCheck.style.color = "#CE7106";
            btnCheck.style.backgroundColor = "white";
        }
        btnCheck.setAttribute("data-id", id);
        let btnSpan = e("span", "");

        let iconCheck;
        let smallCheck = e("small", "", "");

        let bSmallCheck;
        if (inscrito) {
            iconCheck = e("i", "bi bi-check2 d-md-none d-lg-inline");
            bSmallCheck = e("b", "", " INSCRITO");
        } else {
            iconCheck = e("i", "d-none bi bi-check2");
            bSmallCheck = e("b", "", " INSCRIBIR")
        }

        btnCheck.addEventListener("click", function () {
            if (!inscrito) {
                fetch("https://" + ip + "/Ofertas/inscribirseOferta/" + id)
                    .then(response => response.json())
                    .then(data => {
                        if (data) {
                            btnCheck.className = "d-grid btn align-items-center";
                            btnCheck.style.border = "2px solid #CE7106";
                            btnCheck.style.color = "white";
                            btnCheck.style.backgroundColor = "#CE7106";
                            btnCheck.style.boxShadow = "none";
                            bSmallCheck.textContent = " " + "INSCRITO";
                            iconCheck.className = "bi bi-check2 d-md-none d-lg-inline";
                            inscrito = 1;
                        }
                    })
            } else {
                if (confirm("¿Deseas eliminar la inscripción a esta oferta?") == true) {
                    fetch("https://" + ip + "/Ofertas/cancelarInscripcionOferta/" + id)
                        .then(response => response.json())
                        .then(data => {
                            if (data) {
                                // cambia estilo
                                btnCheck.className = "d-grid btn align-items-center";
                                btnCheck.style.border = "2px solid #CE7106";
                                btnCheck.style.color = "#CE7106";
                                btnCheck.style.backgroundColor = "white";
                                btnCheck.style.boxShadow = "none";
                                bSmallCheck.textContent = " " + "INSCRIBIR";
                                iconCheck.className = "d-none bi bi-check2";
                                inscrito = 0;
                            }
                        })
                }
            }
        })

        if(usuarioSesion == 0) {
            btnCheck.setAttribute("class", "d-none");
        }

        a(smallCheck, bSmallCheck);
        a(btnSpan, iconCheck);
        a(btnSpan, smallCheck);
        a(btnCheck, btnSpan);
        a(btnDots, iconDots);
        a(btnInfo, iconInfo);
        a(rowIconos, btnInfo);
        a(rowIconos, btnDots);
        a(contenedorRow, rowIconos);
        a(contenedorRow, btnCheck);
        a(contenedor, contenedorRow);
        return contenedor;
    }

    function a(i, j) {
        i.appendChild(j);
    }

    function e(m, n, t = null) {
        var elemento = document.createElement(m);
        elemento.className = n;
        elemento.textContent = t;
        return elemento;
    }
}

function CreaNegocio(v) {
    let ruta = "https://" + ip + "/Ofertas/Vivienda/" + v.id_inmueble;

    let div = e("div", "card mt-3 rounded-3");
    let row1 = e("div", "row no-gutters rounded-3");
    let col1 = e("div", "col-md-4 rounded-3")
    let colImg = e("div", "carousel slide");
    colImg.id = "carouselExampleControls" + v.id_inmueble;
    colImg.setAttribute("data-bs-ride", "carousel");

    let divCa = e("div", "carousel-inner");
    descargaImagenes(v.id_inmueble)
        .then(data => {
            for (let i = 0; i < data.length; i++) {
                if (i == 0) {
                    let item = e("div", "carousel-item active");
                    let img = e("img", "rounded-3 tarjetaOferta");
                    img.setAttribute("src", data[i]);
                    a(item, img);
                    a(divCa, item);
                } else {
                    let item = e("div", "carousel-item");
                    let img = e("img", "rounded-3 tarjetaOferta");
                    img.setAttribute("src", data[i]);
                    a(item, img);
                    a(divCa, item);
                }
            }
        })

    let btn1Ca = e("button", "carousel-control-prev");
    btn1Ca.setAttribute("type", "button");
    btn1Ca.setAttribute("data-bs-target", "#carouselExampleControls" + v.id_inmueble);
    btn1Ca.setAttribute("data-bs-slide", "prev");
    let btn1CaSpan = e("span", "carousel-control-prev-icon");
    btn1CaSpan.setAttribute("aria-hidden", "true");
    let btn1CaSpan1 = e("span", "visually-hidden", "Previous");
    a(btn1Ca, btn1CaSpan);
    a(btn1Ca, btn1CaSpan1);

    let btn2Ca = e("button", "carousel-control-next");
    btn2Ca.setAttribute("type", "button");
    btn2Ca.setAttribute("data-bs-target", "#carouselExampleControls" + v.id_inmueble);
    btn2Ca.setAttribute("data-bs-slide", "next");
    let btn2CaSpan = e("span", "carousel-control-next-icon");
    btn2CaSpan.setAttribute("aria-hidden", "true");
    let btn2CaSpan1 = e("span", "visually-hidden", "Next");
    a(btn2Ca, btn2CaSpan);
    a(btn2Ca, btn2CaSpan1);

    a(colImg, divCa);
    a(colImg, btn1Ca);
    a(colImg, btn2Ca);


    a(col1, colImg);
    let colBody = e("div", "col-md-6");
    let cardBody = e("div", "card-body");
    let cardTitle = e("h3", "card-title");
    let cardTitleBold = e("b", "", v.titulo + " ");
    let cardTitleSmall = e("small", "blockquote-footer", " " + v.nombre);
    a(cardTitle, cardTitleBold);
    a(cardTitle, cardTitleSmall);

    let cardText1 = e("p", "card-text");
    let cardText1Bold = e("b", "", v.tipo_vivienda);
    a(cardText1, cardText1Bold);
    let cardText1Normal = e("span", "", "TRASPASO: " + v.traspaso + "€");
    a(cardText1, cardText1Normal);
    let cardText2 = e("p", "card-text");
    let cardText2Small = e("small", "", v.direccion + " (" + v.municipio + ")");
    a(cardText2, cardText2Small);
    let cardText21 = e("p", "card-text");
    let cardText21Small = e("small", "", "Aforo: " + v.aforo + " · Gastos Mensuales: " + v.gastos + "€ · " + v.superficie + "m²")
    a(cardText21, cardText21Small);
    let cardText3 = e("p", "card-text");
    let cardText3Normal = e("span", "", v.descripcion + " - ... ")
    a(cardText3, cardText3Normal);
    let cardText3A = e("a", "leer", "Leer más...")
    cardText3A.href = ruta;
    cardText3A.style.color = "#CE7106";
    a(cardText3, cardText3A);
    let cardText4 = e("p", "card-text");
    let cardText4Small = e("small", "text-muted", v.fecha);
    a(cardText4, cardText4Small);


    a(cardBody, cardTitle);
    a(cardBody, cardText1);
    a(cardBody, cardText2);
    a(cardBody, cardText21);
    a(cardBody, cardText3);
    a(cardBody, cardText4);

    a(colBody, cardBody);

    a(row1, col1);
    a(row1, colBody);
    let colBoton = CreaBotones(v.id_oferta, v.inscrito);
    a(row1, colBoton);

    a(div, row1);
    document.getElementById("holder").appendChild(div);

    function CreaBotones(id, inscrito) {
        let contenedor = e("div", "col d-flex flex-column justify-content-between p-3");
        let contenedorRow = e("div", "row h-100 flex-md-column justify-content-between p-2");
        let rowIconos = e("div", "row justify-content-end");
        let btnInfo = e("a", "btn col-6 ml-3");
        btnInfo.style.border = "none";
        btnInfo.style.color = "#CE7106";
        btnInfo.style.backgroundColor = "white";
        btnInfo.id = "iBS0";
        btnInfo.href = ruta;

        let iconInfo = e("i", "bi bi-info-circle-fill", "");
        let btnDots = e("button", "btn col-6");
        btnDots.style.border = "none";
        btnDots.style.color = "#CE7106";
        btnDots.style.backgroundColor = "white";
        btnDots.id = "iBS0";
        let iconDots = e("i", "bi bi-three-dots");
        let btnCheck;
        if (inscrito) {
            btnCheck = e("button", "d-grid btn align-items-center");
            btnCheck.style.border = "2px solid #CE7106";
            btnCheck.style.color = "white";
            btnCheck.style.backgroundColor = "#CE7106";
        } else {
            btnCheck = e("button", "d-grid btn align-items-center");
            btnCheck.style.border = "2px solid #CE7106";
            btnCheck.style.color = "#CE7106";
            btnCheck.style.backgroundColor = "white";
        }
        btnCheck.setAttribute("data-id", id);
        let btnSpan = e("span", "");

        let iconCheck;
        let smallCheck = e("small", "", "");

        let bSmallCheck;
        if (inscrito) {
            iconCheck = e("i", "bi bi-check2 d-md-none d-lg-inline");
            bSmallCheck = e("b", "", " INSCRITO");
        } else {
            iconCheck = e("i", "d-none bi bi-check2");
            bSmallCheck = e("b", "", " INSCRIBIR")
        }

        btnCheck.addEventListener("click", function () {
            if (!inscrito) {
                fetch("https://" + ip + "/Ofertas/inscribirseOferta/" + id)
                    .then(response => response.json())
                    .then(data => {
                        if (data) {
                            btnCheck.className = "d-grid btn align-items-center";
                            btnCheck.style.border = "2px solid #CE7106";
                            btnCheck.style.color = "white";
                            btnCheck.style.backgroundColor = "#CE7106";
                            btnCheck.style.boxShadow = "none";
                            bSmallCheck.textContent = " " + "INSCRITO";
                            iconCheck.className = "bi bi-check2 d-md-none d-lg-inline";
                            inscrito = 1;
                        }
                    })
            } else {
                if (confirm("¿Deseas eliminar la inscripción a esta oferta?") == true) {
                    fetch("https://" + ip + "/Ofertas/cancelarInscripcionOferta/" + id)
                        .then(response => response.json())
                        .then(data => {
                            if (data) {
                                // cambia estilo
                                btnCheck.className = "d-grid btn align-items-center";
                                btnCheck.style.border = "2px solid #CE7106";
                                btnCheck.style.color = "#CE7106";
                                btnCheck.style.backgroundColor = "white";
                                btnCheck.style.boxShadow = "none";
                                bSmallCheck.textContent = " " + "INSCRIBIR";
                                iconCheck.className = "d-none bi bi-check2";
                                inscrito = 0;
                            }
                        })
                }
            }
        })

        if(usuarioSesion == 0) {
            btnCheck.setAttribute("class", "d-none");
        }

        a(smallCheck, bSmallCheck);
        a(btnSpan, iconCheck);
        a(btnSpan, smallCheck);
        a(btnCheck, btnSpan);
        a(btnDots, iconDots);
        a(btnInfo, iconInfo);
        a(rowIconos, btnInfo);
        a(rowIconos, btnDots);
        a(contenedorRow, rowIconos);
        a(contenedorRow, btnCheck);
        a(contenedor, contenedorRow);
        return contenedor;
    }

    function a(i, j) {
        i.appendChild(j);
    }

    function e(m, n, t = null) {
        var elemento = document.createElement(m);
        elemento.className = n;
        elemento.textContent = t;
        return elemento;
    }
}

function CreaLocal(v) {
    let ruta = "https://" + ip + "/Ofertas/Vivienda/" + v.id_inmueble;

    let div = e("div", "card mt-3 rounded-3");
    let row1 = e("div", "row no-gutters rounded-3");
    let col1 = e("div", "col-md-4 rounded-3")
    let colImg = e("div", "carousel slide");
    colImg.id = "carouselExampleControls" + v.id_inmueble;
    colImg.setAttribute("data-bs-ride", "carousel");

    let divCa = e("div", "carousel-inner");
    descargaImagenes(v.id_inmueble)
        .then(data => {
            for (let i = 0; i < data.length; i++) {
                if (i == 0) {
                    let item = e("div", "carousel-item active");
                    let img = e("img", "rounded-3 tarjetaOferta");
                    img.setAttribute("src", data[i]);
                    a(item, img);
                    a(divCa, item);
                } else {
                    let item = e("div", "carousel-item");
                    let img = e("img", "rounded-3 tarjetaOferta");
                    img.setAttribute("src", data[i]);
                    a(item, img);
                    a(divCa, item);
                }
            }
        })

    let btn1Ca = e("button", "carousel-control-prev");
    btn1Ca.setAttribute("type", "button");
    btn1Ca.setAttribute("data-bs-target", "#carouselExampleControls" + v.id_inmueble);
    btn1Ca.setAttribute("data-bs-slide", "prev");
    let btn1CaSpan = e("span", "carousel-control-prev-icon");
    btn1CaSpan.setAttribute("aria-hidden", "true");
    let btn1CaSpan1 = e("span", "visually-hidden", "Previous");
    a(btn1Ca, btn1CaSpan);
    a(btn1Ca, btn1CaSpan1);

    let btn2Ca = e("button", "carousel-control-next");
    btn2Ca.setAttribute("type", "button");
    btn2Ca.setAttribute("data-bs-target", "#carouselExampleControls" + v.id_inmueble);
    btn2Ca.setAttribute("data-bs-slide", "next");
    let btn2CaSpan = e("span", "carousel-control-next-icon");
    btn2CaSpan.setAttribute("aria-hidden", "true");
    let btn2CaSpan1 = e("span", "visually-hidden", "Next");
    a(btn2Ca, btn2CaSpan);
    a(btn2Ca, btn2CaSpan1);

    a(colImg, divCa);
    a(colImg, btn1Ca);
    a(colImg, btn2Ca);


    a(col1, colImg);
    let colBody = e("div", "col-md-6");
    let cardBody = e("div", "card-body");
    let cardTitle = e("h3", "card-title");
    let cardTitleBold = e("b", "", v.precio + " ");
    let cardTitleSmall = e("small", "text-muted", "€/mes");
    a(cardTitle, cardTitleBold);
    a(cardTitle, cardTitleSmall);

    let cardText1 = e("p", "card-text");
    let cardText1Bold = e("b", "", v.tipo_vivienda);
    a(cardText1, cardText1Bold);
    let cardText2 = e("p", "card-text");
    let cardText2Small = e("small", "", v.direccion + " (" + v.municipio + ")");
    a(cardText2, cardText2Small);
    let cardText21 = e("p", "card-text");
    let cardText21Small = e("small", "", "Aforo: " + v.aforo + " · Superficie: " + v.superficie + "m² · Estado: " + v.estado)
    a(cardText21, cardText21Small);

    let cardText5 = e("small", "", v.recursos);

    let cardText3 = e("p", "card-text");
    let cardText3Normal = e("span", "", v.descripcion + " - ... ")
    a(cardText3, cardText3Normal);
    let cardText3A = e("a", "leer", "Leer más...")
    cardText3A.href = ruta;
    cardText3A.style.color = "#CE7106";
    a(cardText3, cardText3A);
    let cardText4 = e("p", "card-text");
    let cardText4Small = e("small", "text-muted", v.fecha);
    a(cardText4, cardText4Small);


    a(cardBody, cardTitle);
    a(cardBody, cardText1);
    a(cardBody, cardText2);
    a(cardBody, cardText21);
    a(cardBody, cardText5);
    a(cardBody, cardText3);
    a(cardBody, cardText4);

    a(colBody, cardBody);

    a(row1, col1);
    a(row1, colBody);
    let colBoton = CreaBotones(v.id_oferta, v.inscrito);
    a(row1, colBoton);

    a(div, row1);
    document.getElementById("holder").appendChild(div);

    function CreaBotones(id, inscrito) {
        let contenedor = e("div", "col d-flex flex-column justify-content-between p-3");
        let contenedorRow = e("div", "row h-100 flex-md-column justify-content-between p-2");
        let rowIconos = e("div", "row justify-content-end");
        let btnInfo = e("a", "btn col-6 ml-3");
        btnInfo.style.border = "none";
        btnInfo.style.color = "#CE7106";
        btnInfo.style.backgroundColor = "white";
        btnInfo.id = "iBS0";
        btnInfo.href = ruta;

        let iconInfo = e("i", "bi bi-info-circle-fill", "");
        let btnDots = e("button", "btn col-6");
        btnDots.style.border = "none";
        btnDots.style.color = "#CE7106";
        btnDots.style.backgroundColor = "white";
        btnDots.id = "iBS0";
        let iconDots = e("i", "bi bi-three-dots");
        let btnCheck;
        if (inscrito) {
            btnCheck = e("button", "d-grid btn align-items-center");
            btnCheck.style.border = "2px solid #CE7106";
            btnCheck.style.color = "white";
            btnCheck.style.backgroundColor = "#CE7106";
        } else {
            btnCheck = e("button", "d-grid btn align-items-center");
            btnCheck.style.border = "2px solid #CE7106";
            btnCheck.style.color = "#CE7106";
            btnCheck.style.backgroundColor = "white";
        }
        btnCheck.setAttribute("data-id", id);
        let btnSpan = e("span", "");

        let iconCheck;
        let smallCheck = e("small", "", "");

        let bSmallCheck;
        if (inscrito) {
            iconCheck = e("i", "bi bi-check2 d-md-none d-lg-inline");
            bSmallCheck = e("b", "", " INSCRITO");
        } else {
            iconCheck = e("i", "d-none bi bi-check2");
            bSmallCheck = e("b", "", " INSCRIBIR")
        }

        btnCheck.addEventListener("click", function () {
            if (!inscrito) {
                fetch("https://" + ip + "/Ofertas/inscribirseOferta/" + id)
                    .then(response => response.json())
                    .then(data => {
                        if (data) {
                            btnCheck.className = "d-grid btn align-items-center";
                            btnCheck.style.border = "2px solid #CE7106";
                            btnCheck.style.color = "white";
                            btnCheck.style.backgroundColor = "#CE7106";
                            btnCheck.style.boxShadow = "none";
                            bSmallCheck.textContent = " " + "INSCRITO";
                            iconCheck.className = "bi bi-check2 d-md-none d-lg-inline";
                            inscrito = 1;
                        }
                    })
            } else {
                if (confirm("¿Deseas eliminar la inscripción a esta oferta?") == true) {
                    fetch("https://" + ip + "/Ofertas/cancelarInscripcionOferta/" + id)
                        .then(response => response.json())
                        .then(data => {
                            if (data) {
                                // cambia estilo
                                btnCheck.className = "d-grid btn align-items-center";
                                btnCheck.style.border = "2px solid #CE7106";
                                btnCheck.style.color = "#CE7106";
                                btnCheck.style.backgroundColor = "white";
                                btnCheck.style.boxShadow = "none";
                                bSmallCheck.textContent = " " + "INSCRIBIR";
                                iconCheck.className = "d-none bi bi-check2";
                                inscrito = 0;
                            }
                        })
                }
            }
        })

        if(usuarioSesion == 0) {
            btnCheck.setAttribute("class", "d-none");
        }

        a(smallCheck, bSmallCheck);
        a(btnSpan, iconCheck);
        a(btnSpan, smallCheck);
        a(btnCheck, btnSpan);
        a(btnDots, iconDots);
        a(btnInfo, iconInfo);
        a(rowIconos, btnInfo);
        a(rowIconos, btnDots);
        a(contenedorRow, rowIconos);
        a(contenedorRow, btnCheck);
        a(contenedor, contenedorRow);
        return contenedor;
    }

    function a(i, j) {
        i.appendChild(j);
    }

    function e(m, n, t = null) {
        var elemento = document.createElement(m);
        elemento.className = n;
        elemento.textContent = t;
        return elemento;
    }
}