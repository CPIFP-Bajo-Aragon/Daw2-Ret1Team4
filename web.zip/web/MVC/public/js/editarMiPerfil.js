/* OPEN MODAL CAMBIAR INFORMACIÓN DEL PERFIL */
// var ip = location.host;
function openModalEditPerfil(ip) {
  
  var modal = document.createElement('div');
  modal.className = 'modalCreate';

  var modalCard = document.createElement('div');
  modalCard.className = 'modalCard';
  // Titulo Card
  var titulo = document.createElement('h2');
  titulo.textContent = "Editar información del perfil";
  modalCard.appendChild(titulo);

  var closeButton = document.createElement('span');
  closeButton.className = 'closeButton';
  closeButton.innerHTML = '&times;';
  closeButton.onclick = closeModal;
  modalCard.appendChild(closeButton);

  var form = document.createElement('form');
  form.className = 'form-container';
  form.method = 'POST';
  form.onsubmit = validarFechas;
  form.action = '/Usuarios/editarMiPerfil';


  // Nombre

  var labelNombre = document.createElement('label');
  labelNombre.htmlFor = 'nombre';
  labelNombre.textContent = 'Nombre:';


  var inputNombre = document.createElement('input');
  inputNombre.type = 'text';
  inputNombre.name = 'nombre';
  inputNombre.required = true;
  inputNombre.classList.add("form-control");
 
   // Apellidos

   var labelApellidos = document.createElement('label');
   labelApellidos.htmlFor = 'apellidos';
   labelApellidos.textContent = 'Apellidos:';
 
 
   var inputApellidos = document.createElement('input');
   inputApellidos.type = 'text';
   inputApellidos.name = 'apellidos';
   inputApellidos.required = true;
   inputApellidos.classList.add("form-control");

   // Correo

   var labelCorreo = document.createElement('label');
   labelCorreo.htmlFor = 'correo';
   labelCorreo.textContent = 'Correo:';
 
 
   var inputCorreo = document.createElement('input');
   inputCorreo.type = 'text';
   inputCorreo.name = 'correo';
   inputCorreo.required = true;  
   inputCorreo.classList.add("form-control");


     // Teléfono

    var labelTlfn = document.createElement('label');
    labelTlfn.htmlFor = 'tlfn';
    labelTlfn.textContent = 'Teléfono:';


    var inputTlfn = document.createElement('input');
    inputTlfn.type = 'text';
    inputTlfn.name = 'tlfn';
    inputTlfn.required = true;
    inputTlfn.classList.add("form-control");


   // Nif

   var inputNif = document.createElement('input');
   inputNif.type = 'hidden';
   inputNif.name = 'nif';
   inputNif.required = true;  

  
 
  fetch('https://'+ ip +'/Usuarios/editarMiPerfil')
    .then(response => {
      if (!response.ok) {
        throw new Error('Error en la solicitud Fetch. Estado de respuesta: ' + response.status);
      }
      return response.json();
    })
    .then(data => {
      console.log('Después de fetch');
      console.log('Datos recibidos:', data);
      inputNombre.value = data.nombre_usuario;
      inputApellidos.value = data.apellidos_usuario;
      inputCorreo.value = data.correo_usuario;
      inputNif.value = data.nif;
      inputTlfn.value = data.telefono_usuario;
    })
    .catch(error => {
      if (error instanceof SyntaxError) {
        console.error('Error: La respuesta del servidor no es un JSON válido.');
      } else {
        console.error('Error en la solicitud Fetch:', error.message, error);
      }
    });
  form.appendChild(labelNombre);
  form.appendChild(inputNombre);
  form.appendChild(labelApellidos);
  form.appendChild(inputApellidos);
  form.appendChild(labelCorreo);
  form.appendChild(inputCorreo);
  form.appendChild(labelTlfn);
  form.appendChild(inputTlfn);
  form.appendChild(inputNif);




  var submitButton = document.createElement('input');
  submitButton.type = 'submit';
  submitButton.value = 'Guardar cambios';
  submitButton.classList.add("btn", "btn-primary");
  form.appendChild(submitButton);

  modalCard.appendChild(form);
  modal.appendChild(modalCard);

  var modalContainer = document.getElementById('modal-container');
  modalContainer.innerHTML = '';
  modalContainer.appendChild(modal);

  modal.style.display = 'block';
}




/* OPEN MODAL CAMBIAR CLAVE */

function openModalCambiarClave(nif) {

  var modal = document.createElement('div');
  modal.className = 'modalCreate';

  var modalCard = document.createElement('div');
  modalCard.className = 'modalCard';
  // Titulo Card
  var titulo = document.createElement('h2');
  titulo.textContent = "Cambiar contraseña";
  modalCard.appendChild(titulo);

  var closeButton = document.createElement('span');
  closeButton.className = 'closeButton';
  closeButton.innerHTML = '&times;';
  closeButton.onclick = closeModal;
  modalCard.appendChild(closeButton);

  var form = document.createElement('form');
  form.className = 'form-container';
  form.method = 'POST';
  form.onsubmit = validarFechas;
  form.action = '/Usuarios/editarClave';


  // Clave

  var labelClave = document.createElement('label');
  labelClave.htmlFor = 'clave';
  labelClave.textContent = 'Contraseña:';


  var inputClave = document.createElement('input');
  inputClave.type = 'password';
  inputClave.name = 'clave';
  inputClave.required = true;
  inputClave.setAttribute("id", "password");
  inputClave.classList.add("form-control");
   // Confirmar clave

   var labelClave2 = document.createElement('label');
   labelClave2.htmlFor = 'clave2';
   labelClave2.textContent = 'Confirmar contraseña:';
 
 
   var inputClave2 = document.createElement('input');
   inputClave2.type = 'password';
   inputClave2.name = 'clave2';
   inputClave2.required = true;
   inputClave2.setAttribute("id", "re-password");
   inputClave2.classList.add("form-control");

   // Nif

   var inputNif = document.createElement('input');
   inputNif.type = 'hidden';
   inputNif.name = 'nif';
   inputNif.required = true;  
  
   inputNif.value = nif;

   var message = document.createElement('span');
   message.setAttribute("id", "message");
   modalCard.appendChild(message);

   
   form.appendChild(labelClave);
   form.appendChild(inputClave);
   form.appendChild(labelClave2);
   form.appendChild(inputClave2);
   form.appendChild(inputNif);

  // COMPROBAR CLAVE
  let valorClave = "";
  let valorClave2 = "";
  
  function comprobarClave() {
    if (valorClave !== valorClave2) {
      message.classList.add("text-danger");
      message.innerHTML = "Las contraseñas no coinciden.";
      submitButton.disabled = true;
    } else {
      message.innerHTML = "";
      submitButton.disabled = false;
    }
  }

  inputClave.addEventListener("keyup", (event) => {
    valorClave = inputClave.value;
    valorClave2 = inputClave2.value;
    comprobarClave();
  });

  inputClave2.addEventListener("keyup", (event) => {
    valorClave = inputClave.value;
    valorClave2 = inputClave2.value;
    comprobarClave();
  });



   var submitButton = document.createElement('input');
   submitButton.type = 'submit';
   submitButton.value = 'Guardar cambios';
   submitButton.classList.add("btn", "btn-primary");
   form.appendChild(submitButton);
   submitButton.disabled = true;
   modalCard.appendChild(form);
   modal.appendChild(modalCard);

   var modalContainer = document.getElementById('modal-container');
   modalContainer.innerHTML = '';
   modalContainer.appendChild(modal);

   modal.style.display = 'block';
}






// VALIDAR, CERRAR, ETC...

function closeModal() {
  var modalContainer = document.getElementById('modal-container');
  modalContainer.innerHTML = '';
}

function validarFechas() {
  var fechaInicio = new Date(document.getElementsByName("Fecha_Inicio")[0].value);
  var fechaFin = new Date(document.getElementsByName("Fecha_Fin")[0].value);

  if (fechaFin <= fechaInicio) {
    alert("La Fecha de Fin debe ser posterior a la Fecha de Inicio.");
    return false;
  }
  return true;
}

function verMisDocumentos(nif){
alert(nif);
  // fetch('https://'+ ip +'/Usuarios/editarMiPerfil')
  // .then(response => {
  //   if (!response.ok) {
  //     throw new Error('Error en la solicitud Fetch. Estado de respuesta: ' + response.status);
  //   }
  //   return response.json();
  // })
  // .then(data => {
    
  // })
  // .catch(error => {
  //   if (error instanceof SyntaxError) {
  //     console.error('Error: La respuesta del servidor no es un JSON válido.');
  //   } else {
  //     console.error('Error en la solicitud Fetch:', error.message, error);
  //   }
  // });

}