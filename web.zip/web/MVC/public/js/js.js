


function gerentes(id){
    fetch("https://"+ ip +"/Usuarios/gerentes/" + id)
        .then(response => response.json())
        .then(data => {
            lista=document.getElementById("listaGerentes"+id);
            lista.textContent="";
            let tablagerentes=document.createElement("table");
            tablagerentes.className="table table-hover"
            let headGerentes=document.createElement("thead");
            let bodyGerentes=document.createElement("tbody");
            let th1=document.createElement("th");
            th1.textContent="Nombre";
            let th2=document.createElement("th");
            th2.textContent="Eliminar";
            headGerentes.appendChild(th1);
            headGerentes.appendChild(th2);
            for(let i=0;i<data.length;i++){
                if(data[i].rol != "Administrador"){
                    let tr=document.createElement("tr");
                    let td1=document.createElement("td");
                    let td2=document.createElement("td");
    
                    td1.textContent=data[i].nombre_usuario+" "+data[i].apellidos_usuario;

                    let btn=document.createElement("button");
                    
                    btn.onclick= function(){
                        
                        if (confirm("Seguro que quieres borrar a "+data[i].nombre_usuario+" "+data[i].apellidos_usuario) == true) {
                            eliminarGerente(data[i].id_usuario,data[i].id_entidad,id);
                          }
                        
                      };
                    let icon=document.createElement("i");

                    btn.className="btn btn-danger"
                    icon.className="bi bi-person-dash-fill"
                    btn.appendChild(icon);
                    td2.appendChild(btn);
                    tr.appendChild(td1);
                    tr.appendChild(td2);
                    bodyGerentes.appendChild(tr);
                }
            }

            tablagerentes.appendChild(headGerentes);
            tablagerentes.appendChild(bodyGerentes);
            lista.appendChild(tablagerentes);
            
        })
        .catch(error => {
            if (error instanceof SyntaxError) {
                console.error('Error: La respuesta del servidor no es un JSON válido.');
            } else {
                console.error('Error en la solicitud Fetch:', error.message, error);
            }
        });
}

 function eliminarEntidad(id){
            fetch("https://"+ ip +"/Usuarios/eliminarEntidad/" + id)
                .then(response => response.json())
                .then(data => {

                })
                .catch(error => {
                    if (error instanceof SyntaxError) {
                        console.error('Error: La respuesta del servidor no es un JSON válido.');
                    } else {
                        console.error('Error en la solicitud Fetch:', error.message, error);
                    }
                });
}

function eliminarGerente(id_usu,id_ent,id){
    fetch("https://"+ ip +"/Usuarios/eliminarGerente/" + id_usu+"/"+id_ent)
        .then(response => response.json())
        .then(data => {
            gerentes(id);
        })
        .catch(error => {
            if (error instanceof SyntaxError) {
                console.error('Error: La respuesta del servidor no es un JSON válido.');
            } else {
                console.error('Error en la solicitud Fetch:', error.message, error);
            }
        });
}