document.addEventListener("DOMContentLoaded", function () {
  let formNif = document.getElementById("NIF");
  formNif.addEventListener("keyup", function () {
    if (getNif(formNif) != 0) {
      existeUser(formNif);
    }
  });

  formNif.addEventListener("focusout", function () {
    if (getNif(formNif) != 0) {
      existeUser(formNif);
    }
  });

  let formCorreo = document.getElementById("email");
  formCorreo.addEventListener("keyup", function () {
    if (getNif(formCorreo) != 0) {
      existeUser(formCorreo);
    }
  });

  formCorreo.addEventListener("focusout", function () {
    if (getNif(formCorreo) != 0) {
      existeUser(formCorreo);
    }
  });
});



function existeUser(formElement) {
  let nif = getNif(formElement);
  fetch('https://'+ ip +'/Usuarios/existeUser/' + nif)
    .then(response => response.json())
    .then(data => {
      if (data == 0 && formatoCorrecto(formElement)) {
        formElement.style.border = "2px solid #1db600";
        formElement.style.boxShadow = "none";
      } else {
        formElement.style.border = "2px solid #d31d1d";
        formElement.style.boxShadow = "none";
      }

    })
}

function formatoCorrecto(formElement) {
  var regexNIF = /^[XYZ0-9][0-9]{7}[TRWAGMYFPDXBNJZSQVHLCKE]$/i;
  var regexEmail = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  if (regexNIF.test(formElement.value) || regexEmail.test(formElement.value)) {
    console.log("El NIF es válido.");
    return true;
  } else {
    console.log("El NIF no es válido.");
    return false;
  }
}

function getNif(formElement) {
  nif = formElement.value;
  return nif;
}
