
let checkNotis = document.getElementById("leerNotis");
checkNotis.addEventListener("click", (event) => {
  fetch('https://'+ ip +'/Usuarios/verTodasNotificaciones')
    .then(response => {
      if (!response.ok) {
        throw new Error('Error en la solicitud Fetch. Estado de respuesta: ' + response.status);
      }
      return response.json(); 
    })
    .then(data => {

      let numNotificaciones = document.getElementById("numNotificaciones");
      numNotificaciones.textContent = "0";

    // function hide (elements) {
    //   elements = elements.length ? elements : [elements];
    //   for (var index = 0; index < elements.length; index++) {
    //     elements[index].style.display = 'none';
    //   }
    // }

    hide(document.getElementsByClassName("notification-message"));
    hide(document.getElementsByClassName("notification-separator"));

    })
    .catch(error => {
      if (error instanceof SyntaxError) {
        console.error('Error: La respuesta del servidor no es un JSON válido.');
      } else {
        console.error('Error en la solicitud Fetch:', error.message, error);
      }
    });
});