var selectedFiles = [];

        function handleDragOver(event) {
            event.preventDefault();
            document.getElementById('drop-area').classList.add('dragover');
        }

        function handleDrop(event) {

            event.preventDefault();
            document.getElementById('drop-area').classList.remove('dragover');

            var files = event.dataTransfer.files;
            document.getElementById('file-input').files = files;
            previewImages();
        }

        function selectFiles() {
            document.getElementById('file-input').click();
        }

        function previewImages() {
            var previewContainer = document.getElementById('image-preview');
            var files = document.getElementById('file-input').files;

            selectedFiles = Array.from(files);

            previewContainer.innerHTML = '';

            for (var i = 0; i < files.length; i++) {
                var file = files[i];
                var fileInfoContainer = document.createElement('div');
                fileInfoContainer.classList.add('file-info');

                var fileName = document.createElement('span');
                fileName.innerText = file.name;

                var deleteButton = document.createElement('button');
                deleteButton.innerText = 'x';
                deleteButton.className="btn btn-danger ms-2"
                deleteButton.classList.add('delete-button');
                deleteButton.onclick = createRemoveFileHandler(file, fileInfoContainer);

                fileInfoContainer.appendChild(fileName);
                fileInfoContainer.appendChild(deleteButton);

                previewContainer.appendChild(fileInfoContainer);
            }
        }


        function createRemoveFileHandler(file, fileInfoContainer) {
            return function () {
                removeFile(file, fileInfoContainer);
            };
        }

        function removeFile(fileToRemove, fileInfoContainer) {
            selectedFiles = selectedFiles.filter(function (file) {
                return file !== fileToRemove;
            });

            fileInfoContainer.remove(); // Elimina el contenedor del archivo del DOM
        }