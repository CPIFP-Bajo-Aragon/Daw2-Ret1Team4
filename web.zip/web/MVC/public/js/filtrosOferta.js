

var filtro = new Object();
fetch("https://" + ip + "/Ofertas/preciosViviendas")
.then(response => response.json())
.then(data => {
    // filtro.precioMaximo = data[0].max_precio;
    // filtro.precioMinimo = data[0].min_precio;

    // maxTraspaso = data[0].max_precio;
    // minTraspaso = data[0].min_precio;
})

fetch("https://" + ip + "/Ofertas/preciosNegocios")
.then(response => response.json())
.then(data => {
    filtro.precioMaximo = data[0].max_precio;
    filtro.precioMinimo = data[0].min_precio;

    maxTraspaso = data[0].max_precio;
    minTraspaso = data[0].min_precio;
})

filtro.municipio = "Sin preferencia";
filtro.tipo = ["V", "L", "N"];
filtro.fecha = "1000000000";


document.addEventListener("DOMContentLoaded", function () {
    creaListeners();
});

function filtra() {
    if(filtro.municipio == "Sin preferencia"){
        arrayFiltrado = datosDescargados.filter(e => (e.precio > filtro.precioMinimo || e.traspaso > filtro.precioMinimo) && (e.precio < filtro.precioMaximo || e.traspaso < filtro.precioMaximo) && e.dias < filtro.fecha && filtro.tipo.includes(e.tipo));
    } else {
        arrayFiltrado = datosDescargados.filter(e => (e.precio > filtro.precioMinimo || e.traspaso > filtro.precioMinimo) && (e.precio < filtro.precioMaximo || e.traspaso < filtro.precioMaximo) && e.municipio == filtro.municipio && e.dias < filtro.fecha && filtro.tipo.includes(e.tipo));
    } 
    construyePagina(arrayFiltrado);
}

function creaListeners() {

    // FLEXCHECK
    let selectedCheck = ["V", "L", "N"];
    const check = document.querySelectorAll(".form-check .form-check-input");
    check.forEach((e) => {
        e.addEventListener("change", function () {
            selectedCheck = [];
            check.forEach((i) => {
                if (i.checked) {
                    selectedCheck.push(i.value)
                }
            })

            if (selectedCheck.length < 2) {
                check.forEach((i) => {
                    if (i.checked) {
                        i.setAttribute("disabled", "");
                    }
                })
            } else {
                check.forEach((i) => {
                    if (i.disabled) {
                        i.removeAttribute("disabled");
                    }
                })
            }

            filtro.tipo = selectedCheck;
            filtra();
        });
    })


    // SELECT OPTION
    const select = document.getElementById("select_municipio");
    select.addEventListener("change", function () {
        filtro.municipio = select.options[select.selectedIndex].value;
        filtra();
    });

    const radio = document.getElementsByName("exampleRadios");
    radio.forEach(e => {
        e.addEventListener("change", function () {
            filtro.fecha = e.value;
            filtra();
        })
    })



    // MULTI-SLIDER
    let rangeMin = 100;
    const range = document.querySelector(".range-selected");
    const rangeInput = document.querySelectorAll(".range-input input");
    const rangePrice = document.querySelectorAll(".range-price input");

    rangeInput.forEach((input) => {
        input.addEventListener("input", (e) => {
            let minRange = parseInt(rangeInput[0].value);
            let maxRange = parseInt(rangeInput[1].value);
            let totalDesp = maxTraspaso - minTraspaso;
            if (maxRange - minRange < rangeMin) {
                if (e.target.className === "min") {
                    rangeInput[0].value = maxRange - rangeMin;
                } else {
                    rangeInput[1].value = minRange + rangeMin;
                }
            } else {
                rangePrice[0].value = minRange;
                rangePrice[1].value = maxRange;

                
                // range.style.left = (minRange / rangeInput[0].max) * 100 + "%";

                range.style.left = ((minRange - minTraspaso) * 100) / totalDesp + "%";
                range.style.right = 100 - (100 - ((((maxTraspaso - maxRange) - totalDesp) * 100) / totalDesp) - 100) + "%";

                // range2.style.left = (minRange / rangeInput[0].max) * 100 + "%";
                // range2.style.right = 100 - (maxRange / rangeInput[1].max) * 100 + "%";

                filtro.precioMinimo = rangePrice[0].value;
                filtro.precioMaximo = rangePrice[1].value;
            }

            filtra();
        });
    });

    rangePrice.forEach((input) => {
        input.addEventListener("input", (e) => {
            let minPrice = rangePrice[0].value;
            let maxPrice = rangePrice[1].value;
            if (maxPrice - minPrice >= rangeMin && maxPrice <= rangeInput[1].max) {
                if (e.target.className === "min") {
                    rangeInput[0].value = minPrice;
                    range.style.left = (minPrice / rangeInput[0].max) * 100 + "%";
                } else {
                    rangeInput[1].value = maxPrice;
                    range.style.right = 100 - (maxPrice / rangeInput[1].max) * 100 + "%";
                }
            }
        });
    });
}
