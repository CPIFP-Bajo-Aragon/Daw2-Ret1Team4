var map;

function initializeMap() {
    if (map != undefined) {
        map.off();
        map.remove();
    }
    map = L.map('mi_mapa').setView([0, 0], 2);

    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
    }).addTo(map);
}


function ServiciosAPI(variable, ip) {

  initializeMap(); 
   
    fetch('https://'+ ip +'/Servicio/CargarServicios/' + variable)
   
    .then(response => {
        if (!response.ok) {
          throw new Error('Error en el fetch' + response.status);
        }
        return response.json();
        
      })
    
      .then(data => {
       
        const primerRegistro = data[0];

        const latitud = primerRegistro.latitud_servicio;
        const longitud = primerRegistro.longitud_servicio;
        map.setView([latitud, longitud], 14);


        data.forEach(servicios => {

           L.marker([servicios.latitud_servicio,  servicios.longitud_servicio]).addTo(map).bindPopup(servicios.nombre_servicio);

        });
       
        
      })
      
      .catch(error => {
        if (error instanceof SyntaxError) {
          console.error('Error: La respuesta del servidor no es un JSON válido.');
        } else {
          console.error('Error en la solicitud Fetch:', error.message, error);
        }
      });
  }