// Obtener el contexto del canvas
var ctx = document.getElementById('myChart').getContext('2d');

// Datos del gráfico con fetch

fetch('https://' + ip + '/Usuarios/consulta')
    .then(response => {
        if (!response.ok) {
            throw new Error('Error en la solicitud Fetch. Estado de respuesta: ' + response.status);
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
        var labels = [];
        var chartData = [];
        var coloresFondo = [];

        var paletaColores = [];
         
        function generarColorRGB() {
            var r = Math.floor(Math.random() * 256);
            var g = Math.floor(Math.random() * 256);
            var b = Math.floor(Math.random() * 256);
            return 'rgb(' + r + ', ' + g + ', ' + b + ')';
        }
        
        function generarColoresAleatorios(n) {
            for (var i = 0; i < n; i++) {
                paletaColores.push(generarColorRGB());
            }
        }
        
        generarColoresAleatorios(data.length);

        for (let i = 0; i < data.length; i++) {
            labels.push(data[i].nombre_municipio);
            chartData.push(data[i].numero_ofertas);
            coloresFondo.push(paletaColores[i % paletaColores.length]);
        }

        // Datos
        var datos = {
            labels: labels,
            datasets: [{
                label: 'Ofertas de inmuebles',
                backgroundColor: coloresFondo,
                data: chartData
            }]
        };

        // Opciones
        var options = {
            responsive: true,
            maintainAspectRatio: true,
            
        };

        // Crear el gráfico 
        new Chart(ctx, {
            type: 'doughnut',
            data: datos,
            options: options
        });
    })
    .catch(error => {
        if (error instanceof SyntaxError) {
            console.error('Error: La respuesta del servidor no es un JSON válido.');
        } else {
            console.error('Error en la solicitud Fetch:', error.message, error);
        }
    });



