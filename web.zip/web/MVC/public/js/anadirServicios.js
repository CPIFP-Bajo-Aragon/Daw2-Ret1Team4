/* OPEN MODAL CAMBIAR INFORMACIÓN DEL PERFIL */

function openModalAnadirServicio(variable, ip) {
    var modal = document.createElement('div');
    modal.className = 'modalCreate';
  
    var modalCard = document.createElement('div');
    modalCard.className = 'modalCard';

    // Titulo Card
    
    var titulo = document.createElement('h2');
    titulo.textContent = "Añadir servicio";
    modalCard.appendChild(titulo);
  
    var closeButton = document.createElement('span');
    closeButton.className = 'closeButton';
    closeButton.innerHTML = '&times;';
    closeButton.onclick = closeModal;
    modalCard.appendChild(closeButton);
  
    var form = document.createElement('form');
    form.className = 'form-container';
    form.method = 'POST';
    form.action = '/Servicio/anadirServicios';
  
  
    // Nombre
  
    var labelNombre = document.createElement('label');
    labelNombre.htmlFor = 'nombre';
    labelNombre.textContent = 'Nombre de servicio:';
  
  
    var inputNombre = document.createElement('input');
    inputNombre.type = 'text';
    inputNombre.name = 'nombre';
    inputNombre.required = true;
    inputNombre.classList.add("form-control");
   
     // Descripción de servicio
  
     var labelDescripcion = document.createElement('label');
     labelDescripcion.htmlFor = 'descripcion';
     labelDescripcion.textContent = 'Descripción de servicio:';
   
   
     var inputDescrpcion = document.createElement('input');
     inputDescrpcion.type = 'text';
     inputDescrpcion.name = 'descripcion';
     inputDescrpcion.required = true;
     inputDescrpcion.classList.add("form-control");
  
     // Tipo de servicio
  
 
      var labelTipoServicio = document.createElement('label');
      labelTipoServicio.htmlFor = 'tipoServicio';
      labelTipoServicio.textContent = 'Tipo de servicio:';
    

      var selectTipoServicio = document.createElement('select');
      selectTipoServicio.name = 'tipoServicio';
      selectTipoServicio.id = 'tipoServicio';

      // Cargar los centros mediante Fetch

      fetch('https://'+ ip +'/Servicio/obtenerTiposServicio')
        .then(response => {
          if (!response.ok) {
            throw new Error('Error en la solicitud Fetch. Estado de respuesta: ' + response.status);
          }
          return response.json();
        })
        .then(data => {
          console.log('Después de fetch');
          console.log('Datos recibidos:', data);
          data.forEach(TipoServicio => {
            console.log('Añadiendo TipoServicio:', TipoServicio);
            var option = document.createElement('option');
            option.value = TipoServicio.id_tipo_servicio;
            option.textContent = TipoServicio.nombre_tipo_servicio;
            selectTipoServicio.appendChild(option);
          });
        })
        .catch(error => {
          if (error instanceof SyntaxError) {
            console.error('Error: La respuesta del servidor no es un JSON válido.');
          } else {
            console.error('Error en la solicitud Fetch:', error.message, error);
          }
        });

        selectTipoServicio.classList.add("form-control");
  
  
       // Latitud Servicio
  
      var labelLatitud = document.createElement('label');
      labelLatitud.htmlFor = 'latitud';
      labelLatitud.textContent = 'Latitud:';
  
  
      var inputLatitud = document.createElement('input');
      inputLatitud.type = 'text';
      inputLatitud.name = 'latitud';
      inputLatitud.required = true;
      inputLatitud.classList.add("form-control");

       // Longitud Servicio
  
      var labelLongitud = document.createElement('label');
      labelLongitud.htmlFor = 'longitud';
      labelLongitud.textContent = 'Longitud:';
  
  
      var inputLongitud = document.createElement('input');
      inputLongitud.type = 'text';
      inputLongitud.name = 'longitud';
      inputLongitud.required = true;
      inputLongitud.classList.add("form-control");

       // ID MUNICIPIO

      var inputIdMunicipio = document.createElement('input');
      inputIdMunicipio.type = 'hidden';
      inputIdMunicipio.name = 'idMunicipio';
      inputIdMunicipio.required = true;
      inputIdMunicipio.classList.add("form-control");
      inputIdMunicipio.value = variable;

    // APPENDCHILDS

    form.appendChild(labelNombre);
    form.appendChild(inputNombre);
    form.appendChild(labelDescripcion);
    form.appendChild(inputDescrpcion);
    form.appendChild(labelTipoServicio);
    form.appendChild(selectTipoServicio);
    form.appendChild(labelLatitud);
    form.appendChild(inputLatitud);
    form.appendChild(labelLongitud);
    form.appendChild(inputLongitud);
    form.appendChild(inputIdMunicipio);
  
  
  
    var submitButton = document.createElement('input');
    submitButton.type = 'submit';
    submitButton.value = 'Guardar cambios';
    submitButton.classList.add("btn", "btn-primary");
    form.appendChild(submitButton);
  
    modalCard.appendChild(form);
    modal.appendChild(modalCard);
  
    var modalContainer = document.getElementById('modal-container');
    modalContainer.innerHTML = '';
    modalContainer.appendChild(modal);
  
    modal.style.display = 'block';
  }
  


  // VALIDAR, CERRAR, ETC...
  
  function closeModal() {
    var modalContainer = document.getElementById('modal-container');
    modalContainer.innerHTML = '';
  }
  