
function obtenerValorRadioButton() {
    var radios = document.getElementsByName('negocioLocal');

    for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            if(radios[i].value=="conlocal"){
                document.getElementById("datosLocal").style="display:block"
            }
            else{
                document.getElementById("datosLocal").style="display:none"
            }
            break;
        }
    }
}

function obtenerTipoInmueble() {
    console.log("fufa");
    var radio = document.getElementsByName('tipoInmueble');
    for (var i = 0; i < radio.length; i++) {
        if (radio[i].checked) {
            if(radio[i].value=="local"){
                document.getElementById("infovivienda").style="display:none"
                document.getElementById("infolocal").style="display:block"

            }
            else{
                document.getElementById("infolocal").style="display:none"
                document.getElementById("infovivienda").style="display:block"
            }
            break;
        }
    }
}
