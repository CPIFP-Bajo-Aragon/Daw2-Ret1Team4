<?php
//cargar iniciador
require_once '../App/iniciador.php';

//instanciar clase core
$iniciar= new Core;

