<?php
    //Para redireccionar la página
    
    function redireccionar($pagina){
        header('location: '.RUTA_URL.$pagina);
    }

    function nextID($db,$pk,$tabla)
    {

        $db->query("SELECT MAX($pk) as maximo FROM $tabla");

        $dato=$db->registro();
        return ($dato->maximo)+1;
    }
    

    
    function cifrar_url_aes($url) {
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $url_cifrada = openssl_encrypt($url, 'aes-256-cbc', 'nytt', 0, $iv);
    if ($url_cifrada === false) {
        die("Error durante el cifrado: " . openssl_error_string());
    }
    $url_cifrada = str_replace(["+", "/", "="], ["_", "-", ""], base64_encode($url_cifrada . "#" . $iv));
    return $url_cifrada;
}

function descifrar_url_aes($url_cifrada) {
    $url_cifrada = str_replace(["_", "-"], ["+", "/"], $url_cifrada);
    $decoded = base64_decode(str_pad(strtr($url_cifrada, '-_', '+/'), strlen($url_cifrada) % 4, '=', STR_PAD_RIGHT));
    if ($decoded === false) {
        die("Error al decodificar la URL cifrada.");
    }
    $parts = explode('#', $decoded, 2);
    if (count($parts) < 2) {
        die("URL cifrada no válida.");
    }
    list($url_cifrada, $iv) = $parts;
    $iv = str_pad($iv, 16, "\0");
    $url_descifrada = openssl_decrypt($url_cifrada, 'aes-256-cbc', 'nytt', 0, $iv);
    if ($url_descifrada === false) {
        die("Error durante el descifrado:" . openssl_error_string());
    }
    return $url_descifrada;
}


function crearCarpeta($nombreCarpeta){
    $ruta = '/srv/www/api/MVC/public/img/ofertas/'.$nombreCarpeta.'/';

if (file_exists($ruta)) {
    if (eliminarContenidoCarpeta($ruta)) {

    } else {
        echo "Error al intentar eliminar el contenido de la carpeta '$ruta'.";
    }
} else {
    if(mkdir($ruta, 0777)){
        return true;
    }else{
        return false;
    }
}
}

function eliminarContenidoCarpeta($carpeta) {
    if (!file_exists($carpeta)) {
        return false;
    }

    $archivos = glob($carpeta . '/*');
    foreach ($archivos as $archivo) {
        is_dir($archivo) ? eliminarCarpeta($archivo) : unlink($archivo);
    }

    return true;
}

function eliminarCarpeta($carpeta) {
    eliminarContenidoCarpeta($carpeta);
    return rmdir($carpeta);
}

function insertFotos($fotos,$nCarpeta){
    
    foreach($fotos["archivo"]['tmp_name'] as $key => $tmp_name)
	{
        // print_r($tmp_name);exit;
		if($fotos["archivo"]["name"][$key]) {
			$filename = $fotos["archivo"]["name"][$key]; //nombre original del archivo
			$source = $fotos["archivo"]["tmp_name"][$key]; //nombre temporal del archivo
			
			$directorio ='/srv/www/api/MVC/public/img/ofertas/'.$nCarpeta.'/';
            //ruta donde guardaremos los archivos
			
			if(!file_exists($directorio)){
				mkdir($directorio, 0777) or die("No se puede crear el directorio de extracción");	
			}
			
			$dir=opendir($directorio); 
            // if(file_exists("portada.jpg")) {
            //     $target_path = $directorio.'/'.$filename;
            // } else {
            //     $target_path = $directorio.'/portada.jpg';
            // }
			$target_path = $directorio.'/'.$filename; //ruta de destino y el nombre del archivo
			
			
			//El primer campo es el origen y el segundo el destino
			if(move_uploaded_file($source, $target_path)) {	
				
				} else {	
				return false;
			}
			closedir($dir); 
		}
	}
}


function listarDirectorio( $nif){

    $path='/srv/www/api/MVC/public/usuarios/' . $nif . '/docs/';
    // Abrimos la carpeta que nos pasan como parámetro
    $dir = opendir($path);

    // Leo todos los ficheros de la carpeta
    while ($elemento = readdir($dir)){
        if( $elemento != "." && $elemento != "..")  // Si es una directorio
            {
                ?> <p>
                    <?php echo $elemento; ?> 
                    <button class="btn btn-danger">
                        <a href="<?php echo RUTA_URL."/Usuarios/borrardoc/$elemento" ?>" class="nav-link">
                        <i class="bi bi-trash"></i>
                        </a>
                    </button>
                    </p> <?php
            }
    }
}



function borrar_directorio($dirname,$nif) {

        $path='/srv/www/api/MVC/public/usuarios/' . $nif . '/docs/';

         if (is_dir($path))
           $dir_handle = opendir($path);

	 while($file = readdir($dir_handle)) {
	       if ($file==$dirname) {
	                 unlink($path."/".$file);
                     return true;
	       }
	 }
	 closedir($dir_handle);
     
}



