<?php

class Chat extends Controlador
{
    private $chatModelo;
    private $usuarioModelo;
    
    public function __construct()
    {

        $this->chatModelo = $this->modelo('ChatModelo');
        $this->usuarioModelo = $this->modelo('UsuarioModelo');


        if (Sesion::sesionCreada()) {
            Sesion::iniciarSesion($this->datos);
          
            $this->datos["notificaciones"] = $this->usuarioModelo->notificaciones($this->datos['usuarioSesion']->id_usuario);
            $this->datos["notificacionesUsuario"] = $this->usuarioModelo->obtenerNotificaciones($this->datos['usuarioSesion']->id_usuario);
        
        }

        $this->datos["rolesPermitidos"] = [10, 20];
        $this->datos['menuActivo'] = 1;
    }

    public function index($id=0)
    {
        $idDescifrado = 0;
         if($id != 0){
            $idDescifrado = descifrar_url_aes($id);
         }
        
       
        if (Sesion::sesionCreada()) {
            
          

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $mensaje = [
                    'id_emisor' => trim($this->datos['usuarioSesion']->id_usuario),
                    // 'id_receptor' => trim($this->datos['chat']->id_receptor),
                    'id_receptor' => $idDescifrado,
                    'mensaje_chat' => $_POST['mensaje_chat'],
                ];
                $this->chatModelo->enviarMensaje($mensaje);

            
            }

           
          
            $chat = [
                'id_emisor' => trim($this->datos['usuarioSesion']->id_usuario),
                'id_receptor' => trim($idDescifrado),
            ];
            $this->datos['chatsActivos'] = $this->chatModelo->obtenerChatsActivos($chat);
            $this->datos['enlaceEncriptado'] = $id;
            
            $this->datos['mensajes'] = $this->chatModelo->verMensajes($chat);
           
            $this->vista("chat/chatear", $this->datos);
        } else {
            $this->vista("inicio_no_loggeado");
        }
    }



}
