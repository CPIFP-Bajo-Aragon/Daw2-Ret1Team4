<?php

class Pueblos extends Controlador
{
    private $usuarioModelo;
    private $puebloModelo;

    public function __construct()
    {
        $this->puebloModelo = $this->modelo('PuebloModelo');
        $this->usuarioModelo = $this->modelo('UsuarioModelo');
        if (Sesion::sesionCreada()) {
            Sesion::iniciarSesion($this->datos);
            $this->datos["notificaciones"] = $this->usuarioModelo->notificaciones($this->datos['usuarioSesion']->id_usuario);
            $this->datos["notificacionesUsuario"] = $this->usuarioModelo->obtenerNotificaciones($this->datos['usuarioSesion']->id_usuario);

        }
        $this->datos["rolesPermitidos"] = [1];
        $this->datos['menuActivo'] = 1;

        
        // CONTROL DE USUARIO SESION, SI NO ESTÁ DEFINIDO SE DEFINE Y SI ESTÁ DEFNIDO PERO SIN VALOR SE LE PONE EL ROL MÁS BÁSICO

            if (!isset($this->datos['usuarioSesion'])) {
                // SI NO ESTÁ DEFINIDO, DEFINIRLO
                $this->datos['usuarioSesion'] = new stdClass();
                $this->datos['usuarioSesion']->id_rol = 10;
            } elseif (is_null($this->datos['usuarioSesion'])) {
                // SI ESTÁ DEFINIDO PERO ES NULL SE LE ESTABLECE EL VALOR DE ID_ROL A 10 QUE ES EL USUARIO BASE
                $this->datos['usuarioSesion'] = new stdClass();
                $this->datos['usuarioSesion']->id_rol = 10;
            }


    }

    public function index()
    {
        $this->datos["pueblos"] = $this->puebloModelo->obtenerPueblos();
        
        $this->vista("pueblos/pueblos_comarca", $this->datos);
    }

    public function obtenerPueblosJS()
    {
                $this->vistaApi($this->puebloModelo->obtenerPueblos());
    }

    public function anadirPueblos(){
       
        $pueblo = [
            'nombre_municipio' => trim($_POST['nombre_municipio']),
            'provincia_municipio' => trim($_POST['provincia_municipio']),
            'codigo_postal_municipio' => trim($_POST['codigo_postal_municipio']),
            'latitud_municipio' => trim($_POST['latitud_municipio']),
            'longitud_municipio' => trim($_POST['longitud_municipio']),
        ];

        $this->puebloModelo->anadirPueblos($pueblo);
        redireccionar("/Pueblos");
    }

    public function visitar($pueblo)
    {
        $this->datos["infoPueblo"] = $this->puebloModelo->infoPueblo($pueblo);
        $this->datos["serviciosPueblo"] = $this->puebloModelo->serviciosPueblo($pueblo);
       
        $this->vista("pueblos/visitar_pueblos", $this->datos);
    }
}
