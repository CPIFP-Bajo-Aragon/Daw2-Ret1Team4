<?php

    class Inicio extends Controlador {
        private $usuarioModelo;
        public function __construct() {
            $this->usuarioModelo = $this->modelo('UsuarioModelo');

        if (Sesion::sesionCreada($this->datos)) {
            $this->datos["notificaciones"] = $this->usuarioModelo->notificaciones($this->datos['usuarioSesion']->id_usuario);
            $this->datos["notificacionesUsuario"] = $this->usuarioModelo->obtenerNotificaciones($this->datos['usuarioSesion']->id_usuario);
        }
        }

        public function index() {
            $this->vista('inicio', $this->datos);
        }
    }