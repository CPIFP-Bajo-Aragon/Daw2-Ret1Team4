<?php

class Servicio extends Controlador {
    private $ServicioModelo;

    public function __construct(){
        $this->ServicioModelo = $this->modelo('ServicioModelo');
    }
    public function index(){
        $this->datos['municipios'] = $this->ServicioModelo->obtenerMunicicipios();
        
    }
    public function CargarServicios($municipio){
        $this->datos['servicios'] = $this->ServicioModelo->obtenerServicios($municipio);
        $this->vistaAPI($this->datos['servicios']);
    }

    public function anadirServicios(){
       
        $servicio = [
            'nombre' => trim($_POST['nombre']),
            'descripcion' => trim($_POST['descripcion']),
            'tipoServicio' => trim($_POST['tipoServicio']),
            'idMunicipio' => trim($_POST['idMunicipio']),
            'latitud' => trim($_POST['latitud']),
            'longitud' => ($_POST['longitud']),
        ];

        $this->datos['servicios'] = $this->ServicioModelo->anadirServicios($servicio);
        redireccionar("/Pueblos");
    }

    public function obtenerTiposServicio(){
        $this->datos['tiposServicio'] = $this->ServicioModelo->obtenerTiposServicio();
        $this->vistaAPI($this->datos['tiposServicio']);
    }


    
}