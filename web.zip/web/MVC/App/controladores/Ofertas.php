<?php

class Ofertas extends Controlador
{
    private $usuarioModelo;
    private $ofertaModelo;
    private $puebloModelo;


    public function __construct()
    {
        $this->ofertaModelo = $this->modelo('OfertaModelo');
        $this->usuarioModelo = $this->modelo('UsuarioModelo');
        $this->puebloModelo = $this->modelo('PuebloModelo');

        if (Sesion::sesionCreada()) {
            Sesion::iniciarSesion($this->datos);
            $this->datos["notificaciones"] = $this->usuarioModelo->notificaciones($this->datos['usuarioSesion']->id_usuario);
            $this->datos["notificacionesUsuario"] = $this->usuarioModelo->obtenerNotificaciones($this->datos['usuarioSesion']->id_usuario);
        }
        $this->datos["rolesPermitidos"] = [1];
        $this->datos['menuActivo'] = 1;
    }

    public function index()
    {
    }

    public function publicarNegocio()
    {
        if (Sesion::sesionCreada()) {

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                if (isset($_POST['publicarNegocio'])) {
                    $negocioNuevo = [
                        'titulo_oferta' => trim($_POST['titulo_oferta']),
                        'titulo_negocio' => trim($_POST['titulo']),
                        'id_municipio' => trim($_POST['municipio_negocio']),
                        'coste_traspaso' => trim($_POST['coste_traspaso']),
                        'coste_mensual' => ($_POST['coste_mensual']),
                        'descripcion_negocio' => trim($_POST['descripcion_negocio']),
                        'descripcion_oferta' => trim($_POST['descripcion_oferta']),
                        'condiciones' => trim($_POST['condiciones']),
                        'id_entidad' => trim($_POST['id_entidad']),
                        'metros_cuadrados' => trim($_POST['metros_cuadrados']),
                        'descripcion_inmueble' => trim($_POST['descripcion_inmueble']),
                        'aforo' => trim($_POST['aforo']),
                        'recursos' => trim($_POST['recursos']),
                        'direccion' => trim($_POST['direccion']),
                        'local' => trim($_POST['negocioLocal']),
                    ];
                    //  print_r($negocioNuevo);exit;

                    if (isset($_FILES['archivo']) && is_array($_FILES['archivo']['name'])) {
                        $fotosInmueble = $_FILES;
                    } else {
                        echo "No se han recibido archivos correctamente.";
                        // exit;
                    }
                    if ($this->ofertaModelo->insertarNegocio($negocioNuevo, $fotosInmueble)) {
                        redireccionar("misOfertas");
                    } else {
                        redireccionar("misOfertas");
                    }
                }
            } else {
                $cont = $this->usuarioModelo->contEntidades($this->datos['usuarioSesion']->id_usuario);
                if ($cont->entidades == 0) {
                    redireccionar("../Usuarios/crearEntidad");
                }
                $this->datos["entidadesUsuario"] = $this->usuarioModelo->obtenerEntidades($this->datos['usuarioSesion']->id_usuario);
                $this->datos["pueblos"] = $this->puebloModelo->obtenerPueblos();
                $this->datos["estado"] = $this->ofertaModelo->obtenerEstados();
                $this->vista("ofertas/publicarNegocio", $this->datos);
            }
        } else {
            redireccionar("Login");
        }
    }

    public function publicarInmueble()
    {
        if (Sesion::sesionCreada()) {

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {

                if (isset($_POST['publicarInmueble'])) {
                    $inmuebleNuevo = [
                        'metros_cuadrados' => trim($_POST['metros_cuadrados']),
                        'descripcion_inmueble' => trim($_POST['descripcion_inmueble']),
                        'id_municipio' => trim($_POST['municipio_inmueble']),
                        'direccion' => trim($_POST['direccion']),
                        'estado' => trim($_POST['estado']),
                        'precio' => trim($_POST['precio']),
                        'n_habitaciones' => trim($_POST['n_habitaciones']),
                        'n_banos' => trim($_POST['n_banos']),
                        'inmueble' => trim($_POST['tipoInmueble']),
                        'tipo_vivienda' => trim($_POST['tipo_vivienda']),
                        'viviendaGaraje' => trim($_POST['viviendaGaraje']),
                        'condiciones' => trim($_POST['condiciones']),
                        'id_entidad' => trim($_POST['id_entidad']),
                        'aforo' => trim($_POST['aforo']),
                        'recursos' => trim($_POST['recursos']),
                        // 'fotos' => trim($_POST['fotos']),
                    ];
                    // print_r($_FILES['archivo']);exit;
                    if (isset($_FILES['archivo']) && is_array($_FILES['archivo']['name'])) {
                        $fotosInmueble = $_FILES;
                    } else {
                        echo "No se han recibido archivos correctamente.";
                        // exit;
                    }


                    if ($this->ofertaModelo->insertarInmueble($inmuebleNuevo, $fotosInmueble)) {
                        redireccionar("misOfertas");
                    } else {
                        redireccionar("misOfertas");
                    }
                }
            } else {
                $cont = $this->usuarioModelo->contEntidades($this->datos['usuarioSesion']->id_usuario);
                if ($cont->entidades == 0) {
                    redireccionar("../Usuarios/crearEntidad");
                }
                $this->datos["entidadesUsuario"] = $this->usuarioModelo->obtenerEntidades($this->datos['usuarioSesion']->id_usuario);
                $this->datos["pueblos"] = $this->puebloModelo->obtenerPueblos();
                $this->datos["estado"] = $this->ofertaModelo->obtenerEstados();
                $this->vista("ofertas/publicarInmueble", $this->datos);
            }
        } else {
            redireccionar("Login");
        }
    }

    public function inscribirseOferta($idOferta)
    {
        $this->vistaApi($this->ofertaModelo->inscribirseOferta($idOferta, $this->datos['usuarioSesion']->id_usuario));
    }

    public function cancelarInscripcionOferta($idOferta)
    {
        $this->vistaApi($this->ofertaModelo->cancelarInscripcionOferta($idOferta, $this->datos['usuarioSesion']->id_usuario));
    }

    public function verOfertas()
    {


        // $this->datos["negocio"] = $this->ofertaModelo->obtenerNegocios($this->datos['negocioSesion']->id_negocio);
        // $this->datos["local"] = $this->ofertaModelo->obtenerLocales($this->datos['localSesion']->id_local);
        // $this->datos["vivienda"] = $this->ofertaModelo->obtenerViviendas($this->datos['viviendaSesion']->id_vivienda);
        if (Sesion::sesionCreada()) {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {

                if (isset($_POST['inscribirse'])) {
                    $idOferta = $_POST['id_oferta'];
                    $this->ofertaModelo->inscribirseOferta($idOferta, $this->datos['usuarioSesion']->id_usuario);
                    redireccionar(('Ofertas/verOfertas'));
                }
                if (isset($_POST['caninscripcion'])) {
                    $idOferta = $_POST['id_oferta'];
                    $this->ofertaModelo->cancelarInscripcionOferta($idOferta, $this->datos['usuarioSesion']->id_usuario);
                    redireccionar(('Ofertas/verOfertas'));
                }
            } else {
                $this->datos["ofertas"] = $this->ofertaModelo->obtenerOfertas();
                $this->datos["ofertasInmuebles"] = $this->ofertaModelo->obtenerInmuebles();
                $this->datos["ofertasNegocios"] = $this->ofertaModelo->obtenerOfertasNegocios($this->datos['usuarioSesion']->id_usuario);
                $this->datos["ofertasLocales"] = $this->ofertaModelo->obtenerOfertasLocales($this->datos['usuarioSesion']->id_usuario);
                $this->datos["ofertasViviendas"] = $this->ofertaModelo->obtenerOfertasViviendas($this->datos['usuarioSesion']->id_usuario);
                $this->datos["estarInscrito"] = $this->ofertaModelo->estarInscrito($this->datos['usuarioSesion']->id_usuario);
                $this->datos['pueblos'] = $this->puebloModelo->obtenerPueblos();
                $this->datos['preciosViviendas'] = $this->ofertaModelo->preciosViviendas();
                $this->datos['preciosNegocios'] = $this->ofertaModelo->preciosNegocios();
                $this->vista("ofertas/verOfertas", $this->datos);
            }
        } else {
            $this->datos["ofertas"] = $this->ofertaModelo->obtenerOfertas();
            $this->datos["ofertasInmuebles"] = $this->ofertaModelo->obtenerInmuebles();
            $this->datos["ofertasNegocios"] = $this->ofertaModelo->obtenerOfertasNegocios();
            $this->datos["ofertasLocales"] = $this->ofertaModelo->obtenerOfertasLocales();
            $this->datos["ofertasViviendas"] = $this->ofertaModelo->obtenerOfertasViviendas();
            $this->datos['pueblos'] = $this->puebloModelo->obtenerPueblos();
            $this->datos['preciosViviendas'] = $this->ofertaModelo->preciosViviendas();
            $this->datos['preciosNegocios'] = $this->ofertaModelo->preciosNegocios();
            $this->vista("ofertas/verOfertas", $this->datos);
        }
    }

    public function misOfertas()
    {
        $this->datos["ofertasInscrito"] = $this->ofertaModelo->obtenerOfertasInscrito($this->datos['usuarioSesion']->id_usuario);
        $this->datos["ofertasNegociosInscrito"] = $this->ofertaModelo->obtenerOfertasNegocios($this->datos['usuarioSesion']->id_usuario);
        $this->datos["ofertasInmueblesInscrito"] = $this->ofertaModelo->obtenerInmuebleInscrito($this->datos['usuarioSesion']->id_usuario);
        $this->datos["ofertasLocalesInscrito"] = $this->ofertaModelo->obtenerLocalesInscrito($this->datos['usuarioSesion']->id_usuario);
        $this->datos["ofertasViviendasInscrito"] = $this->ofertaModelo->obtenerViviendasInscrito($this->datos['usuarioSesion']->id_usuario);
        $this->datos["ofertasUsuario"] = $this->ofertaModelo->obtener_ofertas_usuario($this->datos['usuarioSesion']->id_usuario);

        if (Sesion::sesionCreada()) {
            $this->datos["estarInscrito"] = $this->ofertaModelo->estarInscrito($this->datos['usuarioSesion']->id_usuario);
            $this->datos['pueblos'] = $this->puebloModelo->obtenerPueblos();
            $this->datos['preciosViviendas'] = $this->ofertaModelo->preciosViviendas();
            $this->vista("ofertas/misOfertas", $this->datos);

        } else {
            $this->vista("ofertas/verOfertas");
        }
    }

    public function listadoViviendas()
    {
        $this->vistaApi($this->ofertaModelo->obtenerOfertasViviendas($this->datos['usuarioSesion']->id_usuario));
    }

    public function preciosViviendas()
    {
        $this->vistaApi($this->ofertaModelo->preciosViviendas());
    }

    public function preciosNegocios()
    {
        $this->vistaApi($this->ofertaModelo->preciosNegocios());
    }

    public function Vivienda($arg){
        $this->datos["idVivienda"] = $arg;
        $this->datos["datosVivienda"] = $this->ofertaModelo->detalleVivienda($arg);
        $this->vista("ofertas/detalleInmueble", $this->datos);
    }

    public function Traspaso($arg){
        $this->datos["idVivienda"] = $arg;
        $this->datos["datosVivienda"] = $this->ofertaModelo->detalleTraspaso($arg);
        $this->vista("ofertas/detalleInmueble", $this->datos);
    }

    public function verInscritos($idOferta)
    {
        $this->datos['inscritosOferta'] = $this->ofertaModelo->obtenerInscritos($idOferta);
        $this->vistaAPI($this->datos['inscritosOferta']);
    }

    public function ModificarOferta($idOferta)
    {
     
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {

                $ofertaNueva = [

                    'titulo_oferta' => trim($_POST['titulo']),
                    'condiciones_oferta' => trim($_POST['condiciones']),
                    'descripcion_oferta' => trim($_POST['descripcion']),
                ];

                $this->datos['modificarOferta'] = $this->ofertaModelo->editarOferta($ofertaNueva, $idOferta);
            }
        
        // $this->datos['modificarOferta'] = $this->ofertaModelo->editarOferta($idOferta);
        
    }

    public function apiViviendas()
    {
        if (Sesion::sesionCreada()) {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasViviendas($this->datos['usuarioSesion']->id_usuario));
        } else {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasViviendas());
        }
    }

    public function apiLocales()
    {
        if (Sesion::sesionCreada()) {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasLocales($this->datos['usuarioSesion']->id_usuario));
        } else {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasLocales());
        }
    }

    public function apiNegocios()
    {
        if (Sesion::sesionCreada()) {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasNegocios($this->datos['usuarioSesion']->id_usuario));
        } else {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasNegocios());
        }
    }

    public function apiViviendasInscrito()
    {
        if (Sesion::sesionCreada()) {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasViviendasInscrito($this->datos['usuarioSesion']->id_usuario));
        } else {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasViviendasInscrito());
        }
    }

    public function apiLocalesInscrito()
    {
        if (Sesion::sesionCreada()) {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasLocalesInscrito($this->datos['usuarioSesion']->id_usuario));
        } else {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasLocalesInscrito());
        }
    }

    public function apiNegociosInscrito()
    {
        if (Sesion::sesionCreada()) {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasNegociosInscrito($this->datos['usuarioSesion']->id_usuario));
        } else {
            $this->vistaApi($this->ofertaModelo->obtenerOfertasNegociosInscrito());
        }
    }

    public function apiRutas($idInmueble)
    {

        $path = "/srv/www/api/MVC/public/img/ofertas/" . $idInmueble;
        // Abrimos la carpeta que nos pasan como parámetro
        $dir = opendir($path);
        $rutas = [];
        // Leo todos los ficheros de la carpeta
        while ($elemento = readdir($dir)) {
            if ($elemento != "." && $elemento != "..")  // Si es un archivo
            {
                $ruta = RUTA_IMG_OFER . "/$idInmueble/$elemento";
                array_push($rutas, $ruta);
            }
        }
        closedir($dir); // Cierra el directorio después de leer los archivos
        // $this->vistaApi($rutas);

        echo json_encode($rutas);
    }
}
