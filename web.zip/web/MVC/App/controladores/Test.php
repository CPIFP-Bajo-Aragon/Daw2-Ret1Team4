<?php

class Test extends Controlador
{

    private $ofertaModelo;
    private $usuarioModelo;
    private $puebloModelo;
    
    public function __construct()
    {
        $this->ofertaModelo = $this->modelo('OfertaModelo');
        $this->usuarioModelo = $this->modelo('UsuarioModelo');
        $this->puebloModelo = $this->modelo('PuebloModelo');

        if (Sesion::sesionCreada()) {
            Sesion::iniciarSesion($this->datos);
            $this->datos["notificaciones"] = $this->usuarioModelo->notificaciones($this->datos['usuarioSesion']->id_usuario);
            $this->datos["notificacionesUsuario"] = $this->usuarioModelo->obtenerNotificaciones($this->datos['usuarioSesion']->id_usuario);
            $this->datos["entidadesUsuario"]=$this->usuarioModelo->obtenerEntidades($this->datos['usuarioSesion']->id_usuario);
        }
        $this->datos["rolesPermitidos"] = [1];
        $this->datos['menuActivo'] = 1;
    }

    public function index()
    {
        $this->vista("test",$this->datos);
    }

    public function test()
    {
        $this->vista("test");
    }

    public function testLocal()
    {
        $this->vistaApi($this->ofertaModelo->obtenerOfertasLocales($this->datos['usuarioSesion']->id_usuario));
    }

    public function testNegocio()
    {
        $this->vistaApi($this->ofertaModelo->obtenerOfertasNegocios($this->datos['usuarioSesion']->id_usuario));
    }

    public function testOferta_usuario()
    {
        $this->vistaApi($this->ofertaModelo->obtener_ofertas_usuario($this->datos['usuarioSesion']->id_usuario));
    }

    public function testInscrito_usuario()
    {
        $this->vistaApi($this->ofertaModelo->obtenerOfertasInscrito($this->datos['usuarioSesion']->id_usuario));
    }

    public function inscritoVivienda(){
        $this->vistaApi($this->ofertaModelo->obtenerViviendasInscrito($this->datos['usuarioSesion']->id_usuario));
    }

    public function inscritoNegocio(){
        $this->vistaApi($this->ofertaModelo->obtenerNegociosInscrito($this->datos['usuarioSesion']->id_usuario));
    }

    public function apiNotificaciones()
    {
        $this->vistaApi($this->usuarioModelo->obtenerNotificaciones($this->datos['usuarioSesion']->id_usuario));
    }
    public function testImagenes()
    {
        $this->vista("testImagenes");
    }
    public function vivienda($id)
    {
        $this->datos["javier"]=$id;
        $this->vista("testViviendas",$this->datos);
    }

    public function verOfertas()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {

            if (isset($_POST['inscribirse'])) {
                $idOferta = $_POST['id_oferta'];
                $this->ofertaModelo->inscribirseOferta($idOferta, $this->datos['usuarioSesion']->id_usuario);
                redireccionar(('Ofertas/verOfertas'));
            }
            if (isset($_POST['caninscripcion'])) {
                $idOferta = $_POST['id_oferta'];
                $this->ofertaModelo->cancelarInscripcionOferta($idOferta, $this->datos['usuarioSesion']->id_usuario);
                redireccionar(('Ofertas/verOfertas'));
            }
        }

        $this->datos["ofertas"] = $this->ofertaModelo->obtenerOfertas2();
        $this->datos["negocio"] = $this->ofertaModelo->obtenerNegocios2();
       

        if (Sesion::sesionCreada()) {
            $this->datos["estarInscrito"] = $this->ofertaModelo->estarInscrito($this->datos['usuarioSesion']->id_usuario);
            $this->datos['pueblos'] = $this->puebloModelo->obtenerPueblos();
            $this->datos['preciosOfertas'] = $this->ofertaModelo->preciosOfertas();
            $this->vista("testOfertas",$this->datos);

        } else {
            $this->datos['pueblos'] = $this->puebloModelo->obtenerPueblos();
            $this->datos['preciosOfertas'] = $this->ofertaModelo->preciosOfertas();
            $this->vista("ofertas/verOfertas", $this->datos);
        }

    }

    
}