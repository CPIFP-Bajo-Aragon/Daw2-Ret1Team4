<?php

class Usuarios extends Controlador
{
    private $usuarioModelo;

    public function __construct()
    {

        $this->usuarioModelo = $this->modelo('UsuarioModelo');

        if (isset($_POST['marcarLeidas'])) {
            // Lógica para marcar las notificaciones como leídas en tu base de datos
            // Puedes utilizar tu lógica actual para actualizar el estado de las notificaciones
            // Asegúrate de manejar los errores y devolver una respuesta adecuada.
            // Ejemplo: 
            // actualizarNotificacionesLeidas($_SESSION['usuario_id']);
            // echo json_encode(['success' => true]); // O algún otro formato de respuesta
        }


        if (Sesion::sesionCreada()) {
            Sesion::iniciarSesion($this->datos);
            $this->datos["notificaciones"] = $this->usuarioModelo->notificaciones($this->datos['usuarioSesion']->id_usuario);
            $this->datos["notificacionesUsuario"] = $this->usuarioModelo->obtenerNotificaciones($this->datos['usuarioSesion']->id_usuario);
        }

        $this->datos["rolesPermitidos"] = [10, 20];
        $this->datos['menuActivo'] = 1;
    }

    public function index()
    {
        if (Sesion::sesionCreada()) {
            redireccionar("/ofertas/verOfertas");
        } else {
            $this->vista("inicio_no_loggeado");
        }
    }

    public function miPerfil()
    {
        if (Sesion::sesionCreada()) {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                if (isset($_FILES['archivo']) && is_array($_FILES['archivo']['name'])) {
                    $docs = $_FILES;
                    
                    $nif = $this->datos['usuarioSesion']->nif;

                    foreach ($docs["archivo"]['tmp_name'] as $key => $tmp_name) {
                        //Validamos que el archivo exista
                        if ($docs["archivo"]["name"][$key]) {
                            $filename = $docs["archivo"]["name"][$key]; //nombre original del archivo
                            $source = $docs["archivo"]["tmp_name"][$key]; //nombre temporal del archivo

                            $directorio = '/srv/www/api/MVC/public/usuarios/' . $nif . '/docs/';
                            //ruta donde guardaremos los archivos

                            //Validamos si la ruta de destino existe, en caso de no existir la creamos
                            if (!file_exists($directorio)) {
                                mkdir($directorio, 0777) or die("No se puede crear el directorio de extracción");
                            }

                            $dir = opendir($directorio); //Abrimos el directorio de destino
                            $target_path = $directorio . '/' . $filename; //ruta de destino y el nombre del archivo


                            //El primer campo es el origen y el segundo el destino
                            if (move_uploaded_file($source, $target_path)) {
                            } else {
                                return false;
                            }
                            closedir($dir); //Cerramos el directorio de destino
                        }
                    }
                } else {
                    echo "No se han recibido archivos correctamente.";
                    // exit;
                }


                redireccionar(('/Usuarios/miPerfil'));
            } else {
                $this->vista("usuarios/miPerfil", $this->datos);
            }
        } else {
            $this->vista("ofertas/verOfertas");
        }
    }

    public function editarMiPerfil()
    {
        if (Sesion::sesionCreada()) {

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {

                $usuarioNuevo = [
                    'nombre' => trim($_POST['nombre']),
                    'apellidos' => trim($_POST['apellidos']),
                    'correo' => trim($_POST['correo']),
                    'tlfn' => trim($_POST['tlfn']),
                ];

                $this->usuarioModelo->cambiarInfoUsuario($usuarioNuevo, $this->datos['usuarioSesion']->id_usuario);
                $cambiarUsuarioSesion = $this->usuarioModelo->obtenerUsuario($this->datos['usuarioSesion']->id_usuario);
                Sesion::actualizarSesion($this->datos, $cambiarUsuarioSesion);
                redireccionar(('/Usuarios/miPerfil'));
            } else {
                $this->vistaApi($this->usuarioModelo->obtenerUsuario($this->datos['usuarioSesion']->id_usuario));
            }
        } else {
            $this->vista("ofertas/verOfertas");
        }
    }

    public function editarClave()
    {
        if (Sesion::sesionCreada()) {

            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                $this->usuarioModelo->cambiarClaveUsuario($this->datos['usuarioSesion']->id_usuario);
            }
        } else {
            $this->vista("ofertas/verOfertas");
        }
        Sesion::cerrarSesion();
        redireccionar("/Ofertas/verOfertas");
    }

    public function notificaciones()
    {
        if (isset($_GET['check_notis'])) {
            $this->vista("inicio", $this->datos);
        }

        if (Sesion::sesionCreada()) {

            $this->datos['todasNotificaciones'] = $this->usuarioModelo->obtenerTodasNotificaciones($this->datos['usuarioSesion']->id_usuario);

            $this->vista("usuarios/notificaciones", $this->datos);
        } else {
            $this->vista("inicio");
        }
    }

    public function verTodasNotificaciones()
    {
        $this->vistaApi($this->usuarioModelo->obtenerNotificacionesUsuario($this->datos['usuarioSesion']->id_usuario));
    }


    public function registroUsuario($error = "")
    {
        if (Sesion::sesionCreada()) {
            redireccionar("/Usuarios", $this->datos);
        } else {
            if ($_SERVER['REQUEST_METHOD'] == 'POST') {

                $claveEncriptada = hash('sha256', $_POST['clave']);

                $usuarioNuevo = [
                    'Nif' => trim($_POST['NIF']),
                    'Nombre' => trim($_POST['username']),
                    'Apellidos' => trim($_POST['apellidos']),
                    'Email' => trim($_POST['email']),
                    'FechaN' => ($_POST['FechaN']),
                    'TELF' => trim($_POST['TELF']),
                    'Clave' => trim($claveEncriptada),
                ];

                // TO-DO: Eliminar si funciona Asíncrono.
                // $existe = $this->usuarioModelo->existeUsuario($usuarioNuevo);
                // if($existe > 0) {
                //     redireccionar("/usuarios/registroUsuario/errorNif");
                // }

                $ejecucion = $this->usuarioModelo->registroUsuario($usuarioNuevo);
                if ($ejecucion == true) {
                    Mailer::sendEmail($usuarioNuevo['Email'], $usuarioNuevo['Nombre']);
                    $estructuraDoc = './usuarios/' . $usuarioNuevo['Nif'] . '/docs';
                    $estructuraImg = './usuarios/' . $usuarioNuevo['Nif'] . '/imgs';
                    if (!mkdir($estructuraDoc, 0777, true)) {
                        die('Fallo al crear las carpetas...');
                    }
                    if (!mkdir($estructuraImg, 0777, true)) {
                        die('Fallo al crear las carpetas...');
                    }
                    // redireccionar("/Login");
                }
            } else {
                $this->datos['error'] = $error;
                $this->vista("usuarios/registroUsuario", $this->datos);
            }
        }
    }

    public function recuperarContrasena()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $contrasena = "contrasenaCambiada1";
            $contrasenaEnc = hash('sha256', $contrasena);
            $obj = [
                'correo' => $email = trim($_POST['email']),
                'contrasena' => $contrasenaEnc
            ];
            Mailer::recuperar($email, $contrasena);
            if ($this->usuarioModelo->recuperaContrasena($obj)) {
                echo "se ha enviado un mensaje";
            }
        } else {
            $this->vista("usuarios/recuperar", $this->datos);
        }
    }

    public function entidades()
    {
        if (Sesion::sesionCreada()) {
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['anadir'])) {
                $gerente = [
                    'nif' => trim($_POST['nif']),
                    'id_ent' => trim($_POST['id_ent']),
                ];
                if ($this->usuarioModelo->anadirGerente($gerente)) {
                    redireccionar('/Usuarios/entidades');
                } else {
                    redireccionar('/Usuarios/entidades');
                }
            } else {
                $this->datos["entidadesUsuario"] = $this->usuarioModelo->obtenerEntidades($this->datos['usuarioSesion']->id_usuario);
                $this->vista("usuarios/entidades", $this->datos);
            }
        } else {
            $this->vista("inicio");
        }
    }



    public function crearEntidad()
    {
        if (Sesion::sesionCreada()) {
            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['enviar'])) {
                $nuevaentidad = [
                    'Nombre' => trim($_POST['nombre_entidad']),
                    'Cif' => trim($_POST['cif']),
                    'Sector' => trim($_POST['sector']),
                    'Direccion' => ($_POST['direccion']),
                    'tlf' => trim($_POST['telf']),
                    'Correo' => trim($_POST['correo']),
                    'Web' => trim($_POST['web']),
                ];

                if ($this->usuarioModelo->insertarEntidad($nuevaentidad, $this->datos['usuarioSesion']->id_usuario)) {
                    redireccionar('/Usuarios/entidades');
                } else {
                    redireccionar('/Usuarios/entidades');
                }
            } else {
                $this->vista("usuarios/crearEntidad", $this->datos);
            }
        } else {
            $this->vista("inicio");
        }
    }

    public function delegarAdmin()
    {
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['enviar']) && isset($_POST['dni'])) {
            $dni = $_POST['dni'];
            $usuario = $this->usuarioModelo->obtenerIdUsuario($dni);

            $this->usuarioModelo->actualizarRol($usuario->id_usuario);
        }
        $this->vista("usuarios/delegarAdmin", $this->datos);
    }
    public function estadisticas()
    {
        $this->vista("usuarios/verEstadisticas", $this->datos);
    }

    public function eliminarEntidad($id)
    {
        $this->vistaApi($this->usuarioModelo->eliminarEntidad($id));
    }
    public function eliminarGerente($id_usu, $id_ent)
    {
        $this->vistaApi($this->usuarioModelo->eliminarGerente($id_usu, $id_ent));
    }
    public function gerentes($id)
    {
        $this->vistaApi($this->usuarioModelo->gerentes($id));
    }
    public function consulta()
    {
        $this->vistaApi($this->usuarioModelo->consulta());
    }
    public function existeUser($dato)
    { //Async
        echo $this->usuarioModelo->existeUnique($dato);
    }
    public function borrardoc($elemento){
        if(borrar_directorio($elemento,$this->datos['usuarioSesion']->nif)){
            redireccionar("../../Usuarios/miPerfil");
        }
    }
}
