<script>
//recoger datos de la sesion
var nombre = sessionStorage.getItem('nombre');
var apellidos = sessionStorage.getItem('apellidos');
var fechaNacimiento = sessionStorage.getItem('fecha_nacimiento');
var telefono = sessionStorage.getItem('telefono');
var email = sessionStorage.getItem('email');
var nif = sessionStorage.getItem('nif');

// utilizar los datos de la session en algun formulario

// if (nombre) {
//     document.getElementById('nombre').value = nombre;
// }
// if (apellidos) {
//     document.getElementById('apellidos').value = apellidos;
// }
// if (fechaNacimiento) {
//     document.getElementById('fecha_nac').value = fechaNacimiento;
// }
// if (telefono) {
//     document.getElementById('telefono').value = telefono;
// }
// if (email) {
//     document.getElementById('email').value = email;
// }
// if (nif) {
//     document.getElementById('nif').value = nif;
// }

//session storage

var nombre = document.getElementById('nombre').textContent.split(': ')[1];
var apellidos = document.getElementById('apellidos').textContent.split(': ')[1];
var fechaNacimiento = document.getElementById('fecha_nac').textContent.split(': ')[1];
var telefono = document.getElementById('telefono').textContent.split(': ')[1];
var email = document.getElementById('email').textContent.split(': ')[1];
var nif = document.getElementById('nif').textContent.split(': ')[1];


sessionStorage.setItem('nombre', nombre);
sessionStorage.setItem('apellidos', apellidos);
sessionStorage.setItem('fecha_nacimiento', fechaNacimiento);
sessionStorage.setItem('telefono', telefono);
sessionStorage.setItem('email', email);
sessionStorage.setItem('nif', nif);

//borrar datos de sesion
sessionStorage.clear();
</script>
