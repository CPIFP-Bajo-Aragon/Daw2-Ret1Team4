<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>


<div id="cont" class="container d-flex flex-column align-items-center w-70 p-3 mt-5 rounded-3">
    <h1 class="d-block mb-4" style="color: black">Publicar una oferta</h1>
    <form method="POST" class="d-flex flex-column">
        <div class="mb-3">
            <input type="text" class="form-control" name="titulo_oferta" id="titulo_oferta" placeholder="Título de la oferta">
            </div>
            <p style="color: white; text-align:center">Tipo de oferta</p>


            <div class="d-flex justify-content-center flex-row mb-3">
            <input type="radio" class="form-check-input btn-check mr-2" id="radioNegocio" name="radio" value="N" onchange="showContent()">
            <label class="form-check-label btn btn-outline-dark mr-2" for="radioNegocio">Negocio</label>

              <input type="radio" class="form-check-input btn-check mr-2" id="radioLocal" name="radio" value="L" onchange="showContent()">
            <label class="form-check-label btn btn-outline-dark mr-2" for="radioLocal">Local</label>

             <input type="radio" class="form-check-input btn-check" id="radioVivienda" name="radio" value="V" onchange="showContent()">
            <label class="form-check-label btn btn-outline-dark" for="radioVivienda">Vivienda</label>

            <input type="hidden" name="tipo_oferta" id="tipo_oferta" value="">
         </div>


        <div id="formularioInmuebleLocal" style="display: none;" class="mw-70 p-4 rounded-3 mb-4">
            <h3 class="mb-4">Datos local</h3>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Información básica</h5>
                                <div class="mb-3">
                                    <label for="metros_cuadrados_local" class="form-label">Metros cuadrados</label>
                                    <input type="text" class="form-control" id="metros_cuadrados_local" name="metros_cuadrados_local" placeholder="Metros cuadrados">
                                </div>
                                <div class="mb-3">
                                    <label for="distribucion_local" class="form-label">Distribución</label>
                                    <input type="text" class="form-control" id="distribucion_local" name="distribucion_local" placeholder="Distribución">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Detalles adicionales</h5>
                                <div class="mb-3">
                                    <label for="descripcion_local" class="form-label">Descripción</label>
                                    <input type="text" class="form-control" id="descripcion_local" name="descripcion_local" placeholder="Descripción">
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="direccion_local" class="form-label">Dirección</label>
                                        <input type="text" class="form-control" id="direccion_local" name="direccion_local" placeholder="Dirección">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="precio_local" class="form-label">Precio</label>
                                        <input type="text" class="form-control" id="precio_local" name="precio_local" placeholder="Precio">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="caracteristicas_local" class="form-label">Características</label>
                                        <input type="text" class="form-control" id="caracteristicas_local" name="caracteristicas_local" placeholder="Características">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="equipamiento_local" class="form-label">Equipamiento</label>
                                        <input type="text" class="form-control" id="equipamiento_local" name="equipamiento_local" placeholder="Equipamiento">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="estado_local" class="form-label">Estado</label>
                                    <select class="form-select" name="estado_local" id="estado_local">
                                    <option value="0" selected>Seleccionar estado</option>
                                        <?php foreach ($datos['estado'] as $estado) : ?>
                                            <option value="<?php echo $estado->id_estado ?>">
                                                <?php echo $estado->estado ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="municipio_local" class="form-label">Municipio</label>
                                    <select class="form-select" name="municipio_local" id="municipio_local">
                                        <?php foreach ($datos['pueblos'] as $pueblo) : ?>
                                            <option value="<?php echo $pueblo->id_municipio ?>">
                                                <?php echo $pueblo->nombre_municipio ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                        <label for="precio_inmueble_local" class="form-label">Precio del inmueble</label>
                                        <input type="text" class="form-control" id="precio_inmueble_local" name="precio_inmueble_local" placeholder="precio del inmueble">
                                    </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="capacidad" class="form-label">Capacidad</label>
                                        <input type="number" class="form-control" id="capacidad" name="capacidad" placeholder="Capacidad">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="recursos" class="form-label">Recursos</label>
                                        <input type="text" class="form-control" id="recursos" name="recursos" placeholder="Recursos">
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Detalles adicionales</h5>
                                <div class="mb-3">
                                    <label for="descripcion_local" class="form-label">Descripción</label>
                                    <input type="text" class="form-control" id="descripcion_local" name="descripcion_local" placeholder="Descripción">
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="direccion_local" class="form-label">Dirección</label>
                                        <input type="text" class="form-control" id="direccion_local" name="direccion_local" placeholder="Dirección">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="precio_local" class="form-label">Precio</label>
                                        <input type="text" class="form-control" id="precio_local" name="precio_local" placeholder="Precio">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="caracteristicas_local" class="form-label">Características</label>
                                        <input type="text" class="form-control" id="caracteristicas_local" name="caracteristicas_local" placeholder="Características">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="equipamiento_local" class="form-label">Equipamiento</label>
                                        <input type="text" class="form-control" id="equipamiento_local" name="equipamiento_local" placeholder="Equipamiento">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="estado_local" class="form-label">Estado</label>
                                    <select class="form-select" name="estado_local" id="estado_local">
                                    <option value="0" selected>Seleccionar estado</option>
                                        <?php foreach ($datos['estado'] as $estado) : ?>
                                            <option value="<?php echo $estado->id_estado ?>">
                                                <?php echo $estado->estado ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="municipio_local" class="form-label">Municipio</label>
                                    <select class="form-select" name="municipio_local" id="municipio_local">
                                        <?php foreach ($datos['pueblos'] as $pueblo) : ?>
                                            <option value="<?php echo $pueblo->id_municipio ?>">
                                                <?php echo $pueblo->nombre_municipio ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                        <label for="precio_inmueble_local" class="form-label">Precio del inmueble</label>
                                        <input type="text" class="form-control" id="precio_inmueble_local" name="precio_inmueble_local" placeholder="precio del inmueble">
                                    </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="capacidad" class="form-label">Capacidad</label>
                                        <input type="number" class="form-control" id="capacidad" name="capacidad" placeholder="Capacidad">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="recursos" class="form-label">Recursos</label>
                                        <input type="text" class="form-control" id="recursos" name="recursos" placeholder="Recursos">
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>




        <div id="formularioInmuebleVivienda" style="display: none;" class="mw-70 p-4 mb-4 rounded-3">
            <h3 class="mb-4">Datos vivienda</h3>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Información básica</h5>
                                <div class="mb-3">
                                    <label for="metros_cuadrados_vivienda" class="form-label">Metros cuadrados</label>
                                    <input type="text" class="form-control" id="metros_cuadrados_vivienda" name="metros_cuadrados_vivienda" placeholder="Metros cuadrados">
                                </div>
                                <div class="mb-3">
                                    <label for="distribucion_vivienda" class="form-label">Distribución</label>
                                    <input type="text" class="form-control" id="distribucion_vivienda" name="distribucion_vivienda" placeholder="Distribución">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Detalles adicionales</h5>
                                <div class="mb-3">
                                    <label for="descripcion_vivienda" class="form-label">Descripción</label>
                                    <input type="text" class="form-control" id="descripcion_vivienda" name="descripcion_vivienda" placeholder="Descripción">
                                </div>
                               
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="direccion_vivienda" class="form-label">Dirección</label>
                                        <input type="text" class="form-control" id="direccion_vivienda" name="direccion_vivienda" placeholder="Dirección">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="precio_vivienda" class="form-label">Precio</label>
                                        <input type="text" class="form-control" id="precio_vivienda" name="precio_vivienda" placeholder="Precio">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="caracteristicas_vivienda" class="form-label">Características</label>
                                        <input type="text" class="form-control" id="caracteristicas_vivienda" name="caracteristicas_vivienda" placeholder="Características">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="equipamiento_vivienda" class="form-label">Equipamiento</label>
                                        <input type="text" class="form-control" id="equipamiento_vivienda" name="equipamiento_vivienda" placeholder="Equipamiento">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="estado_vivienda" class="form-label">Estado</label>
                                    
                                    <select class="form-select" name="estado_vivienda" id="estado_vivienda">
                                    <option value="0" selected>Seleccionar estado</option>
                                        <?php foreach ($datos['estado'] as $estado) : ?>
                                            <option value="<?php echo $estado->id_estado ?>">
                                                <?php echo $estado->estado ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label for="municipio_vivienda" class="form-label">Municipio</label>
                                    <select class="form-select" name="municipio_vivienda" id="municipio_vivienda">
                                        <?php foreach ($datos['pueblos'] as $pueblo) : ?>
                                            <option value="<?php echo $pueblo->id_municipio ?>">
                                                <?php echo $pueblo->nombre_municipio ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                        <label for="precio_inmueble_vivienda" class="form-label">Precio del inmueble</label>
                                        <input type="number" class="form-control" id="precio_inmueble_vivienda" name="precio_inmueble_vivienda" placeholder="precio del inmueble">
                                    </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="habitaciones_vivienda" class="form-label">Habitaciones</label>
                                        <input type="number" class="form-control" id="habitaciones_vivienda" name="habitaciones_vivienda" placeholder="Habitaciones">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="tipo_vivienda" class="form-label">Tipo</label>
                                        <input type="text" class="form-control" id="tipo_vivienda" name="tipo_vivienda" placeholder="Tipo">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div id="formularioNegocio" style="display: none;">
            <h3 class="mb-4">Datos negocio</h3>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Información general</h5>
                                <div class="mb-3">
                                    <label for="titulo" class="form-label">Título</label>
                                    <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Título">
                                </div>
                                
                                <div class="mb-3">
                                    <label for="motivo_traspaso" class="form-label">Motivo del traspaso</label>
                                    <input type="text" class="form-control" id="motivo_traspaso" name="motivo_traspaso" placeholder="Motivo del traspaso">
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="coste_traspaso" class="form-label">Coste del traspaso</label>
                                        <input type="number" class="form-control" id="coste_traspaso" name="coste_traspaso" placeholder="Coste del traspaso">
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="coste_mensual" class="form-label">Coste Mensual</label>
                                        <input type="number" class="form-control" id="coste_mensual" name="coste_mensual" placeholder="Coste Mensual">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Detalles adicionales</h5>
                                
                                <div class="mb-3">
                                    <label for="descripcion" class="form-label">Descripción</label>
                                    <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripción">
                                </div>
                                <div class="mb-3">
                                    <label for="capital_minimo" class="form-label">Capital Mínimo</label>
                                    <input type="number" class="form-control" id="capital_minimo" name="capital_minimo" placeholder="Capital Mínimo">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <div class="mb-4">
            <label for="Inicio" class="form-label" style="color: white">Fecha de Inicio:</label>
            <input type="date" class="form-control" name="Inicio" id="Inicio">
        </div>
        <div class="mb-4">
            <label for="Fin" class="form-label" style="color: white">Fecha final:</label>
            <input type="date" class="form-control" name="Fin" id="Fin">
        </div>

        <div class="mb-3">
            <input type="text" class="form-control" name="condiciones" id="Condiciones" placeholder="Condiciones">
        </div>

        <div class="mb-3">
            <label for="id_entidad" class="form-label">Entidad</label>
            <select class="form-select" name="id_entidad" id="id_entidad">
            <?php foreach ($datos['entidadesUsuario'] as $entidad) : ?>
                <option value="<?php echo $entidad->id_entidad ?>">
                 <?php echo $entidad->nombre_entidad ?>
                </option>
                <?php endforeach ?>

                </select>
        </div>

        <input type="submit" class="btn btn-primary" name="registrarse" value="Enviar">

    </form>

    <script src="<?php echo RUTA_URL ?>/js/publicarOferta.js">
    <?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>






    