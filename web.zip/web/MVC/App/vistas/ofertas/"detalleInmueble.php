<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>

<div class="container-fluid  h-100">

    <div class="col h-100">

        
        <div class="row h-50 row-cols-1">
            <div class="col bg-success">
                <img style="max-width:100%; height: 100%; object-fit: cover" src="<?php echo RUTA_IMG_OFER ?>/16/img1.jpg" class="" alt=".">
            </div>
        </div>
        <div class="row row-cols-2">
            <div class="col bg-danger">a</div>
            <div class="col bg-success">a</div>
        </div>
        <div class="row row-cols-4">
            <div class="col-6 bg-success">a</div>
            <div class="col-6 bg-danger">a</div>
        </div>
    </div>
</div>