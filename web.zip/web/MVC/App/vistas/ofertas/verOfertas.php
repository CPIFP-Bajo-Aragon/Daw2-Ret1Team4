<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
    <script>let usuarioSesion = "1";</script>
    <?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
    <script>usuarioSesion = "0";</script>
<?php endif; ?>

<?php
$min = $datos['preciosViviendas'][0]->min_precio;
$max = $datos['preciosNegocios'][0]->max_precio;
?>



<link href="/css/filtrosOfertas.css" rel="stylesheet">
<link href="/css/tarjetasOfertas.css" rel="stylesheet">

<div class="container mt-3">
    <h2>OFERTAS</h2>

    <div class="col">
        <div class="container">
            <a href="#demoFiltros" class="btn btn-secondary" data-bs-toggle="collapse">Filtros</a>
            <div id="demoFiltros" class="collapse container">
                <div class="row">
                    <div class="col-4">
                        <div class="range mt-3">
                            <div class="range-slider">
                                <span class="range-selected" style="left:0%; right:0%;"></span>
                                <div class="range-number"></div>
                            </div>
                            <div class="range-input">
                                <input type="range" class="min" min="<?php echo $min ?>" max="<?php echo $max ?>" value="<?php echo $min ?>" step="100">
                                <input type="range" class="max" min="<?php echo $min ?>" max="<?php echo $max ?>" value="<?php echo $max ?>" step="100">
                            </div>
                            <div class="range-price mt-2">
                                <input readonly="readonly" class="col-5" type="text" name="max" value="<?php echo $min ?>">€ /
                                <input readonly="readonly" class="col-5" type="text" name="min" value="<?php echo $max ?>">€
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <select class="form-select" id="select_municipio">
                            <option id="0"> Sin preferencia </option>
                            <?php
                            foreach ($datos["pueblos"] as $pueblo) :
                                echo "<option id=\"" . $pueblo->id_municipio . "\">" . $pueblo->nombre_municipio . "</option>";
                            endforeach;
                            ?>
                        </select>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="V" id="flexCheckVivienda" checked>
                            <label class="form-check-label" for="flexCheckVivienda">Vivienda</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="L" id="flexCheckLocal" checked>
                            <label class="form-check-label" for="flexCheckLocal">Local</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="N" id="flexCheckNegocio" checked>
                            <label class="form-check-label" for="flexCheckNegocio">Negocio</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-radio">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="radioTodas" value="1000000000000000000" checked>
                            <label class="form-check-label" for="radioTodas">Todas</label>
                        </div>
                        <div class="form-radio">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="radioSemana" value="7">
                            <label class="form-check-label" for="radioSemana">Esta semana</label>
                        </div>
                        <div class="form-radio">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="radioMes" value="31">
                            <label class="form-check-label" for="radioMes">Este mes</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container p-3 rounded-3" id="holder">

        </div>
        <div class="container p-3 rounded-3" id="numbers">

        </div>
    </div>
</div>

<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>
<script src="<?php echo RUTA_JS ?>/ofertas.js"></script>
<script src="/js/filtrosOferta.js"></script>
