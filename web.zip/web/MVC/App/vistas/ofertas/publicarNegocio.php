<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>
<link href="<?php echo RUTA_URL . "/css/dragNdrop.css" ?>" rel="stylesheet">

<div id="cont" class="container d-flex flex-column align-items-center w-70 p-3 mt-5 rounded-3">
    <h1 class="d-block mb-4" style="color: black">Traspasar un negocio</h1>
    <form action="" method="POST" enctype="multipart/form-data">
        <div id="formularioNegocio">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="mb-3">
                            <label for="titulo_oferta" class="form-label">Titulo de la oferta</label>
                            <input type="text" class="form-control" id="titulo_oferta" name="titulo_oferta" placeholder="Titulo de la oferta" required>
                        </div>
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Información del Negocio</h5>
                                <div class="mb-3">
                                    <label for="titulo" class="form-label">Nombre del negocio</label>
                                    <input type="text" class="form-control" id="titulo" name="titulo" placeholder="Nombre del negocio" required>
                                </div>
                                <div class="mb-3">
                                    <label for="municipio_negocio" class="form-label">Municipio</label>
                                    <select class="form-select" name="municipio_negocio" id="municipio_negocio" required>
                                        <?php foreach ($datos['pueblos'] as $pueblo) : ?>
                                            <option value="<?php echo $pueblo->id_municipio ?>">
                                                <?php echo $pueblo->nombre_municipio ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="coste_traspaso" class="form-label">Coste del traspaso</label>
                                        <input type="number" class="form-control" id="coste_traspaso" name="coste_traspaso" value="10000" step="500" min="0"  required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="coste_mensual" class="form-label">Gastos mensuales promedio</label>
                                        <input type="number" class="form-control" id="coste_mensual" name="coste_mensual" value="500" min="0"  required>
                                    </div>
                                    <div class="mb-3">
                                        <label for="descripcion_negocio" class="form-label">Descripción del negocio</label>
                                        <textarea class="form-control" rows="5" id="descripcion_negocio" name="descripcion_negocio"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Detalles adicionales</h5>

                                <div class="mb-3">
                                    <label for="descripcion_oferta" class="form-label">Descripción de la oferta</label>
                                    <textarea class="form-control" rows="5" id="descripcion_oferta" name="descripcion_oferta"></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="condiciones" class="form-label">Condiciones</label>
                                    <input type="text" class="form-control" name="condiciones" id="Condiciones" placeholder="Condiciones">
                                </div>
                                <div class="mb-3">
                                    <label for="id_entidad" class="form-label">Entidad</label>
                                    <p><small>Selecciona la entidad a la que le quieres asignar la oferta</small></p>
                                    <select class="form-select" name="id_entidad" id="id_entidad" required>
                                        <?php foreach ($datos['entidadesUsuario'] as $entidad) : ?>
                                            <option value="<?php echo $entidad->id_entidad ?>">
                                                <?php echo $entidad->nombre_entidad ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3" style="display:none">
                        <div class="form-check">
                            <h5>Tu negocio viene:</h5>
                            <input type="radio" class="form-check-input" id="radio1" name="negocioLocal" value="sinlocal" onchange="obtenerValorRadioButton()">SIN LOCAL
                            <label class="form-check-label" for="radio1"></label>
                        </div>
                        <div class="form-check">
                            <input type="radio" class="form-check-input" id="radio2" name="negocioLocal" value="conlocal" checked onchange="obtenerValorRadioButton()">CON LOCAL
                            <label class="form-check-label" for="radio2"></label>
                        </div>
                    </div>
                    <div class="card mb-4" id="datosLocal">
                        <div class="card-body">
                            <h5 class="card-title">Datos Local</h5>
                            <div class="mb-3">
                                <label for="metros_cuadrados" class="form-label">Metros cuadrados</label>
                                <input type="number" class="form-control" id="metros_cuadrados" name="metros_cuadrados" value="100" min="0" required>
                            </div>
                            <div class="mb-3">
                                <label for="descripcion_inmueble" class="form-label">Descripción del local</label>
                                <textarea class="form-control" rows="5" id="descripcion_inmueble" name="descripcion_inmueble"></textarea>
                            </div>
                            <div id="drop-area" ondragover="handleDragOver(event)" ondrop="handleDrop(event)" onclick="selectFiles()">
                                    <p>Arrastra y suelta las imágenes aquí o haz clic para seleccionarlas.</p>
                                    <p><i>*Formato jpg, jpeg o png</i></p>
                                    <input type="file" id="file-input" name="archivo[]" accept="image/*" multiple style="display: none;" onchange="previewImages()">
                                </div>
                                <div id="image-preview"></div>
                            <div class="mb-3">
                                <label for="aforo" class="form-label">Aforo</label>
                                <input type="text" class="form-control" name="aforo" id="aforo" vaue="10 Personas">
                            </div>
                            <div class="mb-3">
                                <label for="recursos" class="form-label">Recursos</label>
                                <input type="text" class="form-control" name="recursos" id="recursos" placeholder="ej:agua y luz">
                            </div>
                            <div class="mb-3">
                                <label for="direccion" class="form-label">Dirección</label>
                                <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Dirección">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <input type="submit" class="btn btn-primary" name="publicarNegocio" value="Enviar">

    </form>
</div>
<script src="<?php echo RUTA_URL . "/js/dragNdrop.js" ?>"></script>

<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>