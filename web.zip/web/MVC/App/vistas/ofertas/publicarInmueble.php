<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>
<link href="<?php echo RUTA_URL . "/css/dragNdrop.css" ?>" rel="stylesheet">

<div id="cont" class="container d-flex flex-column align-items-center w-70 p-3 mt-5 rounded-3">
    <h1 class="d-block mb-4" style="color: black">Publicar un inmueble</h1>
    <form action="" method="POST" enctype="multipart/form-data">
        <div id="formularioNegocio">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Datos del Inmueble</h5>
                                <div class="mb-3">
                                    <label for="metros_cuadrados" class="form-label">Metros cuadrados</label>
                                    <input type="number" class="form-control" id="metros_cuadrados" name="metros_cuadrados" value="100" min="0"  required>
                                </div>
                                <div class="mb-3">
                                    <label for="descripcion_inmueble" class="form-label">Descripción del inmueble</label>
                                    <textarea class="form-control" rows="5" id="descripcion_inmueble" name="descripcion_inmueble"></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="municipio_inmueble" class="form-label">Municipio</label>
                                    <select class="form-select" name="municipio_inmueble" id="municipio_inmueble" required>
                                        <?php foreach ($datos['pueblos'] as $pueblo) : ?>
                                            <option value="<?php echo $pueblo->id_municipio ?>">
                                                <?php echo $pueblo->nombre_municipio ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                                <div class="row">
                                    <div class=" mb-3">
                                        <label for="direccion" class="form-label">Dirección</label>
                                        <input type="text" class="form-control" name="direccion" id="direccion" placeholder="Dirección">
                                    </div>
                                    <div class=" mb-3">
                                        <label for="estado" class="form-label">Estado del inmueble</label>
                                        <input type="text" class="form-control" name="estado" id="estado" placeholder="ej: nuevo, a reformar...">
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="precio" class="form-label">Precio mensual</label>
                                    <input type="number" class="form-control" id="precio" name="precio" value="300" min="0" step="5" required>
                                </div>
                                <!-- <div class="mb-3">
                                    <label for="archivo" class="form-label">Seleccione fotos del inmueble</label>
                                    <input class="form-control" type="file" id="archivo[]" name="archivo[]" multiple="">
                                </div> -->
                                <div id="drop-area" ondragover="handleDragOver(event)" ondrop="handleDrop(event)" onclick="selectFiles()">
                                    <p>Arrastra y suelta las imágenes aquí o haz clic para seleccionarlas.</p>
                                    <p><i>*Formato jpg, jpeg o png</i></p>
                                    <input type="file" id="file-input" name="archivo[]" accept="image/*" multiple style="display: none;" onchange="previewImages()">
                                </div>
                                <div id="image-preview"></div>
                                <div class="mb-3">
                                    <label for="condiciones" class="form-label">Condiciones</label>
                                    <input type="text" class="form-control" name="condiciones" id="condiciones" placeholder="ej: No perros.">
                                </div>
                                <div class="mb-3">
                                    <div class="form-check">
                                        <h5>El inmueble es:</h5>
                                        <input type="radio" class="form-check-input" id="radiovivienda" name="tipoInmueble" value="vivienda" checked onchange="obtenerTipoInmueble()">UNA VIVIENDA
                                        <label class="form-check-label" for="tipoInmueble"></label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" class="form-check-input" id="radiolocal" name="tipoInmueble" value="local" onchange="obtenerTipoInmueble()">UN LOCAL
                                        <label class="form-check-label" for="tipoInmueble"></label>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-12" id="infovivienda">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Detalles de la vivienda</h5>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="n_habitaciones" class="form-label">Nº habitaciones</label>
                                        <input type="number" class="form-control" id="n_habitaciones" name="n_habitaciones" value="0" min="0" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="n_banos" class="form-label">Nº baños</label>
                                        <input type="number" class="form-control" id="n_banos" name="n_banos" value="0" min="0" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="tipo_vivienda" class="form-label">Tipo de vivienda</label>
                                        <select class="form-select" id="tipo_vivienda" name="tipo_vivienda">
                                            <option>Piso</option>
                                            <option>Chalet</option>
                                            <option>Casa</option>
                                            <option>Estudio</option>
                                            <option>Apartamento</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mt-3">
                                        <div class="form-check mb-3">
                                            <input type="radio" class="form-check-input" id="sinGaraje" name="viviendaGaraje" value="sinGaraje" checked>Sin garaje
                                            <label class="form-check-label" for="viviendaGaraje"></label>
                                        </div>
                                        <div class="form-check mb-3">
                                            <input type="radio" class="form-check-input" id="conGaraje" name="viviendaGaraje" value="conGaraje">Con garaje
                                            <label class="form-check-label" for="viviendaGaraje"></label>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label for="id_entidad" class="form-label">Entidad</label>
                                    <p><small>Selecciona la entidad a la que le quieres asignar la oferta</small></p>
                                    <select class="form-select" name="id_entidad" id="id_entidad" required>
                                        <?php foreach ($datos['entidadesUsuario'] as $entidad) : ?>
                                            <option value="<?php echo $entidad->id_entidad ?>">
                                                <?php echo $entidad->nombre_entidad ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-12" id="infolocal" style="display:none">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title">Detalles del local</h5>
                                <div class="mb-3">
                                    <label for="aforo" class="form-label">Aforo</label>
                                    <input type="text" class="form-control" name="aforo" id="aforo" value="5 Personas">
                                </div>
                                <div class="mb-3">
                                    <label for="recursos" class="form-label">Recursos</label>
                                    <input type="text" class="form-control" name="recursos" id="recursos" placeholder="ej:agua y luz">
                                </div>
                                <div class="mb-3">
                                    <label for="id_entidad" class="form-label">Entidad</label>
                                    <p><small>Selecciona la entidad a la que le quieres asignar la oferta</small></p>
                                    <select class="form-select" name="id_entidad" id="id_entidad" required>
                                        <?php foreach ($datos['entidadesUsuario'] as $entidad) : ?>
                                            <option value="<?php echo $entidad->id_entidad ?>">
                                                <?php echo $entidad->nombre_entidad ?>
                                            </option>
                                        <?php endforeach ?>

                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <input type="submit" class="btn btn-primary" name="publicarInmueble" value="Enviar">

    </form>
</div>
<script src="<?php echo RUTA_URL . "/js/dragNdrop.js" ?>"></script>

<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>