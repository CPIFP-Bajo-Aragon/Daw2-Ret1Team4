<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>

<?php
$min = $datos['preciosViviendas'][0]->min_precio;
$max = $datos['preciosViviendas'][0]->max_precio;
?>

<link href="/css/filtrosOfertas.css" rel="stylesheet">
<link href="/css/tarjetasOfertas.css" rel="stylesheet">
<div class="container mt-3">
    <h2>MIS OFERTAS</h2>

    <div class="col">
        <div class="container">
            <div class="d-flex w-25 justify-content-around">
                <a href="#dem2" data-bs-toggle="collapse" id="enCurso" onclick="carga();">En curso</a>
                <a href="#dem3" data-bs-toggle="collapse" id="Inscritas" onclick="cargaInscritos();">Inscritas</a>
                
            </div>

        </div>
            <div class="container p-3 rounded-3" id="holder" >

            </div>

            <div id="contenedor3"  >
                
               
            </div>

            <div id="contenedor2" >
              
              
            </div>

            <div id="modal-container" >
              
              
            </div>
            <div class="container p-3 rounded-3" id="holder">

</div>
<div class="container p-3 rounded-3" id="numbers">

</div>

            <?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>

            <?php echo "<script> minTraspaso =" . $min . "; maxTraspaso=" . $max . "; </script>" ?>
            <script src="<?php echo RUTA_JS ?>/misOfertas.js"></script>
            <!-- <script src="<?php echo RUTA_JS ?>/ofertas.js"></script> -->
            <!-- <script src="/js/filtrosOferta.js"></script> -->