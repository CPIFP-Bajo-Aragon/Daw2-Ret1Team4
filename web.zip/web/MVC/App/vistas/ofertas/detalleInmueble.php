<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>

<link rel="stylesheet" href="<?php echo RUTA_CSS ?>/detalleInmueble.css">

<div class="container-fluid p-0 h-100">
    <div class="d-flex col">
        <div class="col d-flex justify-content-left align-items-center">
        <a class="text-decoration-none text-white" href="<?php echo RUTA_URL ?>/Ofertas/verOfertas">
            <button class="botonAtras btn m-1">
                <i class="bi bi-arrow-bar-left"></i>
                <span class="">VOLVER</span>
            </button>
            </a>
        </div>
    </div>
    <div class="container-fluid">
        <div id="carouselExampleSlidesOnly" class="carousel slide carousel-fade" data-bs-ride="carousel">
            <div class="carousel-inner">
                <?php
                print_r($datos);
                $idInmueble = $datos["datosVivienda"][0]->id_inmueble;
                $path = "/srv/www/api/MVC/public/img/ofertas/" . $idInmueble;
                // Abrimos la carpeta que nos pasan como parámetro
                $dir = opendir($path);

                // Leo todos los ficheros de la carpeta
                $cont = 0;
                while ($elemento = readdir($dir)) {
                    if ($elemento != "." && $elemento != "..")  // Si es un archivo
                    {
                        if ($cont == 0) {
                            $cont++;
                ?>
                            <div class="carousel-item active">
                                <img src="<?php echo RUTA_IMG_OFER . "/$idInmueble/$elemento" ?>" class="d-block w-100" alt="...">
                            </div>
                        <?php
                        } else {
                        ?>
                            <div class="carousel-item">
                                <img src="<?php echo RUTA_IMG_OFER . "/$idInmueble/$elemento" ?>" class="d-block w-100" alt="...">
                            </div>
                <?php
                        }
                    }
                }
                closedir($dir); // Cierra el directorio después de leer los archivos
                ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleSlidesOnly" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleSlidesOnly" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    </div>

    <!-- <div class="container-fluid d-none d-xl-flex" id="visor">
        <div class="row">
            <div class="row-sm-6 col-xl-3 p-sm-3 p-xl-0 m-0">
                <img id="basadisimo" src="<?php echo RUTA_IMG_OFER ?>/16/img1.jpg" alt="">
            </div>
            <div class="row-sm-6 col-xl-6 p-sm-3 p-xl-0 m-0">
                <img id="basadisimo" src="<?php echo RUTA_IMG_OFER ?>/16/img2.jpg" alt="">
            </div>
            <div class="row-sm-12 col-xl-3 p-sm-3 p-xl-0 m-0">
                <div class="row-xl-6">
                    <img id="basadisimo" src="<?php echo RUTA_IMG_OFER ?>/16/img3.jpg" alt="">
                </div>
                <div class="row-xl-6">
                    <img id="basadisimo" src="<?php echo RUTA_IMG_OFER ?>/16/img4.jpg" alt="">
                </div>
            </div>
        </div>
    </div> -->
    <div class="container-fluid col-11 mt-4">
        <div class="row d-none d-xl-flex" id="descInmueble">
            <div class="col-1">
                <h4><b><?php echo $datos['datosVivienda'][0]->precio; ?> / MES</b></h4>
            </div>
            <div class="col-8">
                <h4><b><?php echo $datos['datosVivienda'][0]->titulo_oferta; ?></b></h4>
            </div>
            <div class="col-3 d-flex justify-content-center align-items-center">
                <div class="col-2 d-flex justify-content-end">
                    <!-- <span class="ratingTotal">4.7 / 5</span> -->
                </div>
            </div>
        </div>
        <div class="row mt-2 d-none d-xl-flex">
            <div class="col-1">
            </div>
            <div class="col-8">
                <article class="text-align-justify">
                    <?php echo $datos['datosVivienda'][0]->descripcion_inmueble; ?>
                </article>
            </div>
            <div class="col-2">
                <div class="row align-items-center justify-content-center">
                    <div class="row-9 d-flex justify-content-center">

                    </div>
                </div>
            </div>
        </div>

        <div class="row d-xl-none">
            <h4><b>Piso, en Calle Zaragoza 39, Alcañiz</b></h4>
            <p class="text-justify"> Piso en venta situado en la localidad de Alcañíz, provincia de Teruel. Esta vivienda de segunda mano, cuenta con una superficie de 75 m² distribuidos en salón comedor con salida a terraza, cocina independiente, 2 dormitorios y 1 baño. La vivienda dispone de cocina amueblada y se encuentra ubicada en una zona tranquila de la población, muy cerca del Camino Capuchinos y rodeado de zonas verdes y vistas despejadas. Además cuenta con buenos accesos por carretera mediante la TE-730. Con nuestros servicios podrá encontrar la vivienda que necesita y asegurar su inversión con el mejor de los asesoramientos especializados. Empiece ahora mismo pidiendo más información. Un responsable cercano a usted le atenderá personalmente.
            </p>
        </div>

        <div class="row d-flex d-xl-none justify-content-center">
            <div class="col-6">Precio Alquiler: <h3>330€</h3>
            </div>
            <!-- <div class="col-6">Valoración Vivienda: <h3>4.7 / 5</h3> -->
            </div>
        </div>
        <div class="col-10 d-flex justify-content-center bg-success">
            <input type="radio" id="1" class="ratingRadio" name="rating" value="1"><label for="1"></label>
            <input type="radio" id="2" class="ratingRadio" name="rating" value="2"><label for="2"></label>
            <input type="radio" id="3" class="ratingRadio" name="rating" value="3"><label for="3"></label>
            <input type="radio" id="4" class="ratingRadio" name="rating" value="4"><label for="4"></label>
            <input type="radio" id="5" class="ratingRadio" name="rating" value="5"><label for="5"></label>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    let radio = document.querySelectorAll("input.ratingRadio");
    let label = document.querySelectorAll("label")
    radio.forEach(element => {
        element.addEventListener("change", function() {
            label.forEach(element => {
                element.className = "";
            });
            for (var i = 0; i < this.id; i++) {
                label[i].className = "activo" + this.id;
            }
        })
    });
</script>