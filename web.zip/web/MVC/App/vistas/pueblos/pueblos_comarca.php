<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>
    <div class="container">
        <h1>PUEBLOS DE LA COMARCA</h1>
        

       

        <?php if($datos['usuarioSesion']->id_rol == 20){; ?>
            <button class="btn btn-primary" onclick="openModalAnadirPueblo();">Añadir pueblo</button>
                <?php }; ?>
        <table class="table table-hover text-center">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>CP</th>
            </tr>
        </thead>
        <tbody>
       
        <!-- <button onclick="cargarDatos(<?php echo htmlspecialchars(json_encode($datos['pueblos'])); ?>);">Cargar PHP</button> -->

            <?php foreach ($datos['pueblos'] as $pueblo): ?>

                <tr>
                    <td id="nombre_<?php echo $pueblo->id_municipio ?>">
                    <a class="link " href="<?php echo RUTA_URL ?>/Pueblos/visitar/<?php echo $pueblo->id_municipio ?>"><?php echo $pueblo->nombre_municipio ?></a>
                        
                    </td>
                    <td id="ccpp_<?php echo $pueblo->id_municipio ?>">
                        <?php echo $pueblo->codigo_postal_municipio ?>
                    </td>
                </tr>
                
            <?php endforeach ?>
            
            <!-- <div id="listingTable"></div>
        <a href="javascript:prevPage()" id="btn_prev">Prev</a>
        <a href="javascript:nextPage()" id="btn_next">Next</a>
        page: <span id="page"></span> -->
    </div>
        </tbody>
    </table>
    <div id="modal-container"></div>  

<script src="<?php echo RUTA_URL ?>/js/paginacionCliente.js"></script>
<script src="<?php echo RUTA_JS ?>/anadirPueblos.js"></script>
<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>