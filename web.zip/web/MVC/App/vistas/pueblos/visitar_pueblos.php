<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="" />
<a href="<?php echo RUTA_URL ?>/Pueblos" class="btn btn_light"><i class="bi bi-chevron-double-left">Volver</i></a>

       


 

    <div class="container d-flex">
    
        <div class="cotaniner map-container mw-50 mh-50">
        <h1 class="bg-warning"><?php echo $this->datos['infoPueblo']->nombre_municipio; ?></h1>
                <body onload="ServiciosAPI('<?php echo $this->datos['serviciosPueblo'][0]->id_municipio; ?>', '<?php echo IP_GLOBAL; ?>')">
                    
                </body>
          
                <div id="mi_mapa" class=""></div>

        </div>

        <!-- SERVICIOS -->
        <div class="container map-services">
            <h1 class="text-center">SERVICIOS</h1>
            <?php if($this->datos['usuarioSesion']->id_rol == 20){; ?>
                <button class="btn btn-primary" onclick="openModalAnadirServicio('<?php echo $this->datos['infoPueblo']->id_municipio; ?>', '<?php echo IP_GLOBAL; ?>')">Añadir servicios</button>
                <?php }; ?>
           <div class="table-scrollable">
            <table class="m-auto table table-striped table-hover table-responsive">
                    <thead>
                        <tr>
                            <th class="text-center">Nombre</th>
                            <th class="text-center">Descripcion</th>
                            <th class="text-center">Tipo de servicio</th>
                        </tr>
                    </thead>
                    <tbody>
                        
                        <?php foreach ($datos['serviciosPueblo'] as $servicio) : ?>
                            <tr>
                                <td>
                                    <?php echo $servicio->nombre_servicio ?>
                                </td>
                                <td>
                                    <?php echo $servicio->descripcion_servicio ?>
                                </td>
                                <td>
                                    <?php echo $servicio->nombre_tipo_servicio ?>
                                </td>

                            </tr>

                        <?php endforeach ?>
                    </tbody>
                </table>
           </div>
        </div>
       
        <div id="modal-container"></div>
   

    </div>

   
                <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin=""></script>
<script src="<?php echo RUTA_URL ?>/js/mapas.js"></script>
<script src="<?php echo RUTA_JS ?>/anadirServicios.js"></script>

<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>