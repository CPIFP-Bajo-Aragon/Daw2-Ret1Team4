<!DOCTYPE html>
<html lang="es" class="h-100">

<head>
  <!-- BORRAR -->
  <!-- <meta http-equiv="Expires" content="0">
  <meta http-equiv="Last-Modified" content="0">
  <meta http-equiv="Cache-Control" content="no-cache, mustrevalidate">
  <meta http-equiv="Pragma" content="no-cache"> -->

  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Inicio</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous"> -->

  <!-- <link rel="stylesheet" href="<?php echo RUTA_URL ?>/css/estilos.css"> -->
  <script src="https://kit.fontawesome.com/705ab1f76d.js" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  <!-- <link href="https://cdn.maptiler.com/maptiler-sdk-js/v1.2.0/maptiler-sdk.css" rel="stylesheet" /> -->

</head>
<style>
    body {
      background-image: url("/img/media/bgwhite.jpg") !important;
      background-attachment: fixed;
      background-repeat: no-repeat;
      /* background-color: rgba(227, 112, 36, 0.2) */
    }
</style>
<body class="h-100">
  <header style="background-color: white;">
    <script>
      let ip = location.host
    </script>
    <div style="background-color: #CE7106">
      <div class="container-fluid d-flex justify-content-between">
        <!-- <button id="leerNotis">Leer notificaciones</button> -->
        <button type="button" id="leerNotis" class="btn navbar-brand text-white me-md-5 me-s-3 p-0" data-bs-toggle="popover" title='Notificaciones' data-bs-content="<?php
                                                                                                                                                                      $contenidoHTML = '';
                                                                                                                                                                      foreach ($datos['notificacionesUsuario'] as $notificacion) {
                                                                                                                                                                        $contenidoHTML .= '<div id="' . $notificacion->id_notificacion . '" class="notification-message">';
                                                                                                                                                                        $contenidoHTML .= $notificacion->contenido_notificacion;
                                                                                                                                                                        $contenidoHTML .= '</div>';
                                                                                                                                                                        $contenidoHTML .= '<hr class="notification-separator">';
                                                                                                                                                                      }
                                                                                                                                                                      $contenidoHTML .= '<a href="' . RUTA_URL . '/usuarios/notificaciones">Ver todas</a>';
                                                                                                                                                                      echo htmlspecialchars($contenidoHTML);
                                                                                                                                                                      ?>" data-bs-html="true">
          <?php echo "Tienes <b id='numNotificaciones'>" . ($this->datos["notificaciones"]->notificaciones) . "</b> notificaciones"; ?>
        </button>
      </div>
    </div>
    <nav class="navbar navbar-expand-sm">

      <a class="navbar-brand" href="<?php echo RUTA_URL ?>/"><img src="<?php echo RUTA_MEDIA ?>/logocomarca.png" alt="" width="200px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav ">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" role="button" data-bs-toggle="dropdown">Ofertas</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Ofertas/verOfertas">Ver Ofertas</a></li>
              <li><a class="dropdown-item " href="<?php echo RUTA_URL ?>/Ofertas/misOfertas">Mis ofertas</a></li>
            </ul>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" role="button" data-bs-toggle="dropdown">Publicar</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Ofertas/publicarNegocio">Publicar traspaso negocio</a></li>
              <li><a class="dropdown-item " href="<?php echo RUTA_URL ?>/Ofertas/publicarInmueble">Publicar inmueble</a></li>
            </ul>
          </li>

          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="" role="button" data-bs-toggle="dropdown">Nuestros Pueblos</a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Pueblos">Ver pueblos</a></li>
            </ul>
          </li>


          <li class="nav-item dropdown d-none d-sm-block d-md-none">
            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
              <b><?php echo $datos["usuarioSesion"]->nombre_usuario; ?></b>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Usuarios/miPerfil">Perfil</a></li>
              <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Usuarios/entidades">Entidades</a></li>
              <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Chat" role="button">Chat</a></li>
              <?php if ($this->datos['usuarioSesion']->id_rol == 20) {; ?>
                <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Usuarios/delegarAdmin" role="button">Añadir administrador</a></li>
                <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Usuarios/estadisticas" role="button">Estadísticas</a></li>
              <?php }; ?>
              <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Login/cerrarSesion">Cerrar sesión</a></li>
            </ul>
          </li>
          <li class="nav-item d-block d-sm-none">
            <a class="nav-link" href="<?php echo RUTA_URL ?>/Usuarios/entidades">Entidades</a>
          </li>
          <li class="nav-item d-block d-sm-none">
            <a class="nav-link" href="<?php echo RUTA_URL ?>/Chat" role="button">Chat</a>
          </li>
          <?php if ($this->datos['usuarioSesion']->id_rol == 20) {; ?>
            <li class="nav-item d-block d-sm-none">
              <a class="nav-link" href="<?php echo RUTA_URL ?>/Usuarios/delegarAdmin" role="button">Añadir administrador</a>
            </li>
            <li class="nav-item d-block d-sm-none">
              <a class="nav-link" href="<?php echo RUTA_URL ?>/Usuarios/estadisticas" role="button">Estadísticas</a>
            </li>
          <?php }; ?>
          <li class="nav-item d-block d-sm-none">
            <a class="nav-link " href="<?php echo RUTA_URL ?>/Usuarios/miPerfil">Perfil</a>
          </li>
          <li class="nav-item d-block d-sm-none">
            <a class="nav-link " href="<?php echo RUTA_URL ?>/Login/cerrarSesion">Cerrar sesion</a>
          </li>
        </ul>
      </div>
      <div class="nav-item dropdown  d-sm-none d-none d-md-block">
        <div class="dropdown-toggle me-md-5 me-s-3" role="button" data-bs-toggle="dropdown">Bienvenido,
          <b><?php echo $datos["usuarioSesion"]->nombre_usuario; ?></b>
        </div>
        <ul class="dropdown-menu">
          <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Usuarios/miPerfil">Perfil</a></li>
          <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Usuarios/entidades">Entidades</a></li>
          <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Chat" role="button">Chat</a></li>
          <?php if ($this->datos['usuarioSesion']->id_rol == 20) {; ?>
            <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Usuarios/delegarAdmin" role="button">Añadir administrador</a></li>
            <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Usuarios/estadisticas" role="button">Estadísticas</a></li>
          <?php }; ?>
          <li><a class="dropdown-item" href="<?php echo RUTA_URL ?>/Login/cerrarSesion">Cerrar sesión</a></li>
        </ul>
      </div>
    </nav>

  </header>