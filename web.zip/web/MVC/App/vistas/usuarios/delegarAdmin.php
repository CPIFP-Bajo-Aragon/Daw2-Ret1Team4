<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>


<div class="container-fluid w-50">
<h3>Hacer administrador</h3>
    <form method="post">
    <div class="m-3">
        <label for="dni" class="form-label">DNI:</label>
    </div>
    <div class="m-3">
        <input type="text" placeholder="DNI" name="dni" id="dni" class="form-control" required>
    </div>
        <input type="submit" class="btn btn-primary" value="Actualizar" name="enviar">
    </form>

</div>










<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>