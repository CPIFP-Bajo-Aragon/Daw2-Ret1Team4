<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>
<div class="container">

    <h1 class="">ENTIDADES</h1>

    <table class="table table-hover">
        <thead>
            <tr>
                <th>Mis entidades</th>
                <th>Rol</th>
                <th>Gestión gerentes</th>
                <!-- <th>Eliminar entidad</th> -->
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datos['entidadesUsuario'] as $entidad) : ?>
                <tr class="">
                    <td>
                        <?php echo $entidad->nombre_entidad ?>
                    </td>
                    <td>
                        <?php echo $entidad->rol ?>
                    </td>

                    <td>
                        <?php if ($entidad->rol == "Administrador") : ?>
                            <button class="btn btn-primary" onclick="gerentes(<?php echo $entidad->id_entidad; ?>)" data-bs-toggle="modal" data-bs-target="#modalEntidad_<?php echo $entidad->id_entidad; ?>"><i class="bi bi-person-fill-gear"></i></a></button>
                        <?php else : ?>
                            <p>No tienes permisos</p>
                        <?php endif; ?>
                    </td>


                    <!-- <td>
                        <?php if ($entidad->rol == "Administrador") : ?>
                        <button class="btn btn-danger" onclick="eliminarEntidad(<?php echo $entidad->id_entidad; ?>)"><i class="bi bi-trash-fill"></i></button>
                        <?php else : ?>
                            <p>No tienes permisos</p>
                        <?php endif; ?>
                    </td> -->

                </tr>

                <!-- MODAL -->
                <div class="modal" id="modalEntidad_<?php echo $entidad->id_entidad; ?>">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">

                            <!-- Modal Header -->
                            <div class="modal-header">
                                <h4>Gestión <?php echo $entidad->nombre_entidad ?></h4>
                            </div>
                            <!-- Modal body -->
                            <div class="modal-body">
                                <h5>Gerentes</h5>
                                <div id="listaGerentes<?php echo $entidad->id_entidad; ?>">
                                
                                </div>
                                <hr>
                                <form method="POST">
                                    <h5>Añadir</h5>
                                    <div class="mb-3 mt-3">
                                        <input type="text" class="form-control" placeholder="NIF del gerente" name="nif" required>
                                    </div>
                                    <div class="mb-3 mt-3">
                                        <input type="text" name="id_ent" value="<?php echo $entidad->id_entidad ?>" hidden>
                                    </div>
                                    <input type="submit" class="btn btn-primary" name="anadir" value="Añadir">
                                </form>

                            </div>

                            <!-- Modal footer -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- MODAL -->

            <?php endforeach ?>
        </tbody>
    </table>
    <a href="<?php echo RUTA_URL ?>/Usuarios/crearEntidad" class="nav-link"><button class="btn btn-primary">Crear entidad</button></a>
</div>





<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>