<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>

<div class="col-10 col-lg-3 col-md-6 text-center">
    <h4>Inmuebles por pueblo</h4>
    <div class="row">
        <canvas id="myChart" class="w-100 h-auto"></canvas>
    </div>
</div>




<script src="<?php echo RUTA_JS ?>/graficos.js"></script>

<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>