<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>
<div class="container">

    <a href="<?php echo RUTA_URL ?>/Usuarios/entidades" class="btn btn_light"><i class="bi bi-chevron-double-left">Volver</i></a>

    <h1 class="">CREAR UNA ENTIDAD</h1>

    <form method="POST">

        <div class="mb-3 mt-3">
            <input type="text" class="form-control" placeholder="Nombre de la entidad" name="nombre_entidad" required>
        </div>
        <div class="mb-3 mt-3">
            <input type="text" class="form-control" placeholder="CIF" name="cif" required>
            <p><small>En caso de no ser una empresa y no tener cif, use su nif</small></p>
        </div>
        <div class="mb-3 mt-3">
            <input type="text" class="form-control" placeholder="Sector de la entidad" name="sector">
        </div>
        <div class="mb-3 mt-3">
            <input type="text" class="form-control" placeholder="Dirección" name="direccion" required>
        </div>
        <div class="mb-3 mt-3">
            <input type="text" class="form-control" placeholder="Número de teléfono" name="telf" required>
        </div>
        <div class="mb-3 mt-3">
            <input type="email" class="form-control" placeholder="Correo" name="correo" required>
        </div>
        <div class="mb-3 mt-3">
            <input type="text" class="form-control" placeholder="Página web" name="web">
        </div>


        <input type="submit" class="btn btn-primary" name="enviar" value="Crear">
    </form>


    <?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>