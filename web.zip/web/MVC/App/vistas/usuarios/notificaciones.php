<?php if(Sesion::sesionCreada()): ?>
<?php require_once RUTA_APP.'/vistas/inc/header_loggeado.php' ?>
<?php else: ?>
<?php require_once RUTA_APP.'/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>
<div class="container">

<h1 class="">NOTIFICACIONES <i class="fa-solid fa-bell" style="color: #FFD43B;"></i></h1>

<table class="table table-hover">
        <thead>
            <tr>
                <th>Contenido</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($datos['todasNotificaciones'] as $notificaciones): ?>
                <?php if($notificaciones->leida_notificacion==0):?>
                <tr class="table-secondary">
                <?php else: ?>
                    <tr class="">
                <?php endif; ?>
                    <td id="id_<?php echo $notificaciones->id_notificacion ?>">
                        <p><?php echo $notificaciones->contenido_notificacion ?></p>
                        <p><?php echo $notificaciones->fecha_notificacion ?></p>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>





<?php require_once RUTA_APP.'/vistas/inc/footer.php' ?>