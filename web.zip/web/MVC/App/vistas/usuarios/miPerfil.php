<?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<link href="<?php echo RUTA_URL . "/css/dragNdrop.css" ?>" rel="stylesheet">

<div id="modal-container"></div>

<div class="container-fluid d-flex justify-content-center mt-3">
    <p>PERFIL</p>
</div>
<div class="container-fluid border border-dark w-50 bg-white text-center">
    <div class="d-flex flex-column">
        <h4 class="mt-3">Información personal</h4>

        <span id="nombre">Nombre: <?php echo $this->datos['usuarioSesion']->nombre_usuario; ?></span>
        <span id="apellidos">Apellidos: <?php echo $this->datos['usuarioSesion']->apellidos_usuario; ?></span>
        <span id="nif">DNI: <?php echo $this->datos['usuarioSesion']->nif; ?></span>
        <h4 class="mt-3">Información de contacto</h4>
        <span id="email">Correo: <?php echo $this->datos['usuarioSesion']->correo_usuario; ?></span>
        <span id="telefono">Teléfono: <?php echo $this->datos['usuarioSesion']->telefono_usuario; ?></span>
    </div>

    <p class="d-flex justify-content-between">
        <button class="btn btn-light border" data-bs-toggle="modal" data-bs-target="#myModal"><span class="d-none d-md-inline">Añadir documentos </span> <i class="bi bi-file-earmark-plus"></i></button>

        <button class="btn btn-light border" onclick="openModalCambiarClave('<?php echo $this->datos['usuarioSesion']->nif; ?>')"><span class="d-none d-md-inline">Cambiar contraseña </span><i class="bi bi-key"></i></button>

        <button class="btn btn-light border" onclick="openModalEditPerfil('<?php  ?>')"><span class="d-none d-md-inline">Editar </span><i class="fa fa-pencil" aria-hidden="true"></i></button>
    </p>

</div>

<div class="container-fluid w-50 mt-4 d-flex justify-content-start">
    <p>Mis documentos <i class="fa fa-file-text-o" aria-hidden="true"></i></p>
</div>
<div id="verMisDocmentos" class="container-fluid w-50 ">
    <?php listarDirectorio($this->datos['usuarioSesion']->nif); ?>
</div>


<!-- The Modal -->
<div class="modal" id="myModal">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header">
                <h4 class="modal-title">Añadir documentos</h4>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <!-- Modal body -->
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div id="drop-area" ondragover="handleDragOver(event)" ondrop="handleDrop(event)" onclick="selectFiles()">
                        <p>Arrastra y suelta los documentos aquí o haz clic para seleccionarlos.</p>

                        <input type="file" id="file-input" name="archivo[]" multiple style="display: none;" onchange="previewImages()">
                    </div>

                    <div id="image-preview"></div>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <input type="submit" name="enviar" class="btn btn-primary mt-2" value="Guardar">
                    <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
            </form>
        </div>

    </div>
</div>
</div>

<script src="<?php echo RUTA_URL . "/js/dragNdrop.js" ?>"></script>
<script src="<?php echo RUTA_URL ?>/js/editarMiPerfil.js"></script>
<script src="<?php echo RUTA_URL ?>/js/guardarStorage.js"></script>

<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>