<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>

<div class="container-fluid mt-5">
    <div class="row justify-content-center">
      <div class="col-md-8 d-flex">
        <div class="container w-25 border border-dark h-100 overflow-auto bg-light">
          <h4 class="text-center">Contactos</h4>
          <!-- CONTACTOS -->
          
          <p class="nav-link border-bottom border-dark usuario-seleccionado">Nueva conversación</p>
          <?php foreach ($this->datos['chatsActivos'] as $key => $chatActivo) {             

          
          if ($this->datos['enlaceEncriptado'] != 0) {
            $cifrado = descifrar_url_aes($this->datos['enlaceEncriptado']);
        } else{
          $cifrado = 0;
        }
          
          ?>
            
            <p><a class="nav-link border-bottom border-dark <?php echo ($cifrado == $chatActivo->otro_usuario) ? 'usuario-seleccionado' : ''; ?>" href='<?php echo RUTA_URL ?>/Chat/index/<?php echo cifrar_url_aes($chatActivo->otro_usuario)?>'><?php echo $chatActivo->nombre_usuario ?></a></p>
          <?php } 

          ?>
       
        </div>
        <div class="chat-container bg-dark w-100" id="chat">
          <!-- MENSAJES -->
         
          <?php foreach ($this->datos['mensajes'] as $key => $mensaje) {
    // Función para dividir el mensaje en líneas de máximo 65 caracteres
    $mensaje_formateado = wordwrap($mensaje->mensaje_chat, 50, "<br>", true);

    if($mensaje->id_usuario == $this->datos['usuarioSesion']->id_usuario){
?>
        <div class="message sent d-flex justify-content-end mb-3">
            <div class="m-3 w-100">
                <p><?php echo $mensaje_formateado; ?></p>
                <p class="chatFecha d-flex align-items-end justify-content-end"><?php echo $mensaje->fecha_chat; ?></p>
            </div>
        </div>
<?php
    } else{
?>
        <div class="message received d-flex justify-content-start mb-3">
            <div class="m-3 w-100">
                <p><?php echo $mensaje_formateado; ?></p>
                <p class="chatFecha d-flex align-items-end justify-content-start"><?php echo $mensaje->fecha_chat; ?></p>
            </div>
        </div>
<?php
    }
} 
?>


      
          
            
          </div>
          
        </div>
        <!-- ENVIAR MENSAJES -->
        <div class="w-50">
        <form class="mt-3" method="POST" name="formChat">
          <div class="mb-3">
            <textarea class="form-control" placeholder="Escribe tu mensaje" name="mensaje_chat" id="mensaje_chat" required></textarea>
          </div>
          <input type="hidden" name="id_usuario" value=''>
          <button type="submit" class="btn btn-primary" id="botonEnviar">Enviar</button>
        </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="<?php echo RUTA_JS ?>/chat.js"></script>
<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>