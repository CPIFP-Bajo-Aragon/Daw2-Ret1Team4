<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>

<link rel="stylesheet" href="<?php echo RUTA_URL ?>/css/carousel.css">
<main>

  <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
    <div class="carousel-indicators">
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
      <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
    </div>
    <div class="carousel-inner">
      <div class="carousel-item active">
      <img class="bd-placeholder-img" src="<?php echo RUTA_MEDIA ?>/alcaniz.jpg" alt="Imagen SVG convertida a IMG">


        <div class="container">
          <div class="carousel-caption text-start bg-dark bg-opacity-25">
            <h1>Conoce la zona</h1>
            <p>Antes de lanzarte a la aventura conoce los maravillosos pueblos de la zona.</p>
            <p><a class="btn btn-lg btn-primary" href="<?php echo RUTA_URL ?>/Pueblos">Observa nuestros mapas</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item">
      <img class="bd-placeholder-img" src="<?php echo RUTA_MEDIA ?>/alcorisa.jpeg" alt="Imagen SVG convertida a IMG">

        <div class="container">
          <div class="carousel-caption bg-dark bg-opacity-25">
            <h1>Lanzate a la aventura</h1>
            <p>No te lo pienses demasiado y obten ya tu inmueble, nosotros te ayudaremos a ello.</p>
            <p><a class="btn btn-lg btn-primary" href="<?php echo RUTA_URL ?>/Usuarios/registroUsuario">Regístrate ya</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item">
      <img class="bd-placeholder-img" src="<?php echo RUTA_MEDIA ?>/calanda.jpg" alt="Imagen SVG convertida a IMG">

        <div class="container">
          <div class="carousel-caption text-end bg-dark bg-opacity-25">
            <h1>Busca oportunidades</h1>
            <p>No tengas prisa, puedes valorar todas las opciones que tenemos en nuestro sistema.</p>
            <p><a class="btn btn-lg btn-primary" href="<?php echo RUTA_URL ?>/Ofertas/verOfertas">Busca ofertas</a></p>
          </div>
        </div>
      </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel" data-bs-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#myCarousel" data-bs-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="visually-hidden">Next</span>
    </button>
  </div>


  <!-- Marketing messaging and featurettes
  ================================================== -->
  <!-- Wrap the rest of the page in another container to center all the content. -->

  <div class="container marketing">

    <!-- Three columns of text below the carousel -->
    <div class="row">
      <div class="col-lg-4">
      <img class="bd-placeholder-img rounded-circle" src="<?php echo RUTA_MEDIA ?>/traspasoNegocio.jpg" alt="Placeholder: 140x140">


        <h2>Traspaso de negocio</h2>
        <p>¿Estás considerando traspasar tu negocio o en busca de una oportunidad de traspaso que te interese? No te preocupes,
             en nuestra página web encontrarás diversas opciones tanto si deseas traspasar tu negocio como si estás en la búsqueda de uno.</p>
      </div><!-- /.col-lg-4 -->
      <div class="col-lg-4">
      <img class="bd-placeholder-img rounded-circle" src="<?php echo RUTA_MEDIA ?>/consigueCasa.jpg" alt="Placeholder: 140x140">

        <h2>Obtén tu vivienda</h2>
        <p>¿Estás pensando en obtener una vivienda? No te preocupes, en nuestra plataforma podrás adquirir tu vivienda ideal.</p>
      </div><!-- /.col-lg-4 -->
      <div class="col-lg-4">
      <img class="bd-placeholder-img rounded-circle" src="<?php echo RUTA_MEDIA ?>/inmueble.jpg" alt="Placeholder: 140x140">

        <h2>Echa un vistazo a los inmuebles</h2>
        <p>En nuestra web disponemos de innumerables inmuebles para que puedas escoger el que más se acerca a lo que estás buscando.</p>
      </div><!-- /.col-lg-4 -->
    </div><!-- /.row -->


    <!-- START THE FEATURETTES -->

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7">
        <h2 class="featurette-heading">Conoce la zona <span class="text-muted"> Observa nuestros mapas.</span></h2>
        <p class="lead">Disponemos de mapas únicos para que puedas ver de los servicios
            que tiene la zona donde adquieras tu próximo inmueble.</p>
      </div>
      <div class="col-md-5">
      <img class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" src="<?php echo RUTA_MEDIA ?>/mapasMovil.jpg" alt="Placeholder: 500x500">


      </div>
    </div>

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7 order-md-2">
        <h2 class="featurette-heading">Permanece siempre alerta<span class="text-muted"> Sistema de notificaciones.</span></h2>
        <p class="lead">No es necesario que tengas que estar revisando todas las ofertas a las que te has suscrito constantemente, ya que gracias
            a nuestro sistema de notificaciones estarás siempre al tanto de las novedades.</p>
      </div>
      <div class="col-md-5 order-md-1">
      <img class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" src="<?php echo RUTA_MEDIA ?>/notificaciones.jpg" alt="Placeholder: 500x500">

      </div>
    </div>

    <hr class="featurette-divider">

    <div class="row featurette">
      <div class="col-md-7">
        <h2 class="featurette-heading">Publica tu oferta <span class="text-muted"> De manera sencilla podrás hacer notar tu oferta</span></h2>
        <p class="lead">Con nuestra plataforma sencilla y eficiente, podrás publicar tu oferta en cuestión de segundos, sin complicaciones ni limitaciones.
             Todo lo necesario para poner en venta tu inmueble estará al alcance de tu mano en nuestra plataforma.
        </p>
      </div>
      <div class="col-md-5">
      <img class="bd-placeholder-img bd-placeholder-img-lg featurette-image img-fluid mx-auto" src="<?php echo RUTA_MEDIA ?>/venderCasa.jpg" alt="Placeholder: 500x500">

      </div>
    </div>

    <hr class="featurette-divider">

    <!-- /END THE FEATURETTES -->

  </div><!-- /.container -->


  <!-- FOOTER -->
  <footer class="container">
    <p class="float-end"><a href="#">Subir a cabecera</a></p>
    <p>&copy; 2023-2024 NYTT, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
  </footer>
</main>


<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>