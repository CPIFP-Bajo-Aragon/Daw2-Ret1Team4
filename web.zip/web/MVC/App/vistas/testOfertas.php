<?php if (Sesion::sesionCreada()) : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_loggeado.php' ?>
<?php else : ?>
    <?php require_once RUTA_APP . '/vistas/inc/header_no_loggeado.php' ?>
<?php endif; ?>

<?php 
    $maxTraspaso = $datos['preciosOfertas'][0]->maxTraspaso;
    $maxAlquiler = $datos['preciosOfertas'][0]->maxAlquiler;
    $minTraspaso = $datos['preciosOfertas'][0]->minTraspaso;
    $minAlquiler = $datos['preciosOfertas'][0]->minAlquiler;
?>

<link href="/css/filtrosOfertas.css" rel="stylesheet">
<div class="container mt-3">
    <h2>OFERTAS</h2>

    <div class="col">
        <div class="container">
            <a href="#demo" class="btn btn-secondary" data-bs-toggle="collapse">Filtros</a>
            <div id="demo" class="collapse container">
                <div class="row">
                    <div class="col-4">
                        <div class="range mt-3">
                            <div class="range-slider">
                                <span class="range-selected" style="left:0%; right:0%;"></span>
                                <div class="range-number"></div>
                            </div>
                            <div class="range-input">
                                <input type="range" class="min" min="<?php echo $minTraspaso ?>" max="<?php echo $maxTraspaso?>" value="<?php echo $minTraspaso ?>" step="1000">
                                <input type="range" class="max" min="<?php echo $minTraspaso ?>" max="<?php echo $maxTraspaso?>" value="<?php echo $maxTraspaso?>" step="1000">
                            </div>
                            <div class="range-price mt-2">
                                <input readonly="readonly" class="col-5" type="text" name="max" value="<?php echo $minTraspaso ?>">€ /
                                <input readonly="readonly" class="col-5" type="text" name="min" value="<?php echo $maxTraspaso?>">€
                            </div>
                        </div>
                    </div>
                    <div class="col-3">
                        <select class="form-select">
                            <option id="0"> Sin preferencia </option>
                            <?php
                            foreach ($datos["pueblos"] as $pueblo) :
                                echo "<option id=\"" . $pueblo->id_municipio . "\">" . $pueblo->nombre_municipio . "</option>";
                            endforeach;
                            ?>
                        </select>
                    </div>
                    <div class="col-2">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="vivienda" id="flexCheckVivienda" checked>
                            <label class="form-check-label" for="flexCheckVivienda">Vivienda</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="local" id="flexCheckLocal" checked>
                            <label class="form-check-label" for="flexCheckLocal">Local</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" value="negocio" id="flexCheckNegocio" checked>
                            <label class="form-check-label" for="flexCheckNegocio">Negocio</label>
                        </div>
                    </div>
                    <div class="col-2">
                        <div class="form-radio">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="radioTodas" value="todas" checked>
                            <label class="form-check-label" for="radioTodas">Todas</label>
                        </div>
                        <div class="form-radio">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="radioSemana" value="semana">
                            <label class="form-check-label" for="radioSemana">Esta semana</label>
                        </div>
                        <div class="form-radio">
                            <input class="form-check-input" type="radio" name="exampleRadios" id="radioMes" value="mes">
                            <label class="form-check-label" for="radioMes">Este mes</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- CAMBIAR URL DE IMAGENES -->
        <?php foreach ($datos["ofertas"] as $oferta) : ?>
            <div class="card m-3">
                <div class="row g-0">
                    <div class="col-md-4 g-0">
                        <img src="<?php echo RUTA_MEDIA ?>/casa.png" class="img-fluid rounded-start" alt="Card image">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $oferta->titulo_oferta; ?></h5>
                            <p class="card-text">
                            <h6><i class="bi bi-pin-fill"></i>Condiciones: <?php echo $oferta->condiciones_oferta; ?></h6>
                            <h6>Descripcion: <?php echo $oferta->descripcion_oferta; ?></h6>
                            <?php foreach ($datos["negocio"] as $negocio) : ?>
                                <p class="card-text"><?php echo $negocio->coste_traspaso_negocio; ?><i class="bi bi-currency-euro"></i></p>
                            <?php endforeach; ?>
                            <button type="button" class="btn btn-primary " data-bs-toggle="modal" data-bs-target="#modalNegocio_<?php echo $oferta->id_oferta; ?>">Ver oferta</button>
                        </div>
                    </div>
                </div>
            </div>


            <!-- MODAL -->
            <div class="modal" id="modalNegocio_<?php echo $oferta->id_oferta; ?>">
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">

                        <!-- Modal Header -->
                        <div class="modal-header">
                            <h4 class="modal-title"><?php echo $oferta->titulo_oferta; ?></h4>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>

                        <!-- Modal body -->
                        <div class="modal-body">
                            <?php foreach ($datos["negocio"] as $negocio) : ?>
                                <p><?php echo $negocio->coste_mensual_negocio; ?><i class="bi bi-currency-euro"></i>/mes</p>
                                <p><?php echo $negocio->capital_minimo_negocio; ?><i class="bi bi-currency-euro"></i> capital mínimo</p>
                            <?php endforeach; ?>
                            <p><?php echo $oferta->descripcion_oferta; ?></p>
                        </div>

                        <!-- Modal footer -->
                        <div class="modal-footer foot-inscribirse" data-id="<?php echo $oferta->id_oferta; ?>">
                            <?php if (Sesion::sesionCreada()) : ?>
                                <?php $on = 0; ?>
                                <?php foreach ($datos["estarInscrito"] as $inscrito) : ?>
                                    <?php if ($inscrito->id_oferta == $oferta->id_oferta) : ?>
                                        <?php $on = 1; ?>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                                <?php if ($on == 1) : ?>
                                    <button class="btn btn-warning btn-caninscripcion" data-id="<?php echo $oferta->id_oferta; ?>">Cancelar inscripción</button>
                                <?php else : ?>
                                    <button class="btn btn-success btn-inscribirse" data-id="<?php echo $oferta->id_oferta; ?>">Inscribirse</button>
                                <?php endif; ?>

                            <?php else : ?>
                                <button class="btn btn-success"><a href="<?php echo RUTA_URL ?>/Login" class="nav-link">Inicia sesión</a></button>
                            <?php endif; ?>
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                        </div>

                    </div>
                </div>
            </div>
            <!-- MODAL -->


        <?php endforeach; ?>



    </div>
</div>



<?php require_once RUTA_APP . '/vistas/inc/footer.php' ?>












<!-- <div class="card m-3">
                <div class="row g-0">
                    <div class="col-md-2 g-0" style="background-image: url('<?php echo RUTA_MEDIA ?>/casa.png'); background-size: cover; background-position: center">
                    </div>
                    <div class="col-md-8">
                        <div class="card-body">
                            <h5 class="card-title">Oferta en alcañiz</h5>
                            <p class="card-text">This is a wider card with supporting text below as a natural lead-in to
                                additional content. This content is a little bit longer.</p>
                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"data-bs-target="#myModal">Open modal</button>
                        </div>
                    </div>

                    <div class="col-md-2 g-0">
                        <div style="display: grid; grid-template-columns: 1fr; grid-template-rows: 1fr; align-items: center; justify-content: center; width: 100%; height: 100%;">
                            <img style="grid-column-start: 0; grid-column-end: 1; width: auto; height: 100%; opacity: 0.3;" src="img/media/casa.png" class="img-fluid" alt="Card image">
                            <img style="grid-column-start: 0; grid-column-end: 1; width: 60%; height: 60%;" src="img/media/casa.png" class="img-fluid" alt="Card image">
                        </div>
                    </div>

                </div>
            </div> -->


<?php echo "<script> minTraspaso =" . $minTraspaso . "; maxTraspaso=" . $maxTraspaso . "; </script>"?>;
<script src="/js/filtrosOferta.js"></script>