<?php

class OfertaModelo
{
    private $db;

    public function __construct()
    {
        $this->db = new Base;
    }

    public function obtenerEstados()
    {
        $this->db->query("SELECT * FROM estado");
        return $this->db->registros();
    }

    public function obtenerOfertas()
    {
        $this->db->query("SELECT * FROM oferta");
        return $this->db->registros();
    }

    public function obtenerUsuarios()
    {
        $this->db->query("SELECT * FROM usuario");
        return $this->db->registros();
    }

    public function obtenerInmuebles()
    {
        $this->db->query("SELECT * FROM oferta o INNER JOIN oferta_inmueble oi ON o.id_oferta = oi.id_oferta INNER JOIN inmueble i ON oi.id_inmueble = i.id_inmueble");

        return $this->db->registros();
    }


    public function obtenerOfertasNegocios($id_usuario = 0)
    {
        $this->db->query("SELECT *, (SELECT COUNT(*) FROM usuario_oferta WHERE id_usuario = '$id_usuario' and usuario_oferta.id_oferta = of.id_oferta) as inscrito FROM oferta AS of INNER JOIN oferta_negocio AS ofn ON of.id_oferta = ofn.id_oferta INNER JOIN negocio AS n ON ofn.id_negocio = n.id_negocio INNER JOIN negocio_local AS nl ON n.id_negocio = nl.id_negocio INNER JOIN local as l on nl.id_inmueble = l.id_inmueble INNER JOIN inmueble AS i on l.id_inmueble = i.id_inmueble INNER JOIN municipio AS m ON m.id_municipio = i.id_municipio WHERE of.activo_oferta = 1; ");
        return $this->db->registros();
    }

    public function obtenerOfertasViviendas($id_usuario = 0)
    {
        $this->db->query("SELECT *, (SELECT COUNT(*) FROM usuario_oferta WHERE id_usuario = '$id_usuario' and usuario_oferta.id_oferta = of.id_oferta) as inscrito FROM (oferta AS of INNER JOIN oferta_inmueble AS ofi ON of.id_oferta = ofi.id_oferta) INNER JOIN inmueble AS inm ON ofi.id_inmueble = inm.id_inmueble INNER JOIN vivienda AS v ON ofi.id_inmueble = v.id_inmueble INNER JOIN municipio AS m ON m.id_municipio = inm.id_municipio WHERE of.activo_oferta = 1 AND of.tipo_oferta = 'I' AND inm.tipo_inmueble = 'V' LIMIT 0,1000");
        return $this->db->registros();
    }

    public function obtenerOfertasLocales($id_usuario = 0)
    {
        $this->db->query("SELECT *, (SELECT COUNT(*) FROM usuario_oferta WHERE id_usuario = '$id_usuario' and usuario_oferta.id_oferta = of.id_oferta) as inscrito FROM (oferta AS of INNER JOIN oferta_inmueble AS ofi ON of.id_oferta = ofi.id_oferta) INNER JOIN inmueble AS inm ON ofi.id_inmueble = inm.id_inmueble INNER JOIN local AS l ON ofi.id_inmueble = l.id_inmueble INNER JOIN municipio AS m ON m.id_municipio = inm.id_municipio WHERE of.activo_oferta = 1");
        return $this->db->registros();
    }

    public function obtenerOfertasNegociosInscrito($id_usuario = 0)
    {
        $this->db->query("SELECT *, (SELECT COUNT(*) FROM usuario_oferta WHERE id_usuario = '$id_usuario' and usuario_oferta.id_oferta = of.id_oferta) as inscrito FROM oferta AS of INNER JOIN oferta_negocio AS ofn ON of.id_oferta = ofn.id_oferta INNER JOIN negocio AS n ON ofn.id_negocio = n.id_negocio INNER JOIN negocio_local AS nl ON n.id_negocio = nl.id_negocio INNER JOIN local as l on nl.id_inmueble = l.id_inmueble INNER JOIN inmueble AS i on l.id_inmueble = i.id_inmueble INNER JOIN municipio AS m ON m.id_municipio = i.id_municipio INNER JOIN usuario_oferta uo ON of.id_oferta=uo.id_oferta INNER JOIN usuario u ON uo.id_usuario=u.id_usuario WHERE of.activo_oferta = 1 AND u.id_usuario='$id_usuario'; ");
        return $this->db->registros();
    }

    public function obtenerOfertasViviendasInscrito($id_usuario = 0)
    {
        $this->db->query("SELECT *, (SELECT COUNT(*) FROM usuario_oferta WHERE id_usuario = '$id_usuario' and usuario_oferta.id_oferta = of.id_oferta) as inscrito FROM (oferta AS of INNER JOIN oferta_inmueble AS ofi ON of.id_oferta = ofi.id_oferta) INNER JOIN inmueble AS inm ON ofi.id_inmueble = inm.id_inmueble INNER JOIN vivienda AS v ON ofi.id_inmueble = v.id_inmueble INNER JOIN municipio AS m ON m.id_municipio = inm.id_municipio INNER JOIN usuario_oferta uo ON of.id_oferta=uo.id_oferta INNER JOIN usuario u ON uo.id_usuario=u.id_usuario WHERE of.activo_oferta = 1 AND u.id_usuario='$id_usuario' AND of.tipo_oferta = 'I' AND inm.tipo_inmueble = 'V' LIMIT 0,1000");
        return $this->db->registros();
    }

    public function obtenerOfertasLocalesInscrito($id_usuario = 0)
    {
        $this->db->query("SELECT *, (SELECT COUNT(*) FROM usuario_oferta WHERE id_usuario = '$id_usuario' and usuario_oferta.id_oferta = of.id_oferta) as inscrito FROM (oferta AS of INNER JOIN oferta_inmueble AS ofi ON of.id_oferta = ofi.id_oferta) INNER JOIN inmueble AS inm ON ofi.id_inmueble = inm.id_inmueble INNER JOIN local AS l ON ofi.id_inmueble = l.id_inmueble INNER JOIN municipio AS m ON m.id_municipio = inm.id_municipio INNER JOIN usuario_oferta uo ON of.id_oferta=uo.id_oferta INNER JOIN usuario u ON uo.id_usuario=u.id_usuario WHERE of.activo_oferta = 1 AND u.id_usuario='$id_usuario'");
        return $this->db->registros();
    }

    public function ocultaOferta($id)
    {
        $this->db->query("UPDATE oferta SET activo_oferta = 0 WEHRE id_oferta = $id");
        return $this->db->registros();
    }

    public function editarOferta($ofertaNueva, $idOferta){
        $this->db->query("UPDATE ofertas SET titulo_oferta = :titulo_oferta, condiciones_ferta = :condiciones_oferta, descripcion_oferta = :descripcion_oferta WHERE id_oferta = $idOferta");
         $this->db->bind(':titulo_oferta', $ofertaNueva['titulo_oferta']);
         $this->db->bind(':condiciones_oferta', $ofertaNueva['condiciones_oferta']);
         $this->db->bind(':descripcion_oferta', $ofertaNueva['descripcion_oferta']);
         $this->db->execute();
    }

    public function estarInscrito($id_usuario)
    {
        $this->db->query("SELECT * FROM usuario_oferta WHERE id_usuario='$id_usuario'");
        return $this->db->registros();
    }

    public function obtenerOfertasInscrito($idUsuario)
    {
        $this->db->query("SELECT u.*, o.*, (SELECT COUNT(*) FROM usuario_oferta WHERE id_usuario = $idUsuario and u.id_oferta = o.id_oferta) as inscrito  FROM oferta AS o  INNER JOIN usuario_oferta AS u ON o.id_oferta = u.id_oferta 
        WHERE o.activo_oferta = 1 AND u.id_usuario = $idUsuario");
        return $this->db->registros();
    }

    public function obtener_ofertas_usuario($idUsuario)
    {
        $this->db->query("SELECT * FROM oferta o INNER JOIN entidad e ON o.id_entidad = e.id_entidad
         INNER JOIN usuario_entidad ue ON e.id_entidad = ue.id_entidad WHERE ue.id_usuario = $idUsuario GROUP BY o.id_oferta");

        return $this->db->registros();

        //    $this->db->query("SELECT * FROM oferta o INNER JOIN usuario_oferta uo ON o.id_oferta = uo.id_oferta
        // INNER JOIN entidad e ON o.id_entidad = e.id_entidad WHERE uo.id_usuario = $idUsuario");
    }





    public function obtenerNegociosInscrito($idUsuario)
    {
        $this->db->query("SELECT * FROM negocio AS n INNER JOIN oferta_negocio AS ofn ON n.id_negocio = ofn.id_negocio
        INNER JOIN oferta AS o ON ofn.id_oferta = o.id_oferta INNER JOIN usuario_oferta AS u ON o.id_oferta = u.id_oferta
        WHERE o.activo_oferta = 1 AND u.id_usuario = $idUsuario");

        return $this->db->registros();
    }

    public function obtenerInmuebleInscrito($idUsuario)
    {
        $this->db->query("SELECT i.*, u.* FROM inmueble AS i INNER JOIN oferta_inmueble AS ofi ON i.id_inmueble = ofi.id_inmueble
        INNER JOIN oferta AS o ON ofi.id_oferta = o.id_oferta INNER JOIN usuario_oferta AS u ON o.id_oferta = u.id_oferta
        WHERE o.activo_oferta = 1 AND u.id_usuario = $idUsuario");

        return $this->db->registros();
    }
    public function obtenerViviendasInscrito($idUsuario)
    {
        $this->db->query("SELECT v.*, ofi.*, o.* FROM vivienda AS v INNER JOIN oferta_inmueble AS ofi ON v.id_inmueble = ofi.id_inmueble
        INNER JOIN oferta AS o ON ofi.id_oferta = o.id_oferta INNER JOIN usuario_oferta AS u ON o.id_oferta = u.id_oferta
        WHERE o.activo_oferta = 1 AND u.id_usuario = $idUsuario");

        return $this->db->registros();
    }

    public function obtenerLocalesInscrito($idUsuario)
    {
        $this->db->query("SELECT * FROM local AS l INNER JOIN oferta_inmueble AS ofi ON l.id_inmueble = ofi.id_inmueble
        INNER JOIN oferta AS o ON ofi.id_oferta = o.id_oferta INNER JOIN usuario_oferta AS u ON o.id_oferta = u.id_oferta
        WHERE o.activo_oferta = 1 AND u.id_usuario = $idUsuario");

        return $this->db->registros();
    }

    // public function detalleVivienda($id)
    // {
    //     $this->db->query("SELECT * FROM (oferta AS of INNER JOIN oferta_inmueble AS ofi ON of.id_oferta = ofi.id_oferta) INNER JOIN inmueble AS inm ON ofi.id_inmueble = inm.id_inmueble INNER JOIN vivienda AS v ON ofi.id_inmueble = v.id_inmueble  WHERE of.activo_oferta = 1 AND v.id_inmueble = $id");
    //     return $this->db->registros();
    // }

    public function detalleVivienda($id)
    {
        $this->db->query("SELECT * 
        FROM oferta
        INNER JOIN oferta_inmueble ON oferta.id_oferta = oferta_inmueble.id_oferta
        INNER JOIN inmueble ON oferta_inmueble.id_inmueble = inmueble.id_inmueble
        INNER JOIN vivienda ON vivienda.id_inmueble = inmueble.id_inmueble and oferta.id_oferta = $id");
        return $this->db->registros();
    }

    public function detalleTraspaso($id)
    {
        $this->db->query("SELECT * 
        FROM oferta
        INNER JOIN oferta_negocio ON oferta.id_oferta = oferta_negocio.id_oferta
        INNER JOIN negocio ON oferta_negocio.id_negocio = negocio.id_negocio
        INNER JOIN negocio_local ON negocio.id_negocio = negocio_local.id_negocio
        INNER JOIN inmueble ON negocio_local.id_inmueble = inmueble.id_inmueble
        INNER JOIN local ON inmueble.id_inmueble = local.id_inmueble
        AND inmueble.id_inmueble = $id");
        return $this->db->registros();
    }

    public function inscribirseOferta($idOferta, $idUsuario)
    {
        $this->db->query("SELECT u.id_usuario FROM usuario u NATURAL JOIN usuario_entidad us NATURAL JOIN entidad e NATURAL JOIN oferta o WHERE o.id_oferta=$idOferta");
        $dat["ids"] = $this->db->registros();

        $this->db->query("SELECT nombre_usuario FROM usuario WHERE id_usuario = $idUsuario;");
        $dato = $this->db->registro();
        $nombreusu = $dato->nombre_usuario;

        $this->db->query("SELECT tipo_oferta FROM oferta WHERE id_oferta = $idOferta;");
        $dato = $this->db->registro();
        $tipo = $dato->tipo_oferta;

        if ($tipo == "I") {
            $this->db->query("SELECT direccion_inmueble FROM inmueble i JOIN oferta_inmueble oi ON i.id_inmueble=oi.id_inmueble JOIN oferta o ON o.id_oferta=oi.id_oferta WHERE o.id_oferta = $idOferta;");
            $dato2 = $this->db->registro();
            $nombreofert = "en " . $dato2->direccion_inmueble;
        } else if ($tipo == "N") {
            $this->db->query("SELECT titulo_oferta FROM oferta WHERE id_oferta = $idOferta;");
            $dato3 = $this->db->registro();
            $nombreofert =$dato3->titulo_oferta;
        } else {
            $nombreofert = "";
        }

        $this->db->query("INSERT INTO usuario_oferta(id_usuario,id_oferta)
                                VALUES (:id_usuario,:id)");

        //bindeo

        $this->db->bind(":id_usuario", $idUsuario);
        $this->db->bind(":id", $idOferta);

        if ($this->db->execute()) {
            $cont = 0;
            foreach ($dat["ids"] as $id) :
                $this->db->query("INSERT INTO `notificacion`(`contenido_notificacion`, `id_usuario`, `leida_notificacion`) VALUES (:cont,:id_usu,0)");
                //Vinculamos los valores
                $this->db->bind(':id_usu', $id->id_usuario);
                $this->db->bind(':cont', "$nombreusu Se ha inscrito a tu oferta $nombreofert");
                if ($this->db->execute()) {
                    $cont++;
                } else {
                    return false;
                }
            endforeach;
            if ($cont > 0) {
                return true;
            }
        } else {
            return false;
        }
    }

    public function cancelarInscripcionOferta($idOferta, $idUsuario)
    {
        $this->db->query("DELETE FROM `usuario_oferta` WHERE id_oferta=$idOferta AND id_usuario='$idUsuario'");

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function preciosViviendas()
    {
        $this->db->query("SELECT max(precio) AS max_precio, min(precio) AS min_precio FROM oferta_inmueble");
        return $this->db->registros();
    }

    public function preciosNegocios()
    {
        $this->db->query("SELECT max(precio_traspaso) AS max_precio, min(precio_traspaso) AS min_precio FROM oferta_negocio");
        return $this->db->registros();
    }

    public function insertarNegocio($datos, $fotos)
    {
        // print_r($fotos);exit;
        $IDNegocio = nextID($this->db, "id_negocio", "negocio");
        $IDOferta = nextID($this->db, "id_oferta", "oferta");

        $this->db->query("INSERT INTO `oferta`(`id_oferta`, `titulo_oferta`, `condiciones_oferta`, `descripcion_oferta`, `id_entidad`, `tipo_oferta`) VALUES (:id_oferta,:titulo_oferta,:condiciones_oferta,:descripcion_oferta,:id_entidad,'N')");
        $this->db->bind(':id_oferta', $IDOferta);
        $this->db->bind(':titulo_oferta', $datos['titulo_oferta']);
        $this->db->bind(':condiciones_oferta', $datos['condiciones']);
        $this->db->bind(':descripcion_oferta', $datos['descripcion_oferta']);
        $this->db->bind(':id_entidad', $datos['id_entidad']);

        if ($this->db->execute()) {

            $this->db->query("INSERT INTO `negocio`(`id_negocio`, `titulo_negocio`, `coste_traspaso_negocio`, `coste_mensual_negocio`, `descripcion_negocio`, `id_municipio_negocio`) VALUES (:id_negocio,:titulo_negocio,:coste_traspaso_negocio,:coste_mensual_negocio,:descripcion_negocio,:id_municipio_negocio)");

            $this->db->bind(':id_negocio', $IDNegocio);
            $this->db->bind(':titulo_negocio', $datos['titulo_negocio']);
            $this->db->bind(':coste_traspaso_negocio', $datos['coste_traspaso']);
            $this->db->bind(':coste_mensual_negocio', $datos['coste_mensual']);
            $this->db->bind(':descripcion_negocio', $datos['descripcion_negocio']);
            $this->db->bind(':id_municipio_negocio', $datos['id_municipio']);
        }

        if ($this->db->execute()) {

            $this->db->query("INSERT INTO `oferta_negocio`(`id_oferta`, `id_negocio`, `precio_traspaso`) VALUES (:id_oferta,:id_negocio,:precio_traspaso)");

            $this->db->bind(':id_negocio', $IDNegocio);
            $this->db->bind(':id_oferta', $IDOferta);
            $this->db->bind(':precio_traspaso', $datos['coste_traspaso']);

            if ($this->db->execute()) {

                if ($datos['local'] == "conlocal") {
                    $IDInmueble = nextID($this->db, "id_inmueble", "inmueble");

                    $this->db->query("INSERT INTO `inmueble`(`id_inmueble`, `metros_cuadrados_inmueble`, `descripcion_inmueble`, `direccion_inmueble`,`tipo_inmueble`, `id_municipio`) VALUES (:id_inmueble,:metros_cuadrados_inmueble,:descripcion_inmueble,:direccion_inmueble,'L',:id_municipio)");

                    $this->db->bind(':id_inmueble', $IDInmueble);
                    $this->db->bind(':metros_cuadrados_inmueble', $datos['metros_cuadrados']);
                    $this->db->bind(':descripcion_inmueble', $datos['descripcion_inmueble']);
                    $this->db->bind(':direccion_inmueble', $datos['direccion']);
                    $this->db->bind(':id_municipio', $datos['id_municipio']);

                    if ($this->db->execute()) {
                        $this->db->query("INSERT INTO `local`(`id_inmueble`, `aforo`, `recursos`) VALUES (:id_inmueble,:aforo,:recursos)");

                        $this->db->bind(':id_inmueble', $IDInmueble);
                        $this->db->bind(':aforo', $datos['aforo']);
                        $this->db->bind(':recursos', $datos['recursos']);

                        if ($this->db->execute()) {
                            $this->db->query("INSERT INTO `negocio_local`(`id_negocio`, `id_inmueble`) VALUES (:id_negocio,:id_inmueble)");

                            $this->db->bind(':id_inmueble', $IDInmueble);
                            $this->db->bind(':id_negocio', $IDNegocio);

                            if ($this->db->execute()) {
                                if (crearCarpeta($IDInmueble) && insertFotos($fotos, $IDInmueble)) {
                                    return true;
                                }
                            }
                        }
                    }
                } else {
                    return true;
                }
            }
        }
    }

    public function insertarInmueble($datos, $fotos)
    {
        // print_r($fotos);exit;
        $IDInmueble = nextID($this->db, "id_inmueble", "inmueble");
        $IDOferta = nextID($this->db, "id_oferta", "oferta");

        $this->db->query("INSERT INTO `oferta`(`id_oferta`, `condiciones_oferta`,`descripcion_oferta`, `id_entidad`, `tipo_oferta`) VALUES (:id_oferta,:condiciones_oferta,:desc_ofert,:id_entidad,'I')");
        $this->db->bind(':id_oferta', $IDOferta);
        $this->db->bind(':desc_ofert', $datos['descripcion_inmueble']);
        $this->db->bind(':condiciones_oferta', $datos['condiciones']);
        $this->db->bind(':id_entidad', $datos['id_entidad']);

        if ($this->db->execute()) {

            $this->db->query("INSERT INTO `inmueble`(`id_inmueble`, `metros_cuadrados_inmueble`, `descripcion_inmueble`, `direccion_inmueble`,`tipo_inmueble`, `id_municipio`) VALUES (:id_inmueble,:metros_cuadrados_inmueble,:descripcion_inmueble,:direccion_inmueble,:tipo,:id_municipio)");

            $this->db->bind(':id_inmueble', $IDInmueble);
            $this->db->bind(':metros_cuadrados_inmueble', $datos['metros_cuadrados']);
            $this->db->bind(':descripcion_inmueble', $datos['descripcion_inmueble']);
            $this->db->bind(':direccion_inmueble', $datos['direccion']);
            $this->db->bind(':id_municipio', $datos['id_municipio']);
            if ($datos['inmueble'] == "vivienda") {
                $this->db->bind(':tipo', "V");
            } else {
                $this->db->bind(':tipo', "L");
            }

            if ($this->db->execute()) {
                $this->db->query("INSERT INTO `oferta_inmueble`(`id_oferta`, `id_inmueble`, `precio`) VALUES (:id_oferta,:id_inmueble,:precio)");

                $this->db->bind(':id_inmueble', $IDInmueble);
                $this->db->bind(':id_oferta', $IDOferta);
                $this->db->bind(':precio', $datos['precio']);

                if ($this->db->execute()) {
                    if ($datos['inmueble'] == "vivienda") {
                        $this->db->query("INSERT INTO `vivienda`(`id_inmueble`, `habitaciones_vivienda`, `tiene_garaje`, `banos`, `tipo_vivienda`) VALUES (:id_inmueble,:habitaciones_vivienda,:tiene_garaje,:banos,:tipo_vivienda)");

                        $this->db->bind(':id_inmueble', $IDInmueble);
                        $this->db->bind(':habitaciones_vivienda', $datos['n_habitaciones']);
                        if ($datos['viviendaGaraje'] == "conGaraje") {
                            $this->db->bind(':tiene_garaje', 1);
                        } else {
                            $this->db->bind(':tiene_garaje', 0);
                        }
                        $this->db->bind(':banos', $datos['n_banos']);
                        $this->db->bind(':tipo_vivienda', $datos['tipo_vivienda']);
                        if ($this->db->execute()) {
                            if (crearCarpeta($IDInmueble) && insertFotos($fotos, $IDInmueble)) {
                                return true;
                            }
                        }
                    } else {
                        $this->db->query("INSERT INTO `local`(`id_inmueble`, `aforo`, `recursos`) VALUES (:id_inmueble,:aforo,:recursos)");

                        $this->db->bind(':id_inmueble', $IDInmueble);
                        $this->db->bind(':aforo', $datos['aforo']);
                        $this->db->bind(':recursos', $datos['recursos']);

                        if ($this->db->execute()) {
                            if (crearCarpeta($IDInmueble) && insertFotos($fotos, $IDInmueble)) {
                                return true;
                            }
                        }
                    }
                }
            }
        } else {
            return false;
        }
    }

    public function obtenerInscritos($idOferta){
        $this->db->query("SELECT usuario.id_usuario ,usuario.nif, usuario.nombre_usuario, usuario.apellidos_usuario, usuario.correo_usuario, usuario.telefono_usuario FROM usuario, usuario_oferta, oferta WHERE usuario.id_usuario = usuario_oferta.id_usuario AND oferta.id_oferta = usuario_oferta.id_oferta AND oferta.id_oferta = $idOferta;");
        $resultados = $this->db->registros();
    
        foreach ($resultados as $resultado) {
            $resultado->id_encriptado = cifrar_url_aes($resultado->id_usuario);
        }

        return $resultados;
    }
    

    // public function obtenerNegocios()
    // {
    //     $this->db->query("SELECT * FROM negocio n RIGHT JOIN oferta o on n.id_negocio=o.id_negocio;");
    //     $this->db->query("SELECT * FROM negocio n RIGHT JOIN oferta o on n.id_negocio=o.id_negocio WHERE $id = o.id_negocio");
    //     return $this->db->registros();
    // }

    // public function EliminaOfertas($id)
    // {
    //     $this->db->query("DELETE FROM oferta WHERE id_oferta=$id");
    //     return $this->db->registros();
    // }

    // public function TipoOfertas($tipo)
    // {
    //     $this->db->query("SELECT * FROM oferta WHERE tipo_oferta=$tipo");
    //     return $this->db->registros();
    // }
}
