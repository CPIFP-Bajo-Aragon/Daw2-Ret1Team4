<?php

class ChatModelo
{
    private $db;

    public function __construct()
    {
        $this->db = new Base;
    }

    public function enviarMensaje($datos){
        
        $this->db->query("INSERT INTO chatear(id_usuario, id_usuario1, mensaje_chat) VALUES (:id_emisor, :id_receptor, :mensaje)");
               
                $this->db->bind(':id_emisor', $datos['id_emisor']);
                $this->db->bind(':id_receptor', $datos['id_receptor']);
                $this->db->bind(':mensaje', $datos['mensaje_chat']);

                if ($this->db->execute()) {
                    $this->db->query("INSERT INTO `notificacion`(`contenido_notificacion`, `id_usuario`, `leida_notificacion`) VALUES (:cont,:id_usu,0)");
                    //Vinculamos los valores
                    $this->db->bind(':id_usu', $datos['id_receptor']);
                    $mensaje = "Te han enviado un nuevo mensaje. <a href='" . RUTA_URL . "/Chat/index/" . cifrar_url_aes($datos['id_emisor']) . "'>Ir al chat</a>";
                    $this->db->bind(':cont', "$mensaje");
                    if ($this->db->execute()) {
                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }

    }

    public function verMensajes($datos){
       
        $this->db->query("SELECT * 
        FROM chatear 
        WHERE (id_usuario = :id_emisor AND id_usuario1 = :id_receptor) 
           OR (id_usuario = :id_receptor AND id_usuario1 = :id_emisor) 
        ORDER BY fecha_chat ASC;
        ");
                
                $this->db->bind(':id_emisor', $datos['id_emisor']);
                $this->db->bind(':id_receptor', $datos['id_receptor']);
                return $this->db->registros();
                
    }

    // TERMINAR -> HAY QUECOGER EL NOMBRE DEL USUARIO Y VER QUE FUNCIONE BIEN

    public function obtenerChatsActivos($datos){
        

        $this->db->query("SELECT chatear.*, 
        COALESCE(NULLIF(usuario.id_usuario, :id_emisor), NULLIF(chatear.id_usuario1, :id_emisor)) AS otro_usuario,
        CASE 
            WHEN usuario.id_usuario = :id_emisor THEN usuario1.nombre_usuario
            ELSE usuario.nombre_usuario 
        END AS nombre_usuario
 FROM chatear
 LEFT JOIN usuario ON chatear.id_usuario = usuario.id_usuario 
 LEFT JOIN usuario AS usuario1 ON chatear.id_usuario1 = usuario1.id_usuario
 WHERE usuario.id_usuario = :id_emisor OR chatear.id_usuario1 = :id_emisor
 GROUP BY nombre_usuario;
 
        ");
                
                $this->db->bind(':id_emisor', $datos['id_emisor']);

                return $this->db->registros();
    }

}
