<?php
//Pasa las cosas del controlador aqui para hacer la consulta en la bd

    class ServicioModelo{
            private $db;
            public function __construct(){
                $this->db= new Base;
            }

            public function obtenerMunicicipios(){
                $this->db->query('SELECT * FROM municipio');
                return $this->db->registros();
            }

            public function obtenerServicios($municipio){
                $this->db->query("SELECT * FROM servicio WHERE id_municipio=$municipio");
                return $this->db->registros();
            }

            public function anadirServicios($datos){
                
                $this->db->query("INSERT INTO servicio (nombre_servicio, descripcion_servicio, id_tipo_servicio, id_municipio, latitud_servicio, longitud_servicio) VALUES (:nombre_servicio, :descripcion_servicio, :id_tipo_servicio, :id_municipio, :latitud_servicio, :longitud_servicio)");
                
                $this->db->bind(':nombre_servicio', $datos['nombre']);
                $this->db->bind(':descripcion_servicio', $datos['descripcion']);
                $this->db->bind(':id_tipo_servicio', $datos['tipoServicio']);
                $this->db->bind(':id_municipio', $datos['idMunicipio']);
                $this->db->bind(':latitud_servicio', $datos['latitud']);
                $this->db->bind(':longitud_servicio', $datos['longitud']);
                $this->db->execute();
                
            }
            
            public function obtenerTiposServicio(){
                $this->db->query("SELECT * FROM tipo_servicio");
                return $this->db->registros();
            }



        }