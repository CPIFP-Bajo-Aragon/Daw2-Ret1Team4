<?php

class LoginModelo
{
    private $db;

    public function __construct()
    {
        $this->db = new Base;
    }


    public function loginEmail($email, $clave)
    {
        $this->db->query("SELECT usuario.*, usuario_has_rol.id_rol FROM usuario, usuario_has_rol WHERE usuario.id_usuario = usuario_has_rol.id_usuario AND correo_usuario='$email' and contrasena_usuario='$clave';");
        return $this->db->registro();
    }

    
}
