<?php

class UsuarioModelo
{
    private $db;

    public function __construct()
    {
        $this->db = new Base;
    }

    public function obtenerUsuarios()
    {
        $this->db->query("SELECT * FROM usuario");
        return $this->db->registros();
    }

    public function existeUsuario($datos)
    {
        $nif = $datos['Nif'];
        $correo = $datos['Email'];
        $this->db->query("SELECT * FROM usuario WHERE nif='$nif' OR correo_usuario='$correo';");
        return $this->db->rowCount();
    }

    public function existeUnique($dato)
    {
        $this->db->query("SELECT * FROM usuario WHERE nif='$dato' OR correo_usuario='$dato';");
        return $this->db->rowCount();
    }

    public function registroUsuario($datos)
    {

        $this->db->query("INSERT INTO usuario (nif, nombre_usuario, apellidos_usuario, correo_usuario, contrasena_usuario, fecha_nacimiento_usuario, telefono_usuario) VALUES (:nif, :nombre, :apellidos, :email, :clave, :fecha, :tlfn)");
        //Vinculamos los valores
        $this->db->bind(':nif', $datos['Nif']);
        $this->db->bind(':nombre', $datos['Nombre']);
        $this->db->bind(':apellidos', $datos['Apellidos']);
        $this->db->bind(':email', $datos['Email']);
        $this->db->bind(':clave', $datos['Clave']);
        $this->db->bind(':fecha', $datos['FechaN']);
        $this->db->bind(':tlfn', $datos['TELF']);

       
        // AÑADIR ROL AL USUARIO

            $id_last=$this->db->executeLastId();
            $this->db->query("INSERT INTO usuario_has_rol (id_usuario, id_rol) VALUES ($id_last, 10);");
          
            $this->db->execute();
            return true;
    }

    public function recuperaContrasena($datos)
    {
        $this->db->query("UPDATE usuario SET contrasena_usuario = :clave WHERE correo_usuario = :correo");
        $this->db->bind(":clave", $datos['contrasena']);
        $this->db->bind(":correo", $datos['correo']);
        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function iniciaSesion($datos)
    {
        $email = $datos['email'];
        $clave = $datos['clave'];
        $this->db->query("SELECT * FROM usuario WHERE correo_usuario='$email' and contrasena_usuario='$clave';");
        return $this->db->rowCount();
        // return $this->db->registros();
    }

    public function notificaciones($id)
    {
        $this->db->query("SELECT COUNT(*) as notificaciones FROM notificacion WHERE id_usuario='$id' and leida_notificacion='0';");
        return $this->db->registro();
    }

    public function obtenerNotificaciones($id)
    {

        $this->db->query("SELECT * FROM notificacion WHERE id_usuario='$id' ORDER BY id_notificacion DESC LIMIT 4;");
        return $this->db->registros();
    }

    public function obtenerTodasNotificaciones($id)
    {

        $this->db->query("SELECT * FROM notificacion WHERE id_usuario='$id' ORDER BY id_notificacion DESC;");
        return $this->db->registros();
    }


    public function obtenerNotificacionesUsuario($id)
    {

        $this->db->query("UPDATE notificacion SET leida_notificacion = 1 WHERE id_usuario = '$id' AND leida_notificacion = 0;");
        return $this->db->execute();
    }

    public function obtenerUsuario($id)
    {

        $this->db->query("SELECT * FROM usuario WHERE id_usuario = '$id';");
        return $this->db->registro();
    }

    public function obtenerIdUsuario($nif)
    {
        $this->db->query("SELECT id_usuario FROM usuario WHERE nif = '$nif'");
        return $this->db->registro();
    }

    public function actualizarRol($id_usuario){
        $this->db->query("UPDATE usuario_has_rol SET id_rol='20' WHERE id_usuario = $id_usuario");
            $this->db->execute();
    }

    public function obtenerEntidades($id)
    {
        $this->db->query("SELECT * FROM usuario_entidad u LEFT JOIN entidad e ON u.id_entidad=e.id_entidad WHERE u.id_usuario = '$id' and e.activa=1;");
        return $this->db->registros();
    }
    public function contEntidades($id)
    {
        $this->db->query("SELECT COUNT(*) AS entidades FROM usuario_entidad WHERE id_usuario = $id");
        return $this->db->registro();
    }

    public function insertarEntidad($datos, $id)
    {
        $this->db->query("INSERT INTO `entidad`(`nombre_entidad`, `cif_entidad`, `sector_entidad`, `direccion_entidad`, `numero_telefono_entidad`, `correo_entidad`, `pagina_web_entidad`) VALUES (:nombre,:cif,:sector,:direccion,:tlfn,:correo,:web)");
        //Vinculamos los valores
        $this->db->bind(':nombre', $datos['Nombre']);
        $this->db->bind(':cif', $datos['Cif']);
        $this->db->bind(':sector', $datos['Sector']);
        $this->db->bind(':direccion', $datos['Direccion']);
        $this->db->bind(':tlfn', $datos['tlf']);
        $this->db->bind(':correo', $datos['Correo']);
        $this->db->bind(':web', $datos['Web']);
        $ent = $this->db->executeLastId();

        $this->db->query("INSERT INTO `usuario_entidad`(`id_usuario`, `id_entidad`, `rol`) VALUES (:usu,:ent,'Administrador')");
        //Vinculamos los valores
        $this->db->bind(':usu', $id);
        $this->db->bind(':ent', $ent);
            if ($this->db->execute()) {
            $this->db->query("INSERT INTO `notificacion`(`contenido_notificacion`, `id_usuario`, `leida_notificacion`) VALUES (:cont,:id_usu,0)");
            //Vinculamos los valores
            $this->db->bind(':id_usu', $id);
            $this->db->bind(':cont', "Se ha creado la entidad satisfactoriamente");
            if ($this->db->execute()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function anadirGerente($datos)
    {
        $nif = $datos['nif'];
        $this->db->query("SELECT id_usuario FROM usuario WHERE nif = '$nif';");
        $dato = $this->db->registro();
        $id = $dato->id_usuario;
        $ent = $datos['id_ent'];

        $this->db->query("SELECT nombre_entidad FROM entidad WHERE id_entidad = '$ent';");
        $dato2 = $this->db->registro();
        $nombreEnt = $dato2->nombre_entidad;
        

        $this->db->query("INSERT INTO `usuario_entidad`(`id_usuario`, `id_entidad`, `rol`) VALUES (:usu,:ent,'Gerente')");
        //Vinculamos los valores
        $this->db->bind(':usu', $id);
        $this->db->bind(':ent', $ent);
        if ($this->db->execute()) {
            $this->db->query("INSERT INTO `notificacion`(`contenido_notificacion`, `id_usuario`, `leida_notificacion`) VALUES (:cont,:id_usu,0)");
            //Vinculamos los valores
            $this->db->bind(':id_usu', $id);
            $this->db->bind(':cont', "Se te ha añadido a la entidad $nombreEnt");
            if ($this->db->execute()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function eliminarEntidad($id)
    {
        // $this->db->query("DELETE FROM entidad WHERE id_entidad=$id ;");

        $this->db->query("UPDATE entidad SET activa = 0 WHERE id_entidad = '$id';");

        if ($this->db->execute()) {
            return true;
        } else {
            return false;
        }
    }

    public function eliminarGerente($id_usu, $id_ent)
    {
        $this->db->query("SELECT nombre_entidad FROM entidad WHERE id_entidad = '$id_ent';");
        $dato = $this->db->registro();
        $nombreEnt = $dato->nombre_entidad;

        $this->db->query("DELETE FROM usuario_entidad WHERE id_usuario=$id_usu AND id_entidad=$id_ent ;");

        if ($this->db->execute()) {
            $this->db->query("INSERT INTO `notificacion`(`contenido_notificacion`, `id_usuario`, `leida_notificacion`) VALUES (:cont,:id_usu,0)");
            //Vinculamos los valores
            $this->db->bind(':id_usu', $id_usu);
            $this->db->bind(':cont', "Se te ha eliminado a la entidad $nombreEnt");
            if ($this->db->execute()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function gerentes($id)
    {

        $this->db->query("SELECT * FROM usuario_entidad u LEFT JOIN usuario us ON u.id_usuario=us.id_usuario WHERE u.id_entidad = '$id';");
        return $this->db->registros();
    }

    public function consulta()
    {

        $this->db->query("SELECT m.nombre_municipio, COUNT(*) AS numero_ofertas FROM inmueble i LEFT JOIN municipio m ON i.id_municipio=m.id_municipio GROUP BY i.id_municipio;");
        return $this->db->registros();
    }

    public function cambiarInfoUsuario($usuarioNuevo, $id)
    {

        $this->db->query("UPDATE usuario SET nombre_usuario = :nombre, apellidos_usuario = :apellidos, correo_usuario = :correo, telefono_usuario = :tlfn  WHERE id_usuario = '$id';");
        $this->db->bind(':nombre', $usuarioNuevo['nombre']);
        $this->db->bind(':apellidos', $usuarioNuevo['apellidos']);
        $this->db->bind(':correo', $usuarioNuevo['correo']);
        $this->db->bind(':tlfn', $usuarioNuevo['tlfn']);
        if ($this->db->execute()) {
            $this->db->query("INSERT INTO `notificacion`(`contenido_notificacion`, `id_usuario`, `leida_notificacion`) VALUES (:cont,:id_usu,0)");
            //Vinculamos los valores
            $this->db->bind(':id_usu', $id);
            $this->db->bind(':cont', "Se ha cambiado correctamente la información de tu perfil");
            if ($this->db->execute()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public function cambiarClaveUsuario($id)
    {

        $this->db->query("UPDATE usuario SET contrasena_usuario = :claveEncriptada WHERE id_usuario= '$id';");
        //Vinculamos los valores
        $claveEncriptada = hash('sha256', $_POST['clave']);
        $this->db->bind(':claveEncriptada', $claveEncriptada);
        if ($this->db->execute()) {
            $this->db->query("INSERT INTO `notificacion`(`contenido_notificacion`, `id_usuario`, `leida_notificacion`) VALUES (:cont,:id_usu,0)");
            //Vinculamos los valores
            $this->db->bind(':id_usu', $id);
            $this->db->bind(':cont', "Se ha cambiado correctamente la contraseña");
            if ($this->db->execute()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    







}
