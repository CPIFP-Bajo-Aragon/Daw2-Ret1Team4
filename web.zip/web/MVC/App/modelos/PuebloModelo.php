<?php 

    class PuebloModelo {
        private $db;

        public function __construct() {
            $this->db = new Base;
        }

        public function obtenerPueblos() {
            $this->db->query("SELECT * FROM municipio");
            return $this->db->registros();
        }

        public function infoPueblo($id) {
            $this->db->query("SELECT * FROM municipio WHERE id_municipio=$id");
            return $this->db->registro();
        }

        public function serviciosPueblo($id) {
            $this->db->query("SELECT servicio.* , tipo_servicio.nombre_tipo_servicio FROM servicio, tipo_servicio WHERE servicio.id_tipo_servicio = tipo_servicio.id_tipo_servicio AND id_municipio = $id");
            
            return $this->db->registros();
        }

        public function anadirPueblos($datos) {
            
            $this->db->query("INSERT INTO municipio(nombre_municipio, provincia_municipio, codigo_postal_municipio) VALUES (:nombre_municipio, :provincia_municipio, :codigo_postal_municipio)");
         
            $this->db->bind(':nombre_municipio', $datos['nombre_municipio']);
            $this->db->bind(':provincia_municipio', $datos['provincia_municipio']);
            $this->db->bind(':codigo_postal_municipio', $datos['codigo_postal_municipio']);
         
            $lastIdPueblo = $this->db->executeLastId();

            $this->db->query("INSERT INTO servicio(nombre_servicio, descripcion_servicio, id_tipo_servicio, id_municipio, latitud_servicio, longitud_servicio) VALUES ('Centro', 'Aquí se encuentra el centro del pueblo', 1, $lastIdPueblo, :latitud_servicio, :longitud_servicio)");
            $this->db->bind(':latitud_servicio', $datos['latitud_municipio']);
            $this->db->bind(':longitud_servicio', $datos['longitud_municipio']);
            return $this->db->execute();
        }

        
    }