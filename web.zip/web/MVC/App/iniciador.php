<?php
//cargamos librerías
require_once 'config/configurar.php';
require_once 'helpers/funciones.php';
require_once 'helpers/mailer.php';

require_once 'librerias/Base.php';
require_once 'librerias/Controlador.php';
require_once 'librerias/Core.php';

require_once 'librerias/Sesion.php';
