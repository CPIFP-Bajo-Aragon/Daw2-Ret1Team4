# Daw2-Ret2Team4
Para descargar (PULL) los cambios desde el repositorio remoto
ejecutar comando: git pull remoto main

De esta manera se hace un pull de la rama "main".
